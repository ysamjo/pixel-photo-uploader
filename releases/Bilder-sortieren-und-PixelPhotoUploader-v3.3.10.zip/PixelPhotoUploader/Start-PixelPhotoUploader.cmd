@echo off
setlocal
title Bilder sortieren + Pixel Photo Uploader
cd /d "%~dp0"

if not exist "%~dp0PixelPhotoUploader.ps1" (
  echo FEHLER: PixelPhotoUploader.ps1 fehlt neben der Startdatei.
  echo Das ZIP bitte zuerst vollstaendig entpacken.
  echo.
  pause
  exit /b 2
)

where powershell.exe >nul 2>&1
if errorlevel 1 (
  echo FEHLER: Windows PowerShell wurde nicht gefunden.
  echo.
  pause
  exit /b 3
)

rem Die Fenster-Oberflaeche laeuft als eigener Prozess ohne Konsolenfenster.
powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command "Start-Process -FilePath 'powershell.exe' -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File','%~dp0PixelPhotoUploader.ps1','-Action','Gui' -WindowStyle Hidden"
set "SCRIPT_EXIT=%ERRORLEVEL%"

if not "%SCRIPT_EXIT%"=="0" (
  echo FEHLER: Die Oberflaeche konnte nicht gestartet werden (Fehlercode %SCRIPT_EXIT%).
  echo Protokoll: %LOCALAPPDATA%\PixelPhotoUploader\PixelPhotoUploader.log
  echo Das Textmenue ist ueber Start-Konsole.cmd erreichbar.
  echo.
  pause
  exit /b %SCRIPT_EXIT%
)

exit /b 0
