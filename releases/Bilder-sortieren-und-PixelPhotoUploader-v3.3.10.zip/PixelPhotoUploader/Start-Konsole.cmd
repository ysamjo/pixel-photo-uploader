@echo off
setlocal
title Pixel Photo Uploader - Textmenue
cd /d "%~dp0"

if not exist "%~dp0PixelPhotoUploader.ps1" (
  echo FEHLER: PixelPhotoUploader.ps1 fehlt neben der Startdatei.
  echo Das ZIP bitte zuerst vollstaendig entpacken.
  echo.
  pause
  exit /b 2
)

where powershell.exe >nul 2>&1
if errorlevel 1 (
  echo FEHLER: Windows PowerShell wurde nicht gefunden.
  echo.
  pause
  exit /b 3
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0PixelPhotoUploader.ps1" -Action Menu
set "SCRIPT_EXIT=%ERRORLEVEL%"

echo.
if not "%SCRIPT_EXIT%"=="0" (
  echo Das Programm wurde mit Fehlercode %SCRIPT_EXIT% beendet.
  echo Protokoll: %LOCALAPPDATA%\PixelPhotoUploader\PixelPhotoUploader.log
) else (
  echo Das Programm wurde beendet.
)
echo Dieses Fenster bleibt fuer die Diagnose offen.
pause
exit /b %SCRIPT_EXIT%
