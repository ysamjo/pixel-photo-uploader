# Bilder sortieren + Pixel Photo Uploader für Windows 3.3.10

Diese gemeinsame Windows-Version verbindet den Dropbox-Import, die Sortierung der eigenen Aufnahmen und den automatischen Upload über ein originales Google Pixel (2016, `sailfish`).

Version 3.2.0 fragt in der Einrichtung zuerst nach dem Übertragungsweg. Standard ist die Android-App „Pixel Photo Companion“ zusammen mit Resilio Sync: **kein USB-Kabel und kein ADB**, auch nicht einmalig. ADB (WLAN oder USB) bleibt als Alternativweg wählbar. 3.2.1 sichert diese Regel zusätzlich im Selbsttest ab und klärt, was verschoben und was kopiert wird. 3.2.2 stellt die Batch-Reihenfolge auf neueste Datei zuerst um. 3.3.0 legt die Fenster-Oberfläche darüber: Doppelklick öffnet jetzt das Programmfenster, der Textmenü-Weg bleibt erhalten. 3.3.1 positioniert die Beschriftungen ohne `Point`-Objekte und nennt bei einem Oberflächenfehler im Hinweisfenster die betroffene Skriptzeile. 3.3.2 behebt die Ursache dieser Fehlerquelle und trennt den Dauerbetrieb vom seltenen Archiv-Grundabgleich: das Archiv muss nicht mehr alle 15 Minuten komplett durchsucht werden. 3.3.3 beseitigt das Durchsuchen auch im Rest des Betriebs — eine gemeldete Datei schreibt ihren eigenen Katalogeintrag, statt den ganzen Archivbaum abzulaufen. 3.3.4 rückt die Fenster-Oberfläche zurecht: die Knopfreihe steht jetzt in einem Raster und bricht nicht mehr um, die Zähler sitzen auf Karten, und die Hauptaktion ist farblich hervorgehoben. 3.3.5 schließt die Lücke, die dabei entstanden war: meldet Windows einen vollen Ereignispuffer, sieht das Skript das jetzt und holt das Archiv sofort vollständig nach. 3.3.6 lässt die Batchgröße bis 10 GiB zu — in Einrichtung, Fenster und Laufzeit gilt dieselbe Spanne von 0,25 bis 10 GiB, und Zahlen außerhalb werden nicht mehr stillschweigend benutzt. 3.3.7 stellt die Wartezeit auf neue Dateien in Sekunden: zwei Minuten waren der kleinste Schritt, jetzt sind es 0 bis 43.200 Sekunden. 3.3.8 zieht die Konsole gleich: `Status anzeigen` nennt dieselben drei Werte, die im Fenster in der Kopfzeile stehen — Batchgröße, Wartezeit in Sekunden und der Abstand des Archiv-Grundabgleichs. 3.3.9 rechnet nach einer **teilweisen** Freigabe ab: meldet das Pixel nur einen Teil des Batches als freigegeben, verkleinert Windows seine eigene Übergabekopie auf den Rest und schreibt `_batch-manifest.json` neu. Vorher sah die App einen halbvollen Ordner als unvollständige Übertragung an und bot die Restdateien nie wieder an — die Automatik stand still, obwohl längst ein Rückbeleg vorlag. Außerdem zeigen Textmenü und Fenstertitel jetzt den Skriptordner mit an: eine versehentlich gestartete Altversion ist damit auf den ersten Blick zu erkennen (ein Fenster mit `3.3.1` durchsucht das Archiv noch bei jedem Zyklus rekursiv). 3.3.10 wirft beim Start des Dauerbetriebs nicht mehr das ganze Archiv an: der letzte Grundabgleich bleibt gemerkt, und innerhalb seiner Spanne bleibt das Archiv in Ruhe — die halbe Stunde `Durchsuche E:\Pictures rekursiv …` nach jedem Anlaufen war der Rest davon.

## Die Fenster-Oberfläche

`Start-PixelPhotoUploader.cmd` öffnet das Fenster. Es steuert dasselbe Skript und dieselben Zustandsdateien wie das Textmenü — es ist nur die Bedienoberfläche darüber.

- Oben fünf Zähler in Karten: Dateien im Archiv, offen (stabil), im Batch ans Pixel, von Google Fotos bestätigt, Rückbelege der App.
- Darunter eine Zeile mit sechs Knöpfen — sie steht jetzt fest in einem Raster und bricht nicht mehr um, auch nicht beim Verkleinern des Fensters. `Überwachung starten` ist als Hauptaktion blau, die übrigen bleiben zurückhaltend.
- `Überwachung starten` / `Überwachung beenden`: der Dauerbetrieb läuft als eigener Prozess und bleibt auch dann laufen, wenn das Fenster geschlossen wird. `tasks.json` im Zustandsordner hält die Prozessnummer dazu.
- `Jetzt abgleichen`: ein einzelner Durchlauf — einsortieren, katalogisieren, Rückbelege abrechnen und den nächsten Batch übergeben.
- `Übergabe prüfen`, `Einrichtung` und `Selbsttest` öffnen dafür ein Konsolenfenster; die geführte Einrichtung mit ihren Ordnerabfragen bleibt dort, weil sie Bewährtes nicht neu erfindet.
- Unten das laufende Protokoll, farbig nach Stufe.
- Reiter `Einstellungen`: Batchgröße (0,25 bis 10 GiB), Wartezeit auf unveränderte Dateien in Sekunden (0 bis 43.200) und der Abstand des Archiv-Grundabgleichs; die Ordnerpfade ändern über die Einrichtung.
- Reiter `Pixel-Checkliste`: dieselbe Checkliste, die die Einrichtung am Ende anzeigt, mit den tatsächlich eingetragenen Ordnern.

Der Vollabgleich aus dem Fenster und der Dauerbetrieb schließen sich gegenseitig aus; der jeweils andere Lauf wird beim Start beendet. Wer den Dauerbetrieb im Textmenü (`2`) startet, läuft an der Zähleranzeige des Fensters vorbei — dann zeigt das Fenster `Überwachung aus`, obwohl etwas läuft.

Ein Oberflächenfehler erscheint seit 3.3.2 mit der betroffenen Skriptzeile in der Statusleiste und seit 3.3.4 rot statt grau. Die Ursache der Meldung aus 3.3.0 und 3.3.1 ist beseitigt: in PowerShell sind `$Caption` (Parameter) und `$caption` (Beschriftung) derselbe Name, der Label wurde stillschweigend zu einem Text und war danach nicht mehr beschriftbar. Der Selbsttest prüft dieses Muster jetzt für jede Funktion des Skripts.

## Übertragungswege

| Weg | Was das Windows-Programm macht | Was das Pixel macht |
| --- | --- | --- |
| Android-App + Resilio (Standard) | legt Batches in den Übergabeordner, wartet auf Rückbelege, löscht bestätigte Batches | Companion-App prüft Google Fotos, gibt Speicher frei, schreibt Rückbeleg |
| WLAN-ADB / USB-ADB | überträgt per `adb push`, liest die Google-Fotos-Oberfläche, klickt selbst `Speicherplatz freigeben` | nur anzeigen und laden |

Beide Wege schließen sich aus: Die App und der ADB-Dauerbetrieb dürfen nicht gleichzeitig laufen, sonst bedienen zwei Stellen dieselbe Google-Fotos-Oberfläche.

## Ablauf

1. Neue Fotos und Videos aus Dropbox `Camera Uploads` werden in den OneDrive-Ordner `Eigene Aufnahmen` verschoben.
2. Dateien direkt im OneDrive-Eingang werden sortiert.
3. Screenshots landen in `Eigene Aufnahmen\Screenshots`.
4. Eindeutig erkennbare Memes und Sticker landen in `Eigene Aufnahmen\Memes`.
5. Alle normalen Fotos und Videos landen nach Aufnahmedatum im Archiv `data\pictures\YYYY.MM`.
6. Nur das Archiv wird rekursiv an das Pixel übertragen. Screenshots und Memes werden nicht an das Pixel gesendet.
7. Bereits erfolgreich verarbeitete Inhalte werden anhand ihrer SHA-256-Prüfsumme nicht erneut hochgeladen.

Das Programm läuft dauerhaft und reagiert auf Ordneränderungen. Solange sich nichts regt, wird nichts nachgescannt: ein neuer Durchlauf durch das **gesamte** Archiv läuft nur dann, wenn das Archiv selbst geändert wurde, wenn etwas einsortiert wurde, wenn die Windows-Überwachung einen vollen Ereignispuffer meldet, oder nach dem eingestellten Abstand des Archiv-Grundabgleichs — standardmäßig alle sechs Stunden. Dieser Abstand gilt auch über einen Neustart hinweg (3.3.10): Anhalten und Neustarten löst keinen zusätzlichen Durchlauf aus. Der Abstand ist im Reiter `Einstellungen` zwischen 5 Minuten und 7 Tagen frei wählbar; `Jetzt abgleichen` macht jederzeit einen vollständigen Durchlauf.

## Wichtige Dateiregeln

- Die Duplikatprüfung verwendet zuerst die Dateigröße als schnellen Kandidatenfilter und danach zwingend SHA-256.
- Der Dateiname muss für ein Duplikat nicht gleich sein.
- Nur bei identischem SHA-256-Inhalt wird die neu eingehende Kopie entfernt.
- Gleicher Dateiname mit anderem Inhalt wird nicht überschrieben; die Datei erhält ` (1)`, ` (2)` usw.
- Videos werden wie normale Aufnahmen nach `YYYY.MM` archiviert und ebenfalls an das Pixel gesendet.
- Das Pixel-Archiv bleibt erhalten. Der Uploader liest daraus und löscht dort keine Originale.
- Dropbox-Eingang und OneDrive-Hauptordner werden dagegen durch Verschieben beziehungsweise Entfernen exakt identischer Duplikate verändert.

## Screenshots und Memes

Die Erkennung ist bewusst vorsichtig, damit normale, etwa per WhatsApp empfangene Fotos nicht allein wegen kleiner Dateigröße als Meme aussortiert werden.

- Screenshot: typischer Dateiname wie `Screenshot` oder `Bildschirmfoto`; zusätzlich werden PNG-Dateien mit typischem Bildschirmformat erkannt.
- Meme/Sticker: eindeutige Begriffe wie `meme`, `sticker`, `giphy`, `tenor` oder `9gag`; kleine GIF- und WebP-Dateien werden ebenfalls erfasst.
- Kleine JPEG-Dateien werden nicht nur wegen ihrer Größe als Meme bewertet.

## Voraussetzungen

- Windows 10 oder Windows 11
- Dropbox-Ordner `Camera Uploads` lokal erreichbar
- OneDrive-Ordner `Eigene Aufnahmen` lokal erreichbar
- lokaler Archivordner, beispielsweise `D:\data\pictures`
- originales kleines Google Pixel von 2016
- Android-App `Pixel Photo Companion` auf dem Pixel installiert (APK per Resilio oder Download, kein USB nötig)
- Resilio Sync auf Windows und auf dem Pixel
- PC und Pixel im selben vertrauenswürdigen WLAN
- Pixel dauerhaft am Ladegerät
- Google Fotos mit Sicherung in Originalqualität

OneDrive und Dropbox sollten die drei ausgewählten Ordner lokal verfügbar halten. Reine Cloud-Platzhalter können nicht zuverlässig geprüft oder verschoben werden.

## Einmalige Einrichtung (Android-App, ohne USB)

1. ZIP vollständig entpacken.
2. `Start-PixelPhotoUploader.cmd` doppelt anklicken. Das Fenster öffnet sich als „nicht eingerichtet“; alle Knöpfe bis auf die Einrichtung sind dann noch graugestellt.
3. Im Fenster `Einrichtung / Pfade ändern` drücken. Die geführte Einrichtung erscheint in einem Konsolenfenster.
4. Bei `Übertragung [A]` einfach die Eingabetaste drücken.
5. Nacheinander fünf Ordner auswählen: Dropbox `Camera Uploads`, OneDrive `Eigene Aufnahmen`, Archiv `data\pictures`, ein **leerer** Resilio-Übergabeordner und ein Ordner für die **Rückbelege** des Pixels.
6. Eine Batchgröße zwischen 0,25 und 10 GiB und die Wartezeit auf unveränderte Dateien in Sekunden wählen; die Einrichtung fragt bei einem ungültigen Wert nach. Bei etwa 7 GiB freiem Pixelspeicher sind 4–5 GiB sinnvoll, ein großes leeres Pixel darf bis an die 10 GiB. Später lässt sich beides im Reiter `Einstellungen` ändern.
7. Resilio-Freigabe A: den Windows-Übergabeordner nur lesend auf dem Pixel als `/storage/emulated/0/DCIM/ResilioInbox` empfangen, vollständige Synchronisierung an, `Overwrite any changed files` aus.
8. Resilio-Freigabe B: `/storage/emulated/0/Documents/PixelPhotoControl` des Pixels freigeben und auf Windows in den gewählten Rückbelegordner legen.
9. In der App Dateizugriff und Bedienungshilfe erlauben, Sicherheitsbestätigung aktivieren, `Überwachung starten` drücken.
10. In Google Fotos Sicherung, Originalqualität und die Sicherung des Ordners `ResilioInbox` prüfen.
11. Das Konsolenfenster der Einrichtung schließen, im Programmfenster `Überwachung starten` drücken. Das Fenster darf danach zugemacht werden; die Überwachung läuft als eigener Prozess weiter.

Für den ersten großen Bestand ist `Jetzt abgleichen` die bessere Wahl als die Überwachung: ein durchgeplanter Durchlauf mit Fortschritt im Protokoll, statt tausender Einzelereignisse.

Die fünf Windows-Ordner müssen getrennt sein und dürfen nicht ineinander liegen. Dadurch entstehen keine Import-Schleifen.

Falls Windows das Skript blockiert: vor dem Entpacken Rechtsklick auf die ZIP-Datei, `Eigenschaften`, dann `Zulassen`.

## Einrichtung mit ADB (Alternative)

1. In der Einrichtung bei `Übertragung [A]` ein `W` (WLAN-ADB) oder `U` (USB-ADB) eingeben.
2. Am Pixel Entwickleroptionen und USB-Debugging einschalten.
3. Pixel per USB verbinden, entsperren und die Debugging-Freigabe bestätigen — für `W` nur einmalig, danach fragt das Programm die Pixel-IP im WLAN ab.
4. Optional zusätzlich den Resilio-Eingang des Pixels überwachen lassen.

Für `W` und `U` wird das USB-Kabel benötigt, entweder einmalig zur Aktivierung von WLAN-ADB oder dauerhaft. Ohne Kabel bleibt nur der App-Weg.

## Android-App und Protokoll

- Windows legt pro Batch den Ordner `WindowsBatches/<Batch-ID>` im Übergabeordner an, Dateinamen als `000001-<Fingerabdruck>.jpg`.
- Die Reihenfolge der Auswahl ist **neueste Datei zuerst** (nach Änderungszeit, bei Gleichstand alphabetisch). `000001` ist also das neueste Medium des Batches, und ein frisch aufgenommenes Handyfoto läuft dem alten Archivbestand voraus.
- Erst wenn alle Dateien liegen, schreibt Windows `_batch-manifest.json` und `_batch-ready.txt`. Die App verarbeitet einen Batch vorher nicht.
- Die App meldet Dateien beim Medienscanner, wartet zweimal `Sicherung abgeschlossen`, öffnet Google Fotos selbst und klickt `Speicherplatz auf diesem Gerät freigeben` samt Bestätigungsdialog. Bleibt der Dialog aus, sucht sie sechs Mal im Fünf-Minuten-Abstand neu, bevor sie einen Menschen holt.
- Für tatsächlich entfernte Dateien schreibt die App `receipt-<Zeitstempel>-<id>.json` in den Kontrollordner. Was im Dateibestand des Pixels verschwunden ist, gilt als freigegeben — auch wenn der Klick von Hand kam.
- Windows stuft eine Datei erst nach ihrem Eintrag in einem Rückbeleg als abgeschlossen ein.
- Sind alle Dateien eines Batches bestätigt, löscht Windows genau diesen Batchordner. Sind nur einige bestätigt, schrumpft Windows seine eigene Übergabekopie auf den Rest und schreibt das Manifest neu — die App bietet die verbliebenen Dateien damit automatisch erneut an. Das Archiv bleibt dabei unberührt.
- Ohne jeglichen Rückbeleg wird ein Batch nicht ein zweites Mal übergeben.

## Pixel und Google Fotos

1. Google Fotos, Profilbild, Fotos-Einstellungen, Sicherung: richtiges Konto, Sicherung eingeschaltet und Originalqualität.
2. Im App-Modus zusätzlich in Google Fotos den Ordner `ResilioInbox` zur Sicherung hinzufügen.
3. Nur für die ADB-Wege: Einstellungen, `Über das Telefon`, siebenmal auf `Build-Nummer` tippen und in `Entwickleroptionen` das USB-Debugging einschalten.

Im App-Modus hält die Companion-App das Pixel offen; nach einem Neustart muss das Gerät einmal manuell entsperrt werden. Eine PIN wird nirgends gespeichert.

## Dauerbetrieb und Sicherheit

- Neue Dateien müssen standardmäßig zwei Minuten (120 Sekunden) unverändert und frei lesbar sein. Einstellbar in Sekunden von 0 bis 43.200 — zwölf Stunden; gespeichert bleibt wie bisher in Minuten, gerechnet wird also auch mit Werten unter einer Minute.
- Windows überwacht Dropbox, den OneDrive-Eingang und das Pixel-Archiv. Was die Überwachung meldet, schreibt der Katalog dateiweise fort — ohne das Archiv zu durchsuchen: ein Ereignis 0,4 s, 200 Ereignisse 0,2 s (gemessen an einem Prüfbaum mit 19.550 Dateien). Meldet die Überwachung auf einen Schlag mehr als 500 Pfade, etwa ein verschobener Monatsordner, ist der komplette Durchlauf billiger und wird benutzt.
- Jeder überwachte Ordner hat seit 3.3.5 einen Ereignispuffer von 64 Kilobyte — das Zulässige Maximum, Windows setzt sonst 4 Kilobyte ein. Reicht auch das nicht, sagt Windows Bescheid, und das Skript hört darauf: die Meldung `Die Windows-Überwachung meldet einen vollen Ereignispuffer; das Archiv wird vollständig nachgesehen.` erscheint im Protokoll, und der nächste Durchlauf vergleicht das Archiv komplett mit dem Katalog, statt auf die ausgefallenen Meldungen zu warten. Ohne diese Absicherung wären geänderte Dateien schlicht als unverändert geführt worden — bis zum nächsten Grundabgleich.
- Beim Durchlauf öffnet das Skript nur neue oder geänderte Dateien neu; Größe und Zeitstempel reichen als Fingerabdruck, die gespeicherte Prüfsumme bleibt erhalten.
- Alles, was die Überwachung trotzdem nicht meldet — Löschungen, umbenannte Ordner, ein Rechner im Ruhemodus — holt der Archiv-Grundabgleich nach, standardmäßig alle sechs Stunden; er ist seit 3.3.3 rund dreieinhalbmal schneller (2,7 s statt 9,7 s im selben Prüfbaum).
- Seit 3.3.10 überlebt der Grundabgleich einen Neustart: `%LOCALAPPDATA%\PixelPhotoUploader\lastscan.json` merkt sich, wann das Archiv zuletzt komplett durchsucht wurde und auf welchen Ordner sich das bezieht. Wer den Dauerbetrieb innerhalb dieser Spanne neu startet, sieht im Protokoll `Letzter Grundabgleich vor … Minuten; das Archiv wird nicht noch einmal komplett durchsucht.` statt einer neuen Rekursion — vorher stand bei jedem Start ein vollständiger Durchlauf durch `E:\Pictures`, bei einem großen Archiv spürbar lange. Gehört der Merker zu einem anderen Archivordner oder fehlt er, wird weiterhin sofort komplett nachgesehen; `Jetzt vollständig abgleichen` setzt ihn zurück. Die Windows-Überwachung läuft jetzt schon, während der Katalog nachgezogen wird, damit in dieser Zeit keine Meldung verloren geht.
- Aus Dropbox und dem OneDrive-Eingang wird **verschoben**; die Eingänge leeren sich bewusst, und die Cloud-Ordner folgen diesem Löschen.
- Das Archiv `data\pictures` ist die Bibliothek: daraus wird für das Pixel ausschließlich **kopiert**. Das Skript ändert dort nichts, auch nicht nach bestätigtem Rückbeleg — gelöscht wird dann nur der eigene Batchordner im Übergabeordner.
- Es wird immer nur ein Batch bereitgestellt; der nächste beginnt erst nach dem Rückbeleg des Pixels.
- Ein Batch ist höchstens so groß wie die eingestellte Batchgröße — die Spanne reicht von 0,25 bis 10 GiB, und Einrichtung, Fenster und Laufzeit benutzen dieselbe Grenze. Im ADB-Weg kommt zusätzlich der freie Pixelspeicher minus 1,5 GiB Reserve dazu; im App-Weg kann Windows den Speicher des Pixels nicht abfragen. Bei 10 GiB Batch müssen also das Pixel und der Übergabeordner auf dem Windows-Rechner diese Menge frei haben.
- Im App-Modus entscheidet ausschließlich der Rückbeleg, was als abgeschlossen gilt. Windows löscht einen Batchordner nur, wenn jede Datei darin bestätigt ist.
- Im ADB-Modus wird erst nach zweimal erkannter Meldung `Sicherung abgeschlossen` `Speicherplatz auf diesem Gerät freigeben` benutzt, und nur tatsächlich entfernte Dateien gelten als abgeschlossen.
- Fehlende Ordner, ausbleibende Rückbelege oder eine unbekannte Google-Fotos-Oberfläche stoppen den Ablauf sicher.

Google Fotos ersetzt kein eigenes Backup. Das Archiv sollte mindestens eine weitere unabhängige Sicherung besitzen.

## Status und Diagnose

Alle Zustandsdateien liegen unter `%LOCALAPPDATA%\PixelPhotoUploader`: `config.json` (Ordner und Übertragungsweg), `catalog.csv` (Archiv mit Prüfsummen), `completed.csv` (bestätigte Uploads), `staged.json` (vorgemerkte Batchdateien), `tasks.json` (Prozessnummern der aus dem Fenster gestarteten Läufe), `lastscan.json` (wann und in welchem Archiv der Grundabgleich zuletzt lief) und `PixelPhotoUploader.log`.

Das Fenster zeigt die Zähler direkt und aktualisiert sie alle zwei Sekunden; `Protokoll öffnen` zeigt den Log im Explorer. Der Textmenü-Weg bleibt über `Start-Konsole.cmd` erreichbar, alternativ `PixelPhotoUploader.ps1 -Action Menu`. Dort startet `3` einen einzelnen Vollabgleich, `4` zeigt die konfigurierten Windows-Ordner, den Übertragungsweg, die Zahl der Rückbelege und den Uploadstatus sowie seit 3.3.8 in einer Zeile `Batch: 5,00 GiB · Stabilität: 120 s · Grundabgleich: alle 360 min`, `5` prüft im App-Modus Übergabe- und Kontrollordner (im ADB-Modus zusätzlich das Pixel und die Google-Fotos-Oberfläche), und `8` öffnet dasselbe Fenster. Beide Oberflächen lesen und schreiben dasselbe `config.json`; die Werte selbst ändern lässt beides über die Einrichtung (`1`) oder im Fenster auf dem Reiter `Einstellungen`.

Auch direkt als Befehl: `-Action Gui` für das Fenster, `-Action Sync` für einen Vollabgleich, `-Action Watch` für den Dauerbetrieb, `-Action Preflight` für die Übergabeprüfung und `-Action SelfTest` für Sortierung, Duplikate, Batchübergabe, Rückbelegabgleich und die neue Katalogfortschreibung ohne Pixel. Der Selbsttest arbeitet in einem temporären Ordner und verändert das Archiv nicht. Er prüft das Skript außerdem als Erstes strukturell: kein Funktionsparameter darf sich im eigenen Rumpf überschreiben (der Oberflächenabsturz aus 3.3.0/3.3.1 hatte genau diese Ursache), und keine Bedingung darf einen Wahrheitswert in einen Text umwandeln — `if ([string]$datei.StartsWith(...))` ist bei einer nicht treffenden Datei `'False'`, und dieser Text gilt in PowerShell als wahr. Das dritte Muster: `-Wert [double]$zahl` ist in einem Befehlsargument keine Umwandlung und `-Wert [DateTime]::Jetzt` kein Aufruf — es bleibt der Text `[double]` beziehungsweise `[DateTime]::Jetzt`. Bei einer Zahl knallt es, bei einem Text-Parameter läuft es falsch weiter; deshalb stehen Umwandlungen und Aufrufe in Argumenten immer in Klammern. Der Selbsttest prüft zuletzt die Überwachung an einem echten Ordner: voller Puffer, alle fünf Ereignismeldungen und die ausgewertete Puffervollmeldung.

Dauerbetrieb aus dem Fenster endet über `Überwachung beenden`. Im Textmenü (`2`) läuft er im sichtbaren Fenster; dort beendet `Strg+C`.

## Pixel nicht erreichbar

App-Modus: Resilio läuft beidseitig, die Companion-App zeigt `Überwachung gestartet`, und der Pixel ist entsperrt. Rückbelege bleiben aus, wenn Google Fotos meldet, dass die Sicherung fehlschlägt; die App hält dann an und löscht nichts.

## WLAN nach Pixel-Neustart (nur ADB-Modus)

WLAN-ADB muss nach jedem vollständigen Pixel-Neustart einmal per USB reaktiviert werden:

1. Pixel per USB verbinden und entsperren.
2. `Start-Konsole.cmd` öffnen und Menüpunkt `7  WLAN-ADB nach Pixel-Neustart reaktivieren` wählen.
3. IP-Adresse bestätigen.
4. Nach der Erfolgsmeldung kann das USB-Datenkabel wieder entfernt werden.

Wer kein USB-Kabel hat, bleibt beim App-Modus; dort entfällt dieser Punkt vollständig. ADB-Port 5555 nur in einem vertrauenswürdigen Heimnetz verwenden und nicht im Router freigeben.

## Unterstützte Formate

Berücksichtigt werden gängige Foto-, RAW- und Videoformate, darunter JPEG, PNG, HEIC, WebP, TIFF, DNG, ARW, CR2/CR3, NEF, RAF, MP4, MOV, MKV, AVI, MTS und WebM. Ob Google Fotos ein spezielles Format annimmt, hängt von Google Fotos ab.
