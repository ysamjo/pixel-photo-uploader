﻿[CmdletBinding()]
param(
    [ValidateSet('Menu', 'Gui', 'Setup', 'Watch', 'Scan', 'Sync', 'Status', 'Preflight', 'SelfTest')]
    [string]$Action = 'Menu'
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$script:AppVersion = '3.3.10'
$script:AppRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:ScriptPath = [string]$MyInvocation.MyCommand.Path
$script:StateRoot = Join-Path $env:LOCALAPPDATA 'PixelPhotoUploader'
$script:ConfigPath = Join-Path $script:StateRoot 'config.json'
$script:CatalogPath = Join-Path $script:StateRoot 'catalog.csv'
$script:CompletedPath = Join-Path $script:StateRoot 'completed.csv'
$script:StagedPath = Join-Path $script:StateRoot 'staged.json'
$script:ResilioStatePath = Join-Path $script:StateRoot 'resilio-state.json'
$script:LogPath = Join-Path $script:StateRoot 'PixelPhotoUploader.log'
$script:TasksPath = Join-Path $script:StateRoot 'tasks.json'
# Merkt sich den Zeitpunkt des letzten Rekursivlaufs durch das Archiv.
$script:LastScanPath = Join-Path $script:StateRoot 'lastscan.json'
$script:UiDumpDevicePath = '/sdcard/pixel_photo_uploader_ui.xml'
$script:UiDumpLocalPath = Join-Path $script:StateRoot 'ui.xml'
$script:AdbPath = Join-Path $script:StateRoot 'tools\platform-tools\adb.exe'
$script:AppBatchFolderName = 'WindowsBatches'
$script:DestinationIndexes = @{}
$script:TrackedTasks = @('Watch', 'Sync', 'Preflight', 'SelfTest', 'Setup')
# 64 KiB sind das Maximum, das FileSystemWatcher zulässt; Standard wären 4 KiB.
$script:WatcherBufferBytes = 65536
# Einrichtung, Fenster und Laufzeit benutzen dieselbe Spanne. Nach oben ist mit 10 GiB
# Schluss, weil ein Batch vollständig auf das Pixel und in den Übergabeordner passen muss.
$script:MinBatchGiB = 0.25
$script:MaxBatchGiB = 10
# Die Wartezeit auf unveränderte Dateien wird weiterhin in Minuten gespeichert, aber in
# Sekunden angeboten: zwei Minuten sind für ein frisch abgelegtes Foto lang.
$script:MaxStableSeconds = 43200
$script:Dashboard = $null
$script:DashboardStamp = ''
$script:Gui = $null
$script:GuiToolTip = $null
$script:GuiPalette = $null
$script:ShellApplication = $null
$script:SupportedExtensions = @(
    '.jpg', '.jpeg', '.jpe', '.png', '.gif', '.webp', '.bmp', '.heic', '.heif',
    '.tif', '.tiff', '.dng', '.arw', '.cr2', '.cr3', '.nef', '.nrw', '.orf',
    '.raf', '.rw2', '.pef', '.srw', '.3gp', '.3g2', '.mp4', '.m4v', '.mov',
    '.mkv', '.avi', '.wmv', '.mpg', '.mpeg', '.mts', '.m2ts', '.webm'
)
$script:SupportedExtensionSet = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
foreach ($extension in $script:SupportedExtensions) { [void]$script:SupportedExtensionSet.Add($extension) }

if (-not (Test-Path -LiteralPath $script:StateRoot)) {
    New-Item -ItemType Directory -Path $script:StateRoot -Force | Out-Null
}

function Write-Log {
    param(
        [Parameter(Mandatory = $true)][string]$Message,
        [ValidateSet('INFO', 'WARN', 'ERROR', 'OK')][string]$Level = 'INFO'
    )

    $line = '{0} [{1}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Message
    Add-Content -LiteralPath $script:LogPath -Value $line -Encoding UTF8

    try {
        $oldColor = $Host.UI.RawUI.ForegroundColor
        try {
            switch ($Level) {
                'WARN'  { $Host.UI.RawUI.ForegroundColor = 'Yellow' }
                'ERROR' { $Host.UI.RawUI.ForegroundColor = 'Red' }
                'OK'    { $Host.UI.RawUI.ForegroundColor = 'Green' }
            }
            Write-Host $line
        }
        finally {
            $Host.UI.RawUI.ForegroundColor = $oldColor
        }
    }
    catch {
        # Ein Hintergrundprozess ohne Konsole hat kein brauchbares RawUI; das Protokoll ist bereits geschrieben.
    }
}

function Save-JsonAtomic {
    param(
        [Parameter(Mandatory = $true)]$Value,
        [Parameter(Mandatory = $true)][string]$Path,
        [int]$Depth = 8
    )

    $tempPath = "$Path.tmp"
    ConvertTo-Json -InputObject $Value -Depth $Depth | Set-Content -LiteralPath $tempPath -Encoding UTF8
    Move-Item -LiteralPath $tempPath -Destination $Path -Force
}

function Load-Config {
    if (-not (Test-Path -LiteralPath $script:ConfigPath)) {
        throw 'Das Programm ist noch nicht eingerichtet. Bitte zuerst "Einrichtung" ausführen.'
    }
    $config = Get-Content -LiteralPath $script:ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $defaults = [ordered]@{
        Version           = 3
        TransportMode     = ''
        ConnectionMode    = 'USB'
        Serial            = ''
        UsbSerial         = ''
        WiFiEndpoint      = ''
        StagingRoot       = ''
        ControlRoot       = ''
        ResilioEnabled    = $false
        ResilioRemoteRoot = '/sdcard/DCIM/ResilioInbox'
        KeepAwake         = $true
        RequireUnlocked   = $true
        ImportEnabled     = $false
        DropboxRoot       = ''
        InboxRoot         = ''
    }
    foreach ($name in $defaults.Keys) {
        if (-not ($config.PSObject.Properties.Name -contains $name)) {
            $config | Add-Member -NotePropertyName $name -NotePropertyValue $defaults[$name]
        }
    }
    if ([string]::IsNullOrWhiteSpace([string]$config.TransportMode)) {
        $inheritedMode = if ([string]$config.ConnectionMode -eq 'WiFi') { 'WiFi' } else { 'USB' }
        $config | Add-Member -NotePropertyName TransportMode -NotePropertyValue $inheritedMode -Force
    }
    return $config
}

function Test-AppTransport {
    param([Parameter(Mandatory = $true)]$Config)
    return ([string]$Config.TransportMode -eq 'App')
}

function Get-TextSha256 {
    param([Parameter(Mandatory = $true)][string]$Text)

    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
        return ([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-', '').ToLowerInvariant()
    }
    finally {
        $sha.Dispose()
    }
}

function Get-FileSha256 {
    param([Parameter(Mandatory = $true)][string]$Path)

    $stream = [System.IO.File]::Open($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::Read)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        return ([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-', '').ToLowerInvariant()
    }
    finally {
        $sha.Dispose()
        $stream.Dispose()
    }
}

function Get-PathPrefix {
    param([Parameter(Mandatory = $true)][string]$Root)

    return [System.IO.Path]::GetFullPath($Root).TrimEnd('\', '/') + [System.IO.Path]::DirectorySeparatorChar
}

function Get-RelativePathUnderPrefix {
    param(
        [Parameter(Mandatory = $true)][string]$Prefix,
        [Parameter(Mandatory = $true)][string]$FullPath
    )

    # Der Katalog wird dateiweise aufgebaut: zwei Uri-Objekte je Datei kosten mehr als
    # der ganze Rest des Durchlaufs. Unterhalb der Wurzel genügt der abgeschnittene Präfix.
    if ($FullPath.Length -gt $Prefix.Length -and
        $FullPath.StartsWith($Prefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        return $FullPath.Substring($Prefix.Length).Replace('/', '\')
    }

    $rootUri = New-Object System.Uri($Prefix)
    $fileUri = New-Object System.Uri($FullPath)
    $relative = [System.Uri]::UnescapeDataString($rootUri.MakeRelativeUri($fileUri).ToString())
    return $relative.Replace('/', '\')
}

function Get-RelativePathSafe {
    param(
        [Parameter(Mandatory = $true)][string]$Root,
        [Parameter(Mandatory = $true)][string]$FullPath
    )

    return Get-RelativePathUnderPrefix -Prefix (Get-PathPrefix -Root $Root) -FullPath $FullPath
}

function Get-Fingerprint {
    param(
        [Parameter(Mandatory = $true)][string]$RelativePath,
        [Parameter(Mandatory = $true)][long]$Size,
        [Parameter(Mandatory = $true)][string]$LastWriteUtc
    )

    $normalized = $RelativePath.Replace('/', '\').ToLowerInvariant()
    return Get-TextSha256 ("{0}|{1}|{2}" -f $normalized, $Size, $LastWriteUtc)
}

function Test-SupportedMedia {
    param([Parameter(Mandatory = $true)][string]$Path)
    return $script:SupportedExtensionSet.Contains([System.IO.Path]::GetExtension($Path))
}

function Test-FileReady {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][DateTime]$StableBefore
    )

    try {
        $file = Get-Item -LiteralPath $Path -ErrorAction Stop
        if ($file.LastWriteTimeUtc -gt $StableBefore) { return $false }

        # Explorer, Robocopy und die meisten Fotoprogramme halten die Zieldatei
        # während des Schreibens geöffnet. Ein exklusives Öffnen verhindert,
        # dass ein nur teilweise kopiertes Medium in die Warteschlange gelangt.
        $stream = [System.IO.File]::Open($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::None)
        $stream.Dispose()
        return $true
    }
    catch {
        return $false
    }
}

function Get-UniqueDestinationPath {
    param(
        [Parameter(Mandatory = $true)][string]$Folder,
        [Parameter(Mandatory = $true)][string]$FileName
    )

    $candidate = Join-Path $Folder $FileName
    if (-not (Test-Path -LiteralPath $candidate)) { return $candidate }

    $stem = [System.IO.Path]::GetFileNameWithoutExtension($FileName)
    $extension = [System.IO.Path]::GetExtension($FileName)
    $counter = 1
    do {
        $candidate = Join-Path $Folder ("{0} ({1}){2}" -f $stem, $counter, $extension)
        $counter++
    } while (Test-Path -LiteralPath $candidate)
    return $candidate
}

function Get-DestinationIndex {
    param([Parameter(Mandatory = $true)][string]$Folder)

    $key = [System.IO.Path]::GetFullPath($Folder).TrimEnd('\').ToLowerInvariant()
    if (-not $script:DestinationIndexes.ContainsKey($key)) {
        $bySize = @{}
        $hashByPath = @{}
        if (Test-Path -LiteralPath $Folder -PathType Container) {
            foreach ($file in Get-ChildItem -LiteralPath $Folder -File -ErrorAction SilentlyContinue) {
                $sizeKey = [string]$file.Length
                if (-not $bySize.ContainsKey($sizeKey)) {
                    $bySize[$sizeKey] = [System.Collections.Generic.List[string]]::new()
                }
                $bySize[$sizeKey].Add($file.FullName)
            }
        }
        $script:DestinationIndexes[$key] = [pscustomobject]@{
            BySize     = $bySize
            HashByPath = $hashByPath
        }
    }
    return $script:DestinationIndexes[$key]
}

function Find-ContentDuplicate {
    param(
        [Parameter(Mandatory = $true)][string]$SourcePath,
        [Parameter(Mandatory = $true)][string]$DestinationFolder
    )

    $source = Get-Item -LiteralPath $SourcePath
    $index = Get-DestinationIndex -Folder $DestinationFolder
    $sizeKey = [string]$source.Length
    if (-not $index.BySize.ContainsKey($sizeKey)) {
        return [pscustomobject]@{ DuplicatePath = ''; SourceHash = '' }
    }

    $sourceHash = Get-FileSha256 -Path $SourcePath
    foreach ($candidatePath in @($index.BySize[$sizeKey])) {
        if (-not (Test-Path -LiteralPath $candidatePath -PathType Leaf)) { continue }
        if (-not $index.HashByPath.ContainsKey($candidatePath)) {
            $index.HashByPath[$candidatePath] = Get-FileSha256 -Path $candidatePath
        }
        if ([string]$index.HashByPath[$candidatePath] -eq $sourceHash) {
            return [pscustomobject]@{ DuplicatePath = $candidatePath; SourceHash = $sourceHash }
        }
    }
    return [pscustomobject]@{ DuplicatePath = ''; SourceHash = $sourceHash }
}

function Add-ToDestinationIndex {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [string]$Sha256 = ''
    )

    $file = Get-Item -LiteralPath $Path
    $index = Get-DestinationIndex -Folder $file.DirectoryName
    $sizeKey = [string]$file.Length
    if (-not $index.BySize.ContainsKey($sizeKey)) {
        $index.BySize[$sizeKey] = [System.Collections.Generic.List[string]]::new()
    }
    $index.BySize[$sizeKey].Add($file.FullName)
    if ($Sha256) { $index.HashByPath[$file.FullName] = $Sha256 }
}

function Move-MediaFile {
    param(
        [Parameter(Mandatory = $true)][string]$SourcePath,
        [Parameter(Mandatory = $true)][string]$DestinationFolder,
        [Parameter(Mandatory = $true)][string]$Reason
    )

    if (-not (Test-Path -LiteralPath $DestinationFolder -PathType Container)) {
        New-Item -ItemType Directory -Path $DestinationFolder -Force | Out-Null
    }

    $duplicate = Find-ContentDuplicate -SourcePath $SourcePath -DestinationFolder $DestinationFolder
    if ($duplicate.DuplicatePath) {
        Remove-Item -LiteralPath $SourcePath -Force
        Write-Log "Duplikat entfernt ($Reason): $SourcePath; identisch mit $($duplicate.DuplicatePath)" 'OK'
        return [pscustomobject]@{ Result = 'Duplicate'; Path = '' }
    }

    $source = Get-Item -LiteralPath $SourcePath
    $destinationPath = Get-UniqueDestinationPath -Folder $DestinationFolder -FileName $source.Name
    Move-Item -LiteralPath $SourcePath -Destination $destinationPath
    Add-ToDestinationIndex -Path $destinationPath -Sha256 ([string]$duplicate.SourceHash)
    Write-Log "Verschoben ($Reason): $SourcePath -> $destinationPath" 'OK'
    return [pscustomobject]@{ Result = 'Moved'; Path = [string]$destinationPath }
}

function Get-MediaDate {
    param([Parameter(Mandatory = $true)][System.IO.FileInfo]$File)

    if ($File.Extension.ToLowerInvariant() -in @('.jpg', '.jpeg', '.tif', '.tiff')) {
        try {
            Add-Type -AssemblyName System.Drawing -ErrorAction SilentlyContinue
            $image = [System.Drawing.Image]::FromFile($File.FullName)
            try {
                $property = $image.GetPropertyItem(0x9003)
                $value = [Text.Encoding]::ASCII.GetString($property.Value).Trim([char]0)
                return [DateTime]::ParseExact($value, 'yyyy:MM:dd HH:mm:ss', $null)
            }
            finally { $image.Dispose() }
        }
        catch { }
    }

    if ($File.BaseName -match '(?<!\d)(?<year>20\d{2})[-._]?(?<month>0[1-9]|1[0-2])[-._]?(?<day>0[1-9]|[12]\d|3[01])(?!\d)') {
        try { return Get-Date -Year ([int]$Matches.year) -Month ([int]$Matches.month) -Day ([int]$Matches.day) -Hour 0 -Minute 0 -Second 0 }
        catch { }
    }

    if ($env:OS -eq 'Windows_NT') {
        try {
            if (-not $script:ShellApplication) {
                $script:ShellApplication = New-Object -ComObject Shell.Application
            }
            $folder = $script:ShellApplication.Namespace($File.DirectoryName)
            $item = $folder.ParseName($File.Name)
            foreach ($propertyName in @('System.Photo.DateTaken', 'System.Media.DateEncoded', 'System.ItemDate')) {
                $value = $item.ExtendedProperty($propertyName)
                if ($value -is [DateTime]) { return [DateTime]$value }
                if ($value) {
                    $parsed = [DateTime]::MinValue
                    if ([DateTime]::TryParse([string]$value, [ref]$parsed)) { return $parsed }
                }
            }
        }
        catch { }
    }
    return $File.LastWriteTime
}

function Get-ImageDimensions {
    param([Parameter(Mandatory = $true)][string]$Path)

    try {
        Add-Type -AssemblyName System.Drawing -ErrorAction SilentlyContinue
        $image = [System.Drawing.Image]::FromFile($Path)
        try { return @([int]$image.Width, [int]$image.Height) }
        finally { $image.Dispose() }
    }
    catch { return @(0, 0) }
}

function Get-MediaCategory {
    param([Parameter(Mandatory = $true)][System.IO.FileInfo]$File)

    $extension = $File.Extension.ToLowerInvariant()
    if ($File.Name -match '(?i)screenshot|screen[ _-]?shot|bildschirmfoto|bildschirmaufnahme') {
        return 'Screenshots'
    }

    $width = 0
    $height = 0
    if (($extension -in @('.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp')) -and $File.Length -le 5MB) {
        $width, $height = Get-ImageDimensions -Path $File.FullName
    }

    if ($extension -eq '.png' -and $width -gt 0 -and $height -gt 0) {
        $portraitScreen = $height -ge 1200 -and (($height / [double]$width) -ge 1.45)
        $landscapeScreen = $width -ge 1200 -and (($width / [double]$height) -ge 1.45)
        if ($portraitScreen -or $landscapeScreen) { return 'Screenshots' }
    }

    if ($File.Name -match '(?i)meme|sticker|giphy|tenor|9gag') { return 'Memes' }
    if (($extension -in @('.gif', '.webp')) -and $File.Length -le 1MB) { return 'Memes' }
    return 'Archive'
}

function Invoke-ImportPipeline {
    param([Parameter(Mandatory = $true)]$Config)

    if (-not [bool]$Config.ImportEnabled) {
        return [pscustomobject]@{ Moved = 0; Duplicates = 0; ArchivePaths = @() }
    }
    foreach ($path in @([string]$Config.DropboxRoot, [string]$Config.InboxRoot, [string]$Config.SourceRoot)) {
        if (-not (Test-Path -LiteralPath $path -PathType Container)) {
            throw "Importordner ist nicht erreichbar: $path"
        }
    }

    $script:DestinationIndexes = @{}
    $stableBefore = [DateTime]::UtcNow.AddMinutes(-[double]$Config.StableMinutes)
    $moved = 0
    $duplicates = 0
    $archivePaths = [System.Collections.Generic.List[string]]::new()
    $sourcePrefix = Get-PathPrefix -Root ([string]$Config.SourceRoot)

    Write-Log 'Importiere stabile Medien aus Dropbox in den OneDrive-Eingang ...'
    foreach ($file in @(Get-ChildItem -LiteralPath ([string]$Config.DropboxRoot) -Recurse -File -ErrorAction SilentlyContinue)) {
        if (-not (Test-SupportedMedia -Path $file.FullName)) { continue }
        if (-not (Test-FileReady -Path $file.FullName -StableBefore $stableBefore)) { continue }
        $result = Move-MediaFile -SourcePath $file.FullName -DestinationFolder ([string]$Config.InboxRoot) -Reason 'Dropbox -> OneDrive'
        if ($result.Result -eq 'Moved') { $moved++ } else { $duplicates++ }
    }

    Write-Log 'Sortiere den OneDrive-Eingang ...'
    foreach ($file in @(Get-ChildItem -LiteralPath ([string]$Config.InboxRoot) -File -ErrorAction SilentlyContinue)) {
        if (-not (Test-SupportedMedia -Path $file.FullName)) { continue }
        if (-not (Test-FileReady -Path $file.FullName -StableBefore $stableBefore)) { continue }

        $category = Get-MediaCategory -File $file
        if ($category -eq 'Screenshots' -or $category -eq 'Memes') {
            $destinationFolder = Join-Path ([string]$Config.InboxRoot) $category
        }
        else {
            $date = Get-MediaDate -File $file
            $destinationFolder = Join-Path ([string]$Config.SourceRoot) $date.ToString('yyyy.MM')
        }

        $result = Move-MediaFile -SourcePath $file.FullName -DestinationFolder $destinationFolder -Reason "Sortierung: $category"
        if ($result.Result -eq 'Moved') {
            $moved++
            # Nur was im Archiv ankommt, gehört in die Katalogliste. Der Dauerbetrieb
            # schreibt daraus die betroffenen Einträge fort, statt das Archiv zu durchsuchen.
            if ($result.Path.StartsWith($sourcePrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
                $archivePaths.Add([string]$result.Path)
            }
        }
        else { $duplicates++ }
    }

    Write-Log "Import/Sortierung abgeschlossen: $moved verschoben, $duplicates SHA-256-Duplikate entfernt." 'OK'
    return [pscustomobject]@{ Moved = $moved; Duplicates = $duplicates; ArchivePaths = @($archivePaths) }
}

function Load-Catalog {
    if (-not (Test-Path -LiteralPath $script:CatalogPath)) {
        return @()
    }
    return @(Import-Csv -LiteralPath $script:CatalogPath -Encoding UTF8)
}

function Save-Catalog {
    param([Parameter(Mandatory = $true)]$Entries)

    $tempPath = "$script:CatalogPath.tmp"
    if (@($Entries).Count -eq 0) {
        '"Fingerprint","RelativePath","Size","LastWriteUtc","Stable","Sha256"' | Set-Content -LiteralPath $tempPath -Encoding UTF8
    }
    else {
        @($Entries) | Export-Csv -LiteralPath $tempPath -NoTypeInformation -Encoding UTF8
    }
    Move-Item -LiteralPath $tempPath -Destination $script:CatalogPath -Force
}

function ConvertTo-UtcDateTime {
    param([Parameter(Mandatory = $true)]$Value)

    # ConvertFrom-Json liefert je nach PowerShell-Version ein DateTime-Objekt oder einen
    # Text, und ein Text wird ohne diesen Hinweis in der Ortszeit geparst. Verglichen wird
    # deshalb nur ein Ausdruck, der nachweislich in UTC steht.
    if ($Value -is [DateTime]) {
        if ($Value.Kind -eq [System.DateTimeKind]::Utc) { return $Value }
        return $Value.ToUniversalTime()
    }
    $text = ([string]$Value).Trim()
    $parsed = [DateTime]::MinValue
    $culture = [System.Globalization.CultureInfo]::InvariantCulture
    $styles = [System.Globalization.DateTimeStyles]::AdjustToUniversal -bor [System.Globalization.DateTimeStyles]::RoundtripKind
    if (-not [DateTime]::TryParseExact($text, 'o', $culture, $styles, [ref]$parsed)) {
        if (-not [DateTime]::TryParse($text, $culture, $styles, [ref]$parsed)) { return [DateTime]::MinValue }
    }
    if ($parsed.Kind -ne [System.DateTimeKind]::Utc) { return $parsed.ToUniversalTime() }
    return $parsed
}

function Get-LastFullScanUtc {
    param([Parameter(Mandatory = $true)][AllowEmptyString()][string]$SourceRoot)

    # Merkt sich den letzten Rekursivlauf durch das Archiv, damit ein Neustart des
    # Dauerbetriebs nicht sofort wieder den teuren Durchlauf kostet. Eine fehlende,
    # unlesbare oder zu einem anderen Archiv gehörende Markedatei zählt als "noch nie".
    if (-not (Test-Path -LiteralPath $script:LastScanPath -PathType Leaf)) { return [DateTime]::MinValue }
    try {
        $raw = [string](Get-Content -LiteralPath $script:LastScanPath -Raw -Encoding UTF8)
        $data = ConvertFrom-Json -InputObject $raw
        if (-not [string]::Equals(([string]$data.SourceRoot), $SourceRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
            return [DateTime]::MinValue
        }
        return ConvertTo-UtcDateTime -Value $data.ScannedUtc
    }
    catch {
        return [DateTime]::MinValue
    }
}

function Set-LastFullScanUtc {
    param(
        [Parameter(Mandatory = $true)][DateTime]$Value,
        [Parameter(Mandatory = $true)][AllowEmptyString()][string]$SourceRoot
    )

    try {
        $state = [pscustomobject]@{
            ScannedUtc = $Value.ToUniversalTime().ToString('o')
            SourceRoot = $SourceRoot
        }
        Save-JsonAtomic -Value $state -Path $script:LastScanPath -Depth 3
    }
    catch {
        Write-Log "Zeitpunkt des Grundabgleichs nicht merkbar: $($_.Exception.Message)" 'WARN'
    }
}

function Get-ArchiveScanDecision {
    param(
        [Parameter(Mandatory = $true)][DateTime]$LastFullScanUtc,
        [Parameter(Mandatory = $true)][double]$RescanMinutes
    )

    # Beide Zeitpunkte liegen in UTC; eine Subtraktion vergleicht ohnehin nur die Ticks.
    $ageMinutes = [Math]::Max(0.0, ([DateTime]::UtcNow - $LastFullScanUtc).TotalMinutes)
    $due = ($ageMinutes -ge $RescanMinutes)
    # WaitMinutes gilt von jetzt an: läuft der Grundabgleich gerade, ist die ganze Spanne neu.
    $waitMinutes = $RescanMinutes
    if (-not $due) { $waitMinutes = [Math]::Max(1.0, $RescanMinutes - $ageMinutes) }
    return [pscustomobject]@{
        AgeMinutes  = $ageMinutes
        FullScan    = $due
        WaitMinutes = $waitMinutes
    }
}

function Load-Staged {
    if (-not (Test-Path -LiteralPath $script:StagedPath)) {
        return @()
    }
    $raw = Get-Content -LiteralPath $script:StagedPath -Raw -Encoding UTF8
    if ([string]::IsNullOrWhiteSpace($raw)) {
        return @()
    }
    return @($raw | ConvertFrom-Json)
}

function Save-Staged {
    param([Parameter(Mandatory = $true)]$Entries)
    Save-JsonAtomic -Value @($Entries) -Path $script:StagedPath -Depth 8
}

function Load-CompletionSets {
    $fingerprints = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    $hashes = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)

    if (Test-Path -LiteralPath $script:CompletedPath) {
        foreach ($row in @(Import-Csv -LiteralPath $script:CompletedPath -Encoding UTF8)) {
            if ($row.Fingerprint) { [void]$fingerprints.Add([string]$row.Fingerprint) }
            if ($row.Sha256) { [void]$hashes.Add([string]$row.Sha256) }
        }
    }

    return [pscustomobject]@{
        Fingerprints = $fingerprints
        Hashes = $hashes
    }
}

function Add-Completion {
    param(
        [Parameter(Mandatory = $true)]$Entry,
        [Parameter(Mandatory = $true)]$CompletionSets,
        [Parameter(Mandatory = $true)][string]$Reason
    )

    if ($CompletionSets.Fingerprints.Contains([string]$Entry.Fingerprint)) {
        return
    }

    $row = [pscustomobject]@{
        Fingerprint  = [string]$Entry.Fingerprint
        Sha256       = [string]$Entry.Sha256
        RelativePath = [string]$Entry.RelativePath
        Size         = [string]$Entry.Size
        CompletedUtc = [DateTime]::UtcNow.ToString('o')
        Reason       = $Reason
    }

    if (Test-Path -LiteralPath $script:CompletedPath) {
        $row | Export-Csv -LiteralPath $script:CompletedPath -NoTypeInformation -Encoding UTF8 -Append
    }
    else {
        $row | Export-Csv -LiteralPath $script:CompletedPath -NoTypeInformation -Encoding UTF8
    }

    [void]$CompletionSets.Fingerprints.Add([string]$Entry.Fingerprint)
    if ($Entry.Sha256) { [void]$CompletionSets.Hashes.Add([string]$Entry.Sha256) }
}

function New-CatalogEntry {
    param(
        [Parameter(Mandatory = $true)]$File,
        [Parameter(Mandatory = $true)][string]$RelativePath,
        [Parameter(Mandatory = $true)]$OldByFingerprint,
        [Parameter(Mandatory = $true)][DateTime]$StableBefore,
        [bool]$ReuseStable = $true
    )

    $lastWrite = [string]$File.LastWriteTimeUtc.ToString('o')
    $fingerprint = Get-Fingerprint -RelativePath $RelativePath -Size ([long]$File.Length) -LastWriteUtc $lastWrite
    $known = $OldByFingerprint.ContainsKey($fingerprint)
    $sha256 = ''
    $isStable = $false
    if ($known) {
        $sha256 = [string]$OldByFingerprint[$fingerprint].Sha256
        # Fingerabdruck enthält Pfad, Größe und Änderungszeit: war die Datei schon
        # einmal vollständig lesbar, muss sie dafür nicht ein zweites Mal geöffnet werden.
        if ($ReuseStable) { $isStable = ([string]$OldByFingerprint[$fingerprint].Stable -eq 'True') }
    }
    if (-not $known -or -not $ReuseStable) {
        $isStable = Test-FileReady -Path ([string]$File.FullName) -StableBefore $StableBefore
    }

    return [pscustomobject]@{
        Fingerprint  = $fingerprint
        RelativePath = $RelativePath
        Size         = [string]$File.Length
        LastWriteUtc = $lastWrite
        Stable       = [string]$isStable
        Sha256       = $sha256
    }
}

function Update-Catalog {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [string[]]$OnlyPaths = @(),
        [int]$BulkPathLimit = 500,
        [switch]$Overflow
    )

    $sourceRoot = [string]$Config.SourceRoot
    if (-not (Test-Path -LiteralPath $sourceRoot -PathType Container)) {
        Write-Log "Quellordner ist nicht erreichbar: $sourceRoot" 'WARN'
        return $null
    }

    $prefix = Get-PathPrefix -Root $sourceRoot
    $stableBefore = [DateTime]::UtcNow.AddMinutes(-[double]$Config.StableMinutes)
    $oldEntries = @(Load-Catalog)
    $oldByFingerprint = @{}
    foreach ($old in $oldEntries) { $oldByFingerprint[[string]$old.Fingerprint] = $old }
    $started = Get-Date

    $only = @($OnlyPaths | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) })
    # Einzelne Meldungen schreibt der Katalog fort; bei einer Sammelaktion, nach einem
    # Überlauf des Ereignispuffers und ohne Meldungen bleibt der Durchlauf billiger bzw.
    # die einzige Quelle.
    if (-not $Overflow -and $only.Count -gt 0 -and $only.Count -le $BulkPathLimit) {
        return @(Update-CatalogFromPaths -Config $Config -SourceRoot $sourceRoot -Prefix $prefix -StableBefore $stableBefore `
            -OldEntries $oldEntries -OldByFingerprint $oldByFingerprint -OnlyPaths $only -Started $started)
    }

    Write-Log "Durchsuche $sourceRoot rekursiv nach neuen oder geänderten Medien ..."
    $entries = [System.Collections.Generic.List[object]]::new()
    $totalBytes = [long]0
    $newCount = 0
    $skippedDirectories = 0
    $pending = [System.Collections.Generic.Queue[object]]::new()
    $pending.Enqueue((New-Object System.IO.DirectoryInfo($sourceRoot)))

    while ($pending.Count -gt 0) {
        $directory = $pending.Dequeue()
        $children = @()
        try { $children = @($directory.GetDirectories()) } catch { $skippedDirectories++ }
        foreach ($child in $children) {
            # Verknüpfungen und Wolkenplätze würden den Durchlauf im Kreis führen.
            if (($child.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) { $skippedDirectories++; continue }
            $pending.Enqueue($child)
        }

        $files = @()
        try { $files = @($directory.GetFiles()) } catch { $skippedDirectories++; continue }
        foreach ($file in $files) {
            if (-not (Test-SupportedMedia -Path ([string]$file.FullName))) { continue }
            $relative = Get-RelativePathUnderPrefix -Prefix $prefix -FullPath ([string]$file.FullName)
            if ($relative -match '^(?i)(\$RECYCLE\.BIN|System Volume Information)(\\|$)') { continue }
            $entry = New-CatalogEntry -File $file -RelativePath $relative -OldByFingerprint $oldByFingerprint -StableBefore $stableBefore
            if (-not $oldByFingerprint.ContainsKey([string]$entry.Fingerprint)) { $newCount++ }
            $entries.Add($entry)
            $totalBytes += [long]$entry.Size
        }
    }

    Save-Catalog -Entries $entries
    Set-LastFullScanUtc -Value (Get-Date) -SourceRoot $sourceRoot
    $gib = [Math]::Round($totalBytes / 1GB, 2)
    $seconds = ((Get-Date) - $started).TotalSeconds
    $skipNote = ''
    if ($skippedDirectories -gt 0) { $skipNote = '; {0:N0} Ordner übersprungen' -f $skippedDirectories }
    Write-Log ('Katalog: {0:N0} Dateien, {1:N2} GiB; {2:N0} neue/geänderte Fingerabdrücke; Durchlauf {3:N1} s{4}.' -f `
        $entries.Count, $gib, $newCount, $seconds, $skipNote) 'OK'
    return @($entries)
}

function Update-CatalogFromPaths {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)][string]$SourceRoot,
        [Parameter(Mandatory = $true)][string]$Prefix,
        [Parameter(Mandatory = $true)][DateTime]$StableBefore,
        # Ein leerer Katalog ist der Normalfall beim ersten Ereignis nach der Einrichtung.
        [Parameter(Mandatory = $true)][AllowEmptyCollection()][object[]]$OldEntries,
        [Parameter(Mandatory = $true)]$OldByFingerprint,
        [Parameter(Mandatory = $true)][AllowEmptyCollection()][object[]]$OnlyPaths,
        [Parameter(Mandatory = $true)][DateTime]$Started
    )

    $entries = [System.Collections.Generic.List[object]]::new()
    $positionByRelative = @{}
    $index = -1
    foreach ($old in $OldEntries) {
        $index++
        $entries.Add($old)
        $positionByRelative[[string]$old.RelativePath] = $index
    }

    $removedIndexes = New-Object 'System.Collections.Generic.HashSet[int]'
    $changed = 0
    foreach ($path in @($OnlyPaths)) {
        $full = [string]$path
        if ($full.Length -le $Prefix.Length -or
            -not $full.StartsWith($Prefix, [System.StringComparison]::OrdinalIgnoreCase)) { continue }

        $relative = $full.Substring($Prefix.Length).Replace('/', '\')
        if ($relative -match '^(?i)(\$RECYCLE\.BIN|System Volume Information)(\\|$)') { continue }
        $known = $positionByRelative.ContainsKey($relative)

        $file = New-Object System.IO.FileInfo($full)
        if ($file.Exists -and (Test-SupportedMedia -Path $full)) {
            $entry = New-CatalogEntry -File $file -RelativePath $relative -OldByFingerprint $OldByFingerprint `
                -StableBefore $StableBefore -ReuseStable $false
            if ($known) { $entries[[int]$positionByRelative[$relative]] = $entry } else {
                $positionByRelative[$relative] = $entries.Count
                $entries.Add($entry)
            }
            $changed++
            continue
        }

        # Ein vorhandener Ordner meldet nichts über seinen Inhalt und darf nichts löschen.
        # Ist der gemeldete Weg selbst weg, fehlt aber auch alles, was darunter stand.
        if (Test-Path -LiteralPath $full -PathType Container) { continue }
        if ($known) { [void]$removedIndexes.Add([int]$positionByRelative[$relative]); $changed++ }
        $nested = $relative + '\'
        for ($i = 0; $i -lt $entries.Count; $i++) {
            if (([string]$entries[$i].RelativePath).StartsWith($nested, [System.StringComparison]::OrdinalIgnoreCase)) {
                [void]$removedIndexes.Add($i)
                $changed++
            }
        }
    }

    $seconds = ((Get-Date) - $Started).TotalSeconds
    if ($changed -eq 0) {
        Write-Log ('Katalog ohne Durchlauf geprüft: {0:N0} Meldungen, nichts geändert ({1:N1} s).' -f @($OnlyPaths).Count, $seconds)
        return @($entries)
    }

    if ($removedIndexes.Count -gt 0) {
        $kept = [System.Collections.Generic.List[object]]::new()
        for ($i = 0; $i -lt $entries.Count; $i++) {
            if (-not $removedIndexes.Contains($i)) { $kept.Add($entries[$i]) }
        }
        $entries = $kept
    }
    Save-Catalog -Entries $entries
    Write-Log ('Katalog ohne Rekursivlauf ergänzt: {0:N0} Meldungen, {1:N0} Einträge aktualisiert, jetzt {2:N0} Dateien ({3:N1} s).' -f `
        @($OnlyPaths).Count, $changed, $entries.Count, $seconds) 'OK'
    return @($entries)
}

function Ensure-Adb {
    if (Test-Path -LiteralPath $script:AdbPath) {
        return
    }

    Write-Log 'Android Platform Tools fehlen; lade sie direkt von Google herunter ...'
    $toolsRoot = Join-Path $script:StateRoot 'tools'
    if (-not (Test-Path -LiteralPath $toolsRoot)) {
        New-Item -ItemType Directory -Path $toolsRoot -Force | Out-Null
    }

    $zipPath = Join-Path $env:TEMP 'platform-tools-latest-windows.zip'
    Invoke-WebRequest -UseBasicParsing -Uri 'https://dl.google.com/android/repository/platform-tools-latest-windows.zip' -OutFile $zipPath
    Expand-Archive -LiteralPath $zipPath -DestinationPath $toolsRoot -Force
    Remove-Item -LiteralPath $zipPath -Force

    if (-not (Test-Path -LiteralPath $script:AdbPath)) {
        throw 'ADB konnte nicht installiert werden.'
    }
    Write-Log 'Android Platform Tools wurden installiert.' 'OK'
}

function Invoke-AdbNative {
    param([Parameter(Mandatory = $true)][object[]]$Arguments)

    # ADB meldet den normalen Erststart des Daemons über stderr. Windows
    # PowerShell darf diese Meldung nicht wegen ErrorActionPreference=Stop
    # als Skriptfehler behandeln; entscheidend ist allein der Exitcode.
    $previousPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $output = @(& $script:AdbPath @Arguments 2>&1)
        $exitCode = $LASTEXITCODE
    }
    finally {
        $ErrorActionPreference = $previousPreference
    }
    return [pscustomobject]@{ Output = $output; ExitCode = $exitCode }
}

function Invoke-Adb {
    param(
        [Parameter(Mandatory = $true)][object[]]$Arguments,
        $Config = $null,
        [switch]$AllowFailure
    )

    Ensure-Adb
    $allArguments = [System.Collections.Generic.List[object]]::new()
    $targetSerial = ''
    if ($Config) {
        if (([string]$Config.TransportMode -eq 'WiFi') -and $Config.WiFiEndpoint) {
            $targetSerial = [string]$Config.WiFiEndpoint
        }
        elseif ($Config.Serial) {
            $targetSerial = [string]$Config.Serial
        }
    }
    if (-not [string]::IsNullOrWhiteSpace($targetSerial)) {
        $allArguments.Add('-s')
        $allArguments.Add($targetSerial)
    }
    foreach ($argument in $Arguments) { $allArguments.Add($argument) }

    $result = Invoke-AdbNative -Arguments @($allArguments)
    $text = ($result.Output | Out-String).Trim()
    if (($result.ExitCode -ne 0) -and (-not $AllowFailure)) {
        throw "ADB-Fehler ($($result.ExitCode)): $text"
    }
    return $text
}

function Get-AdbDeviceStates {
    Ensure-Adb
    $result = Invoke-AdbNative -Arguments @('devices')
    if ($result.ExitCode -ne 0) {
        throw "ADB konnte die Geräteliste nicht lesen: $(($result.Output | Out-String).Trim())"
    }
    $devices = [System.Collections.Generic.List[object]]::new()
    foreach ($line in $result.Output) {
        $text = ([string]$line).Trim()
        if ($text -match '^(?<serial>[^\s]+)\s+(?<state>device|unauthorized|offline|recovery|sideload|no permissions.*)$') {
            $devices.Add([pscustomobject]@{ Serial = [string]$Matches.serial; State = [string]$Matches.state })
        }
    }
    return @($devices)
}

function Get-ConnectedDevices {
    return @(Get-AdbDeviceStates | Where-Object { $_.State -eq 'device' } | ForEach-Object { $_.Serial })
}

function Wait-ForAuthorizedUsbPixel {
    param([int]$TimeoutSeconds = 120)

    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    $lastMessage = ''
    do {
        $usbStates = @(Get-AdbDeviceStates | Where-Object { $_.Serial -notmatch ':' })
        $ready = @($usbStates | Where-Object { $_.State -eq 'device' })
        if ($ready.Count -eq 1) {
            Write-Host "Pixel per USB erkannt und freigegeben: $($ready[0].Serial)" -ForegroundColor Green
            return [string]$ready[0].Serial
        }

        if ($ready.Count -gt 1) {
            $message = 'Mehrere freigegebene USB-Geräte erkannt. Bitte nur das Pixel angeschlossen lassen.'
        }
        elseif (@($usbStates | Where-Object { $_.State -eq 'unauthorized' }).Count -gt 0) {
            $message = 'Pixel erkannt, aber noch nicht freigegeben. Pixel entsperren und "USB-Debugging zulassen?" bestätigen.'
        }
        elseif (@($usbStates | Where-Object { $_.State -eq 'offline' }).Count -gt 0) {
            $message = 'Pixel ist ADB-offline. USB-Kabel kurz trennen, erneut verbinden und den Freigabedialog bestätigen.'
        }
        else {
            $message = 'Noch kein ADB-Gerät erkannt. Pixel entsperren, USB-Debugging aktivieren und USB auf "Dateiübertragung" stellen.'
        }

        if ($message -ne $lastMessage) {
            Write-Host $message -ForegroundColor Yellow
            $lastMessage = $message
        }
        Start-Sleep -Seconds 3
    } while ((Get-Date) -lt $deadline)

    throw 'Pixel wurde innerhalb von 120 Sekunden nicht als freigegebenes ADB-Gerät erkannt. Datenkabel und Windows-Treiber "Android Composite ADB Interface" im Geräte-Manager prüfen.'
}

function Connect-WifiAdb {
    param(
        [Parameter(Mandatory = $true)][string]$Endpoint,
        [switch]$AllowFailure
    )

    Ensure-Adb
    if ([string]::IsNullOrWhiteSpace($Endpoint)) {
        if ($AllowFailure) { return $false }
        throw 'Für WLAN-ADB ist keine Pixel-Adresse konfiguriert.'
    }

    $connectResult = Invoke-AdbNative -Arguments @('connect', $Endpoint)
    $stateResult = Invoke-AdbNative -Arguments @('-s', $Endpoint, 'get-state')
    $ok = ($connectResult.ExitCode -eq 0) -and ($stateResult.ExitCode -eq 0) -and (($stateResult.Output | Out-String) -match 'device')
    if ((-not $ok) -and (-not $AllowFailure)) {
        throw "WLAN-ADB ist nicht erreichbar ($Endpoint). Pixel und PC müssen im selben WLAN sein. Nach einem Pixel-Neustart WLAN-ADB gegebenenfalls einmal per USB neu aktivieren. ADB: $($connectResult.Output | Out-String)"
    }
    return $ok
}

function Enable-WifiAdbFromUsb {
    param(
        [Parameter(Mandatory = $true)][string]$UsbSerial,
        [Parameter(Mandatory = $true)][string]$Endpoint
    )

    Ensure-Adb
    $tcpResult = Invoke-AdbNative -Arguments @('-s', $UsbSerial, 'tcpip', '5555')
    if ($tcpResult.ExitCode -ne 0) {
        throw "WLAN-ADB konnte über USB nicht aktiviert werden: $($tcpResult.Output | Out-String)"
    }
    Start-Sleep -Seconds 3
    if (-not (Connect-WifiAdb -Endpoint $Endpoint -AllowFailure)) {
        throw "Das Pixel lauscht auf Port 5555, ist aber unter $Endpoint nicht erreichbar. IP-Adresse und WLAN-Isolation prüfen."
    }
}

function Get-WifiIPv4FromUsb {
    param([Parameter(Mandatory = $true)][string]$UsbSerial)

    Ensure-Adb
    $routeResult = Invoke-AdbNative -Arguments @('-s', $UsbSerial, 'shell', 'ip', 'route')
    if (($routeResult.ExitCode -eq 0) -and (($routeResult.Output | Out-String) -match '(?m)\bsrc\s+(\d{1,3}(?:\.\d{1,3}){3})\b')) {
        return [string]$Matches[1]
    }
    $addressResult = Invoke-AdbNative -Arguments @('-s', $UsbSerial, 'shell', 'ip', '-f', 'inet', 'addr', 'show', 'wlan0')
    if (($addressResult.ExitCode -eq 0) -and (($addressResult.Output | Out-String) -match '(?m)\binet\s+(\d{1,3}(?:\.\d{1,3}){3})/')) {
        return [string]$Matches[1]
    }
    return ''
}

function Reenable-WifiAdb {
    $config = Load-Config
    if ([string]$config.TransportMode -ne 'WiFi') {
        throw 'Diese Einrichtung nutzt kein WLAN-ADB (Android-App oder USB). Eine Reaktivierung ist nicht nötig.'
    }

    Write-Host 'Pixel per USB verbinden, entsperren und USB-Debugging bestätigen.'
    Read-Host 'Danach Eingabetaste drücken' | Out-Null
    $usbDevices = @((Wait-ForAuthorizedUsbPixel))

    $detectedIp = Get-WifiIPv4FromUsb -UsbSerial ([string]$usbDevices[0])
    $currentIp = ([string]$config.WiFiEndpoint -split ':')[0]
    $suggestedIp = if ($detectedIp) { $detectedIp } else { $currentIp }
    $ipInput = Read-Host "Pixel-IP im WLAN [$suggestedIp]"
    $ip = if ([string]::IsNullOrWhiteSpace($ipInput)) { $suggestedIp } else { $ipInput.Trim() }
    if ($ip -notmatch '^\d{1,3}(?:\.\d{1,3}){3}$') { throw 'Ungültige IPv4-Adresse.' }

    $config.WiFiEndpoint = "$ip`:5555"
    $config.UsbSerial = [string]$usbDevices[0]
    $config.Serial = [string]$usbDevices[0]
    Save-JsonAtomic -Value $config -Path $script:ConfigPath
    Enable-WifiAdbFromUsb -UsbSerial ([string]$usbDevices[0]) -Endpoint ([string]$config.WiFiEndpoint)
    Write-Log "WLAN-ADB unter $($config.WiFiEndpoint) aktiviert. Das USB-Kabel kann entfernt werden." 'OK'
}

function Ensure-ConfiguredConnection {
    param([Parameter(Mandatory = $true)]$Config)

    if ([string]$Config.TransportMode -eq 'WiFi') {
        [void](Connect-WifiAdb -Endpoint ([string]$Config.WiFiEndpoint))
    }
}

function Get-AppBatchDirectory {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)][string]$BatchId
    )

    $parent = Join-Path ([string]$Config.StagingRoot) $script:AppBatchFolderName
    return [System.IO.Path]::GetFullPath((Join-Path $parent $BatchId)).TrimEnd('\', '/')
}

function Get-PropertyText {
    param(
        [Parameter(Mandatory = $true)]$Object,
        [Parameter(Mandatory = $true)][string]$Name
    )

    # Vorgemerkte Datensätze aus einer älteren Einrichtung kennen neue Felder
    # nicht; StrictMode würde den Zugriff als Fehler melden.
    if (-not ($Object.PSObject.Properties.Name -contains $Name)) { return '' }
    return [string]$Object.$Name
}

function Copy-ToAppBatch {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)][string]$SourcePath,
        [Parameter(Mandatory = $true)][string]$BatchDirectory,
        [Parameter(Mandatory = $true)][string]$StagedName
    )

    if (-not (Test-Path -LiteralPath $BatchDirectory -PathType Container)) {
        New-Item -ItemType Directory -Path $BatchDirectory -Force | Out-Null
    }

    $source = Get-Item -LiteralPath $SourcePath
    $targetPath = Join-Path $BatchDirectory $StagedName
    $partPath = "$targetPath.part"
    try {
        # Resilio gibt den ganzen Ordner frei. Die Datei läuft erst unter .part
        # mit, damit die Android-App nie ein halbes Medium übernimmt.
        Copy-Item -LiteralPath $SourcePath -Destination $partPath -Force
        $part = Get-Item -LiteralPath $partPath
        if ($part.Length -ne $source.Length) {
            throw "Größenprüfung der Übergabedatei fehlgeschlagen: $StagedName"
        }
        $part.LastWriteTimeUtc = $source.LastWriteTimeUtc
        if (Test-Path -LiteralPath $targetPath) { Remove-Item -LiteralPath $targetPath -Force }
        Move-Item -LiteralPath $partPath -Destination $targetPath
    }
    finally {
        Remove-Item -LiteralPath $partPath -Force -ErrorAction SilentlyContinue
    }
}

function Write-AppBatchMarkers {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)][string]$BatchId,
        [Parameter(Mandatory = $true)]$Entries
    )

    $batchDirectory = Get-AppBatchDirectory -Config $Config -BatchId $BatchId
    $bytes = [long]0
    foreach ($entry in @($Entries)) { $bytes += [long]$entry.Size }

    $manifest = [pscustomobject]@{
        version    = 1
        batchId    = $BatchId
        fileCount  = @($Entries).Count
        bytes      = $bytes
        createdUtc = [DateTime]::UtcNow.ToString('o')
    }
    Save-JsonAtomic -Value $manifest -Path (Join-Path $batchDirectory '_batch-manifest.json') -Depth 5
    'READY' | Set-Content -LiteralPath (Join-Path $batchDirectory '_batch-ready.txt') -Encoding ASCII
}

function Get-ReceiptRemovedPaths {
    param([Parameter(Mandatory = $true)]$Config)

    $paths = [System.Collections.Generic.List[string]]::new()
    $controlRoot = [string]$Config.ControlRoot
    if ([string]::IsNullOrWhiteSpace($controlRoot) -or -not (Test-Path -LiteralPath $controlRoot -PathType Container)) {
        return @($paths)
    }

    foreach ($file in @(Get-ChildItem -LiteralPath $controlRoot -Filter 'receipt-*.json' -File -ErrorAction SilentlyContinue)) {
        try {
            $receipt = Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
        }
        catch {
            Write-Log "Ungültiger Rückbeleg wurde übersprungen: $($file.Name)" 'WARN'
            continue
        }
        if (-not $receipt) { continue }
        if (-not ($receipt.PSObject.Properties.Name -contains 'version')) { continue }
        if (-not ($receipt.PSObject.Properties.Name -contains 'removedPaths')) { continue }
        if ([int]$receipt.version -ne 1) { continue }
        foreach ($path in @($receipt.removedPaths)) {
            if ($path) { $paths.Add(([string]$path).Replace('\', '/')) }
        }
    }
    return @($paths)
}

function Remove-AppBatchDirectory {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)][string]$BatchId
    )

    $parent = [System.IO.Path]::GetFullPath((Join-Path ([string]$Config.StagingRoot) $script:AppBatchFolderName)).TrimEnd('\', '/')
    $target = Get-AppBatchDirectory -Config $Config -BatchId $BatchId
    $parentUri = $parent.Replace('\', '/') + '/'
    $targetUri = $target.Replace('\', '/')
    if (-not $targetUri.StartsWith($parentUri, [StringComparison]::OrdinalIgnoreCase) -or
        ([System.IO.Path]::GetFileName($target) -ne $BatchId)) {
        throw 'Interne Sicherheitsprüfung des Batchordners fehlgeschlagen.'
    }
    if (Test-Path -LiteralPath $target) {
        Remove-Item -LiteralPath $target -Recurse -Force
        Write-Log "Abgeschlossenen Batchordner entfernt: $target" 'OK'
    }
}

function Add-BatchEntry {
    param(
        [Parameter(Mandatory = $true)][hashtable]$Map,
        [Parameter(Mandatory = $true)][AllowEmptyString()][string]$BatchId,
        [Parameter(Mandatory = $true)]$Entry
    )

    if ([string]::IsNullOrWhiteSpace($BatchId)) { return }
    if (-not $Map.ContainsKey($BatchId)) {
        $Map[$BatchId] = [System.Collections.Generic.List[object]]::new()
    }
    $Map[$BatchId].Add($Entry)
}

function Shrink-AppBatchDirectory {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)][string]$BatchId,
        [Parameter(Mandatory = $true)]$Confirmed,
        [Parameter(Mandatory = $true)]$Remaining
    )

    $batchDirectory = (Get-AppBatchDirectory -Config $Config -BatchId $BatchId).TrimEnd('\', '/')
    if (-not (Test-Path -LiteralPath $batchDirectory -PathType Container)) { return }

    foreach ($entry in @($Confirmed)) {
        $stagedName = [string]$entry.StagedName
        if ([string]::IsNullOrWhiteSpace($stagedName)) { continue }
        $stagedPath = [System.IO.Path]::GetFullPath((Join-Path $batchDirectory $stagedName))
        if (-not $stagedPath.StartsWith($batchDirectory + [System.IO.Path]::DirectorySeparatorChar,
            [StringComparison]::OrdinalIgnoreCase)) {
            throw 'Interne Sicherheitsprüfung der Übergabedatei fehlgeschlagen.'
        }
        if (Test-Path -LiteralPath $stagedPath -PathType Leaf) { Remove-Item -LiteralPath $stagedPath -Force }
    }

    # Das Pixel hält einen Batch nur für vollständig, wenn sein Inhalt zum Manifest passt.
    # Blieben Dateien zurück, muss also die eigene Übergabekopie schrumpfen und das Manifest
    # neu geschrieben werden — sonst sieht die App einen halbleeren Ordner als halbfertige
    # Übertragung an und bietet die Restdateien nie wieder an.
    Write-AppBatchMarkers -Config $Config -BatchId $BatchId -Entries @($Remaining)
    Write-Log ("Batch {0} auf {1:N0} verbliebene Dateien geschrumpft; das Pixel bietet sie erneut an." -f
        $BatchId, @($Remaining).Count) 'OK'
}

function Confirm-AppStagedBatches {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)]$CompletionSets
    )

    $staged = @(Load-Staged)
    if ($staged.Count -eq 0) { return 0 }

    $removedPaths = @(Get-ReceiptRemovedPaths -Config $Config)
    if ($removedPaths.Count -eq 0) { return 0 }

    $remaining = [System.Collections.Generic.List[object]]::new()
    $confirmedEntriesPerBatch = @{}
    $unconfirmedEntriesPerBatch = @{}
    $completedNow = 0
    foreach ($entry in $staged) {
        $batchId = Get-PropertyText -Object $entry -Name 'BatchId'
        $suffix = Get-PropertyText -Object $entry -Name 'PixelSuffix'
        if ([string]::IsNullOrWhiteSpace($suffix)) {
            Write-Log "Vorgemerkte Datei stammt aus einem ADB-Lauf und bleibt ungeklärt: $($entry.RelativePath)" 'ERROR'
            $remaining.Add($entry)
            Add-BatchEntry -Map $unconfirmedEntriesPerBatch -BatchId $batchId -Entry $entry
            continue
        }

        $confirmed = $false
        foreach ($path in $removedPaths) {
            if ($path.EndsWith($suffix, [StringComparison]::OrdinalIgnoreCase)) { $confirmed = $true; break }
        }

        if (-not $confirmed) {
            $remaining.Add($entry)
            Add-BatchEntry -Map $unconfirmedEntriesPerBatch -BatchId $batchId -Entry $entry
            continue
        }

        Add-Completion -Entry $entry -CompletionSets $CompletionSets -Reason 'Android-Rückbeleg nach bestätigter Google-Fotos-Freigabe'
        $completedNow++
        Add-BatchEntry -Map $confirmedEntriesPerBatch -BatchId $batchId -Entry $entry
    }

    Save-Staged -Entries $remaining
    if ($completedNow -gt 0) {
        Write-Log ("{0:N0} Dateien durch Android-Rückbelege bestätigt." -f $completedNow) 'OK'
    }
    foreach ($batchId in @($confirmedEntriesPerBatch.Keys)) {
        if (-not $unconfirmedEntriesPerBatch.ContainsKey($batchId)) {
            Remove-AppBatchDirectory -Config $Config -BatchId $batchId
            continue
        }
        Shrink-AppBatchDirectory -Config $Config -BatchId $batchId `
            -Confirmed @($confirmedEntriesPerBatch[$batchId]) -Remaining @($unconfirmedEntriesPerBatch[$batchId])
    }
    if ($remaining.Count -gt 0) {
        Write-Log ("{0:N0} Dateien warten weiterhin auf ihren Android-Rückbeleg." -f $remaining.Count)
    }
    return $completedNow
}

function Repair-AppBatches {
    param([Parameter(Mandatory = $true)]$Config)

    $staged = @(Load-Staged)
    $byBatch = @{}
    foreach ($entry in $staged) {
        $batchId = Get-PropertyText -Object $entry -Name 'BatchId'
        if ([string]::IsNullOrWhiteSpace($batchId)) { continue }
        if (-not $byBatch.ContainsKey($batchId)) {
            $byBatch[$batchId] = [System.Collections.Generic.List[object]]::new()
        }
        $byBatch[$batchId].Add($entry)
    }

    $changed = $false
    foreach ($batchId in @($byBatch.Keys)) {
        $entries = @($byBatch[$batchId])
        $batchDirectory = Get-AppBatchDirectory -Config $Config -BatchId $batchId
        foreach ($entry in $entries) {
            $stagedPath = Join-Path $batchDirectory ([string]$entry.StagedName)
            $needsCopy = ($entry.State -ne 'Staged') -or (-not (Test-Path -LiteralPath $stagedPath -PathType Leaf))
            if (-not $needsCopy) { continue }

            $sourcePath = Join-Path ([string]$Config.SourceRoot) ([string]$entry.RelativePath)
            if (-not (Test-Path -LiteralPath $sourcePath -PathType Leaf)) {
                throw "Batchübergabe kann nicht fortgesetzt werden; Quelle fehlt: $sourcePath"
            }
            Copy-ToAppBatch -Config $Config -SourcePath $sourcePath -BatchDirectory $batchDirectory -StagedName ([string]$entry.StagedName)
            $entry.State = 'Staged'
            $entry.StagedUtc = [DateTime]::UtcNow.ToString('o')
            $changed = $true
            Write-Log "Übergabedatei erneut bereitgestellt: $($entry.RelativePath)" 'OK'
        }

        $manifestPath = Join-Path $batchDirectory '_batch-manifest.json'
        $readyPath = Join-Path $batchDirectory '_batch-ready.txt'
        if ((Test-Path -LiteralPath $manifestPath -PathType Leaf) -and (Test-Path -LiteralPath $readyPath -PathType Leaf)) { continue }

        $allEntriesStaged = $true
        foreach ($entry in $entries) { if ($entry.State -ne 'Staged') { $allEntriesStaged = $false } }
        if ($allEntriesStaged) {
            Write-AppBatchMarkers -Config $Config -BatchId $batchId -Entries $entries
            Write-Log ("Batch {0} liegt vollständig im Übergabeordner." -f $batchId) 'OK'
        }
    }

    if ($changed) { Save-Staged -Entries $staged }
}

function Invoke-AppPreflight {
    param([Parameter(Mandatory = $true)]$Config)

    $stagingRoot = [string]$Config.StagingRoot
    $controlRoot = [string]$Config.ControlRoot
    if ([string]::IsNullOrWhiteSpace($stagingRoot) -or [string]::IsNullOrWhiteSpace($controlRoot)) {
        throw 'Für die Android-App fehlen Übergabe- oder Kontrollordner. Bitte die Einrichtung erneut ausführen.'
    }
    foreach ($path in @($stagingRoot, $controlRoot)) {
        if (-not (Test-Path -LiteralPath $path -PathType Container)) {
            throw "Ordner der Android-App-Übertragung fehlt: $path"
        }
    }

    $probePath = Join-Path $stagingRoot ('.ppu-write-probe-' + [Guid]::NewGuid().ToString('N'))
    try {
        'probe' | Set-Content -LiteralPath $probePath -Encoding ASCII
    }
    finally {
        Remove-Item -LiteralPath $probePath -Force -ErrorAction SilentlyContinue
    }

    $batchParent = Join-Path $stagingRoot $script:AppBatchFolderName
    if (-not (Test-Path -LiteralPath $batchParent -PathType Container)) {
        New-Item -ItemType Directory -Path $batchParent -Force | Out-Null
    }

    $batchCount = @(Get-ChildItem -LiteralPath $batchParent -Directory -ErrorAction SilentlyContinue).Count
    $receiptCount = @(Get-ChildItem -LiteralPath $controlRoot -Filter 'receipt-*.json' -File -ErrorAction SilentlyContinue).Count
    Write-Log ("Übergabeordner schreibt bereit ($stagingRoot); $batchCount Batchordner vorhanden, $receiptCount Rückbelege eingetroffen.") 'OK'
    if ($receiptCount -eq 0) {
        Write-Log 'Noch kein Rückbeleg synchronisiert. Läuft die App „Pixel Photo Companion“ auf dem Pixel und empfängt Resilio den Kontrollordner?' 'WARN'
    }
}

function Assert-DeviceReady {
    param([Parameter(Mandatory = $true)]$Config)

    if (Test-AppTransport -Config $Config) {
        foreach ($path in @([string]$Config.StagingRoot, [string]$Config.ControlRoot)) {
            if (-not (Test-Path -LiteralPath $path -PathType Container)) {
                throw "Ordner der Android-App-Übertragung ist nicht erreichbar: $path"
            }
        }
        return
    }

    Ensure-ConfiguredConnection -Config $Config
    $state = Invoke-Adb -Config $Config -Arguments @('get-state') -AllowFailure
    if ($state -notmatch 'device') {
        throw 'Pixel nicht per ADB erreichbar. USB-Kabel, USB-Debugging und die Freigabe auf dem Pixel prüfen.'
    }

    $device = Invoke-Adb -Config $Config -Arguments @('shell', 'getprop ro.product.device')
    if ($device.Trim() -ne 'sailfish') {
        throw "Verbundenes Gerät ist kein kleines Pixel (2016/sailfish), sondern: $device"
    }
}

function Test-DeviceLocked {
    param([Parameter(Mandatory = $true)]$Config)

    $policy = Invoke-Adb -Config $Config -Arguments @('shell', 'dumpsys window policy') -AllowFailure
    if ($policy -match '(?i)(isStatusBarKeyguard|mShowingLockscreen|keyguardShowing)\s*[=:]\s*true') {
        return $true
    }
    $window = Invoke-Adb -Config $Config -Arguments @('shell', 'dumpsys window') -AllowFailure
    return ($window -match '(?i)(mDreamingLockscreen|mShowingLockscreen|keyguardShowing)\s*[=:]\s*true')
}

function Assert-DeviceUnlocked {
    param([Parameter(Mandatory = $true)]$Config)

    [void](Invoke-Adb -Config $Config -Arguments @('shell', 'input', 'keyevent', 'KEYCODE_WAKEUP') -AllowFailure)
    [void](Invoke-Adb -Config $Config -Arguments @('shell', 'wm', 'dismiss-keyguard') -AllowFailure)
    Start-Sleep -Seconds 1
    if (([bool]$Config.RequireUnlocked) -and (Test-DeviceLocked -Config $Config)) {
        throw 'Das Pixel ist gesperrt. Einmal manuell entsperren; die PIN wird aus Sicherheitsgründen nicht gespeichert oder automatisch eingegeben.'
    }
}

function Quote-AndroidShell {
    param([Parameter(Mandatory = $true)][string]$Text)
    $singleQuote = [string][char]39
    $doubleQuote = [string][char]34
    $quoteBreak = $singleQuote + $doubleQuote + $singleQuote + $doubleQuote + $singleQuote
    return $singleQuote + $Text.Replace($singleQuote, $quoteBreak) + $singleQuote
}

function Get-DeviceFreeBytes {
    param([Parameter(Mandatory = $true)]$Config)

    $df = Invoke-Adb -Config $Config -Arguments @('shell', 'df -k /sdcard')
    foreach ($line in @($df -split "`r?`n") | Select-Object -Last 3) {
        $parts = @($line.Trim() -split '\s+')
        if (($parts.Count -ge 6) -and ($parts[3] -match '^\d+$')) {
            return ([long]$parts[3] * 1024L)
        }
    }
    throw "Freien Pixel-Speicher konnte ich nicht auslesen: $df"
}

function Test-RemoteFile {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)][string]$RemotePath,
        [long]$ExpectedSize = -1
    )

    $quoted = Quote-AndroidShell $RemotePath
    $sizeText = Invoke-Adb -Config $Config -Arguments @('shell', "if [ -f $quoted ]; then stat -c %s $quoted; else echo MISSING; fi") -AllowFailure
    if ($sizeText -match 'MISSING') { return $false }
    if (($ExpectedSize -ge 0) -and ($sizeText.Trim() -ne [string]$ExpectedSize)) { return $false }
    return ($sizeText.Trim() -match '^\d+$')
}

function Get-RemoteFileSet {
    param([Parameter(Mandatory = $true)]$Config)

    $set = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
    $quotedRoot = Quote-AndroidShell ([string]$Config.RemoteRoot)
    $output = Invoke-Adb -Config $Config -Arguments @('shell', "if [ -d $quotedRoot ]; then find $quotedRoot -type f -print; fi") -AllowFailure
    foreach ($line in @($output -split "`r?`n")) {
        $path = $line.TrimEnd()
        if ($path.StartsWith('/')) { [void]$set.Add($path) }
    }
    return $set
}

function Get-RemoteMediaSnapshot {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)][string]$Root
    )

    $items = [System.Collections.Generic.List[object]]::new()
    $quotedRoot = Quote-AndroidShell $Root
    $command = "if [ -d $quotedRoot ]; then find $quotedRoot -type f -print | while IFS= read -r f; do case `"`$f`" in */.sync/*|*.!sync) continue;; esac; stat -c '%s|%Y|%n' `"`$f`"; done; fi"
    $output = Invoke-Adb -Config $Config -Arguments @('shell', $command) -AllowFailure
    foreach ($line in @($output -split "`r?`n")) {
        if ($line -match '^(\d+)\|(\d+)\|(/.*)$') {
            if (-not (Test-SupportedMedia -Path ([string]$Matches[3]))) { continue }
            $items.Add([pscustomobject]@{
                Size  = [long]$Matches[1]
                MTime = [long]$Matches[2]
                Path  = [string]$Matches[3]
            })
        }
    }
    return @($items)
}

function Load-ResilioState {
    if (-not (Test-Path -LiteralPath $script:ResilioStatePath)) { return @() }
    $raw = Get-Content -LiteralPath $script:ResilioStatePath -Raw -Encoding UTF8
    if ([string]::IsNullOrWhiteSpace($raw)) { return @() }
    return @($raw | ConvertFrom-Json)
}

function Save-ResilioState {
    param([Parameter(Mandatory = $true)]$Entries)
    Save-JsonAtomic -Value @($Entries) -Path $script:ResilioStatePath -Depth 6
}

function Update-ResilioState {
    param([Parameter(Mandatory = $true)]$Config)

    if (-not [bool]$Config.ResilioEnabled) { return @() }
    $root = [string]$Config.ResilioRemoteRoot
    $snapshot = @(Get-RemoteMediaSnapshot -Config $Config -Root $root)
    $previousByPath = @{}
    foreach ($old in @(Load-ResilioState)) { $previousByPath[[string]$old.Path] = $old }

    $nowEpoch = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    $stableSeconds = [long]([double]$Config.StableMinutes * 60)
    $next = [System.Collections.Generic.List[object]]::new()
    $ready = [System.Collections.Generic.List[object]]::new()

    foreach ($item in $snapshot) {
        $firstSeen = $nowEpoch
        $mediaScanned = $false
        if ($previousByPath.ContainsKey([string]$item.Path)) {
            $old = $previousByPath[[string]$item.Path]
            if (([long]$old.Size -eq [long]$item.Size) -and ([long]$old.MTime -eq [long]$item.MTime)) {
                $firstSeen = [long]$old.FirstSeen
                $mediaScanned = [bool]$old.MediaScanned
            }
        }

        $stable = (($nowEpoch - $firstSeen) -ge $stableSeconds) -and (($nowEpoch - [long]$item.MTime) -ge $stableSeconds)
        if ($stable -and (-not $mediaScanned)) {
            Send-MediaScan -Config $Config -RemotePath ([string]$item.Path)
            $mediaScanned = $true
            Write-Log "Vollständig empfangene Resilio-Datei beim Android-Medienscanner angemeldet: $($item.Path)" 'OK'
        }

        $record = [pscustomobject]@{
            Path         = [string]$item.Path
            Size         = [string]$item.Size
            MTime        = [string]$item.MTime
            FirstSeen    = [string]$firstSeen
            MediaScanned = [bool]$mediaScanned
        }
        $next.Add($record)
        if ($mediaScanned) { $ready.Add($record) }
    }

    Save-ResilioState -Entries $next
    return @($ready)
}

function Convert-SnapshotToPathSet {
    param([Parameter(Mandatory = $true)]$Snapshot)
    $set = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
    foreach ($item in @($Snapshot)) { [void]$set.Add([string]$item.Path) }
    return $set
}

function Send-MediaScan {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)][string]$RemotePath
    )

    $encodedSegments = [System.Collections.Generic.List[string]]::new()
    foreach ($segment in @($RemotePath -split '/')) {
        if ($segment.Length -gt 0) {
            $encodedSegments.Add([System.Uri]::EscapeDataString($segment))
        }
    }
    $uri = 'file:///' + ($encodedSegments -join '/')
    [void](Invoke-Adb -Config $Config -Arguments @('shell', 'am', 'broadcast', '-a', 'android.intent.action.MEDIA_SCANNER_SCAN_FILE', '-d', $uri) -AllowFailure)
}

function Get-RemotePathForEntry {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)]$Entry,
        [Parameter(Mandatory = $true)][string]$BatchId
    )

    $parent = Split-Path -Parent ([string]$Entry.RelativePath)
    $parentHash = (Get-TextSha256 $parent).Substring(0, 12)
    $fileName = Split-Path -Leaf ([string]$Entry.RelativePath)
    return ('{0}/{1}/{2}/{3}' -f ([string]$Config.RemoteRoot).TrimEnd('/'), $BatchId, $parentHash, $fileName)
}

function Ensure-EntryHash {
    param(
        [Parameter(Mandatory = $true)]$Entry,
        [Parameter(Mandatory = $true)]$Config
    )

    $fullPath = Join-Path ([string]$Config.SourceRoot) ([string]$Entry.RelativePath)
    if (-not (Test-Path -LiteralPath $fullPath -PathType Leaf)) { return $false }

    $file = Get-Item -LiteralPath $fullPath
    $currentLastWrite = $file.LastWriteTimeUtc.ToString('o')
    $currentFingerprint = Get-Fingerprint -RelativePath ([string]$Entry.RelativePath) -Size $file.Length -LastWriteUtc $currentLastWrite
    if ($currentFingerprint -ne [string]$Entry.Fingerprint) {
        Write-Log "Datei hat sich während der Verarbeitung geändert und wird später neu katalogisiert: $($Entry.RelativePath)" 'WARN'
        return $false
    }

    if ([string]::IsNullOrWhiteSpace([string]$Entry.Sha256)) {
        Write-Log "Prüfsumme: $($Entry.RelativePath)"
        $Entry.Sha256 = Get-FileSha256 -Path $fullPath
    }
    return $true
}

function Read-NumberInRange {
    param(
        [Parameter(Mandatory = $true)][string]$Question,
        [Parameter(Mandatory = $true)][double]$Default,
        [Parameter(Mandatory = $true)][double]$Minimum,
        [Parameter(Mandatory = $true)][double]$Maximum
    )

    # Komma und Punkt werden beide verstanden; eine leere Eingabe bleibt die Vorgabe.
    while ($true) {
        $answer = Read-Host ('{0} [{1}], möglich {2} bis {3}' -f $Question, $Default, $Minimum, $Maximum)
        if ([string]::IsNullOrWhiteSpace($answer)) { return $Default }
        $value = [double]0
        if (-not [double]::TryParse($answer.Trim().Replace(',', '.'), [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$value)) {
            Write-Host 'Bitte eine Zahl angeben, zum Beispiel 5.'
            continue
        }
        if ($value -lt $Minimum -or $value -gt $Maximum) {
            Write-Host ('Der Wert muss zwischen {0} und {1} liegen.' -f $Minimum, $Maximum)
            continue
        }
        return $value
    }
}

function Get-BatchCapacityBytes {
    param([Parameter(Mandatory = $true)]$Config)

    # Eine per Hand eingetragene Zahl kann außerhalb der Spanne liegen; dann gilt die
    # Spanne, sonst baut ein Wert wie 0 gar keinen Batch mehr und keiner sagt etwas.
    $giB = Get-ClampedValue -Value ([double]$Config.BatchGiB) -Minimum $script:MinBatchGiB -Maximum $script:MaxBatchGiB
    return [long]($giB * 1GB)
}

function Get-StableMinutesFromSeconds {
    param([Parameter(Mandatory = $true)][double]$Seconds)

    # Einrichtung und Fenster rechnen in Sekunden, die Zustandsdatei bleibt bei Minuten.
    return (Get-ClampedValue -Value $Seconds -Minimum 0 -Maximum $script:MaxStableSeconds) / 60
}

function Select-AndStageBatch {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)]$CompletionSets
    )

    $catalog = @(Load-Catalog)
    $staged = @(Load-Staged)
    $stagedFingerprints = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($entry in $staged) { [void]$stagedFingerprints.Add([string]$entry.Fingerprint) }

    $isAppBatch = Test-AppTransport -Config $Config
    if ($isAppBatch -and $staged.Count -gt 0) {
        Write-Log 'Der laufende Batch wartet noch auf seinen Android-Rückbeleg; es wird kein weiterer Batch übergeben.'
        return 0
    }

    $configuredBatchBytes = Get-BatchCapacityBytes -Config $Config
    if ($isAppBatch) {
        $capacity = $configuredBatchBytes
    }
    else {
        $freeBytes = Get-DeviceFreeBytes -Config $Config
        $reserveBytes = [long]([double]$Config.ReserveGiB * 1GB)
        $capacity = [Math]::Min($configuredBatchBytes, ($freeBytes - $reserveBytes))
        if ($capacity -lt 256MB) {
            Write-Log ("Zu wenig freier Pixel-Speicher für einen neuen Batch: {0:N2} GiB frei." -f ($freeBytes / 1GB)) 'WARN'
            return 0
        }
    }

    $selected = [System.Collections.Generic.List[object]]::new()
    $selectedBytes = [long]0
    $catalogChanged = $false

    foreach ($entry in @($catalog | Sort-Object @{ Expression = { [DateTime]$_.LastWriteUtc }; Descending = $true }, @{ Expression = { [string]$_.RelativePath } })) {
        if ([string]$entry.Stable -ne 'True') { continue }
        if ($CompletionSets.Fingerprints.Contains([string]$entry.Fingerprint)) { continue }
        if ($stagedFingerprints.Contains([string]$entry.Fingerprint)) { continue }

        $size = [long]$entry.Size
        if ($size -gt $capacity) {
            Write-Log "Einzeldatei ist größer als die verfügbare Batchgröße und wird übersprungen: $($entry.RelativePath)" 'WARN'
            continue
        }
        if (($selectedBytes + $size) -gt $capacity) { continue }

        if (-not (Ensure-EntryHash -Entry $entry -Config $Config)) { continue }
        $catalogChanged = $true

        if ($CompletionSets.Hashes.Contains([string]$entry.Sha256)) {
            Add-Completion -Entry $entry -CompletionSets $CompletionSets -Reason 'Identischer Inhalt bereits abgeschlossen'
            Write-Log "Bereits erledigter Inhalt unter neuem Pfad erkannt: $($entry.RelativePath)" 'OK'
            continue
        }

        $selected.Add($entry)
        $selectedBytes += $size
    }

    if ($catalogChanged) { Save-Catalog -Entries $catalog }
    if ($selected.Count -eq 0) { return 0 }

    $batchId = [DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss')
    Write-Log ("Übertrage Batch mit {0:N0} Dateien und {1:N2} GiB." -f $selected.Count, ($selectedBytes / 1GB))

    $batchDirectory = ''
    if ($isAppBatch) {
        $batchDirectory = Get-AppBatchDirectory -Config $Config -BatchId $batchId
    }

    $index = 0
    foreach ($entry in $selected) {
        $index++
        $sourcePath = Join-Path ([string]$Config.SourceRoot) ([string]$entry.RelativePath)
        $remotePath = ''
        $remoteDir = ''
        $stagedName = ''
        $pixelSuffix = ''
        if ($isAppBatch) {
            $extension = [System.IO.Path]::GetExtension([string]$entry.RelativePath).ToLowerInvariant()
            $stagedName = ('{0:D6}-{1}{2}' -f $index, ([string]$entry.Fingerprint).Substring(0, 12), $extension)
            $pixelSuffix = '/{0}/{1}/{2}' -f $script:AppBatchFolderName, $batchId, $stagedName
            $remotePath = $pixelSuffix
        }
        else {
            $remotePath = Get-RemotePathForEntry -Config $Config -Entry $entry -BatchId $batchId
            $remoteDir = $remotePath.Substring(0, $remotePath.LastIndexOf('/'))
        }
        $record = [pscustomobject]@{
            Fingerprint  = [string]$entry.Fingerprint
            Sha256       = [string]$entry.Sha256
            RelativePath = [string]$entry.RelativePath
            Size         = [string]$entry.Size
            RemotePath   = $remotePath
            BatchId      = $batchId
            StagedName   = $stagedName
            PixelSuffix  = $pixelSuffix
            State        = 'Copying'
            StagedUtc    = ''
        }

        $staged += $record
        Save-Staged -Entries $staged

        try {
            if ($isAppBatch) {
                Write-Log "Gebe über den Resilio-Übergabeordner weiter: $($entry.RelativePath)"
                Copy-ToAppBatch -Config $Config -SourcePath $sourcePath -BatchDirectory $batchDirectory -StagedName $stagedName
            }
            else {
                $quotedDir = Quote-AndroidShell $remoteDir
                [void](Invoke-Adb -Config $Config -Arguments @('shell', "mkdir -p $quotedDir"))
                Write-Log "Kopiere: $($entry.RelativePath)"
                [void](Invoke-Adb -Config $Config -Arguments @('push', '-a', $sourcePath, $remotePath))

                if (-not (Test-RemoteFile -Config $Config -RemotePath $remotePath -ExpectedSize ([long]$entry.Size))) {
                    throw 'Größenprüfung der übertragenen Datei fehlgeschlagen.'
                }

                Send-MediaScan -Config $Config -RemotePath $remotePath
            }

            $record.State = 'Staged'
            $record.StagedUtc = [DateTime]::UtcNow.ToString('o')
            Save-Staged -Entries $staged
        }
        catch {
            Write-Log "Übertragung fehlgeschlagen ($($entry.RelativePath)): $($_.Exception.Message)" 'ERROR'
            throw
        }
    }

    if ($isAppBatch) {
        Write-AppBatchMarkers -Config $Config -BatchId $batchId -Entries $selected
        Write-Log "Batch im Übergabeordner bereitgestellt: $batchDirectory" 'OK'
        return $selected.Count
    }

    Write-Log 'Batch vollständig auf das Pixel übertragen und beim Medienscanner angemeldet.' 'OK'
    return $selected.Count
}

function Wake-AndOpenPhotos {
    param([Parameter(Mandatory = $true)]$Config)

    Assert-DeviceUnlocked -Config $Config
    [void](Invoke-Adb -Config $Config -Arguments @('shell', 'monkey', '-p', 'com.google.android.apps.photos', '-c', 'android.intent.category.LAUNCHER', '1') -AllowFailure)
    Start-Sleep -Seconds 4
}

function Reset-PhotosToHome {
    param([Parameter(Mandatory = $true)]$Config)

    [void](Invoke-Adb -Config $Config -Arguments @('shell', 'am', 'force-stop', 'com.google.android.apps.photos') -AllowFailure)
    Start-Sleep -Seconds 1
    Wake-AndOpenPhotos -Config $Config
}

function Get-ScreenSize {
    param([Parameter(Mandatory = $true)]$Config)
    $sizeText = Invoke-Adb -Config $Config -Arguments @('shell', 'wm', 'size')
    if ($sizeText -match '(\d+)x(\d+)') {
        return [pscustomobject]@{ Width = [int]$Matches[1]; Height = [int]$Matches[2] }
    }
    return [pscustomobject]@{ Width = 1080; Height = 1920 }
}

function Get-UiNodes {
    param([Parameter(Mandatory = $true)]$Config)

    Remove-Item -LiteralPath $script:UiDumpLocalPath -Force -ErrorAction SilentlyContinue
    [void](Invoke-Adb -Config $Config -Arguments @('shell', 'uiautomator', 'dump', '--compressed', $script:UiDumpDevicePath) -AllowFailure)
    [void](Invoke-Adb -Config $Config -Arguments @('pull', $script:UiDumpDevicePath, $script:UiDumpLocalPath) -AllowFailure)
    if (-not (Test-Path -LiteralPath $script:UiDumpLocalPath)) { return @() }

    try {
        [xml]$xml = Get-Content -LiteralPath $script:UiDumpLocalPath -Raw -Encoding UTF8
        return @($xml.SelectNodes('//node'))
    }
    catch {
        return @()
    }
}

function Get-UiText {
    param([Parameter(Mandatory = $true)]$Nodes)
    $values = [System.Collections.Generic.List[string]]::new()
    foreach ($node in @($Nodes)) {
        if ($node.text) { $values.Add([string]$node.text) }
        if ($node.'content-desc') { $values.Add([string]$node.'content-desc') }
    }
    return ($values -join "`n")
}

function Get-BoundsCenter {
    param([Parameter(Mandatory = $true)][string]$Bounds)
    if ($Bounds -match '^\[(\d+),(\d+)\]\[(\d+),(\d+)\]$') {
        return [pscustomobject]@{
            X = [int](('0' + $Matches[1])) + [int](([int]$Matches[3] - [int]$Matches[1]) / 2)
            Y = [int](('0' + $Matches[2])) + [int](([int]$Matches[4] - [int]$Matches[2]) / 2)
        }
    }
    return $null
}

function Tap-UiNode {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)]$Node
    )
    $center = Get-BoundsCenter -Bounds ([string]$Node.bounds)
    if (-not $center) { return $false }
    [void](Invoke-Adb -Config $Config -Arguments @('shell', 'input', 'tap', [string]$center.X, [string]$center.Y) -AllowFailure)
    return $true
}

function Open-PhotosProfile {
    param([Parameter(Mandatory = $true)]$Config)
    $size = Get-ScreenSize -Config $Config
    $x = $size.Width - [Math]::Max(45, [int]($size.Width * 0.05))
    $y = [Math]::Max(55, [int]($size.Height * 0.04))
    [void](Invoke-Adb -Config $Config -Arguments @('shell', 'input', 'tap', [string]$x, [string]$y) -AllowFailure)
    Start-Sleep -Seconds 2
}

function Wait-ForPhotosBackup {
    param([Parameter(Mandatory = $true)]$Config)

    Write-Log 'Warte, bis Google Fotos den Batch vollständig gesichert hat ...'
    Wake-AndOpenPhotos -Config $Config
    $deadline = (Get-Date).AddHours([double]$Config.BackupTimeoutHours)
    $start = Get-Date
    $sawActive = $false
    $completeStreak = 0
    $lastProgressLog = [DateTime]::MinValue

    while ((Get-Date) -lt $deadline) {
        Assert-DeviceUnlocked -Config $Config
        $nodes = @(Get-UiNodes -Config $Config)
        $text = Get-UiText -Nodes $nodes

        if ($text -notmatch '(?i)(Sicherung|Backup|WLAN|Wi-Fi)') {
            Open-PhotosProfile -Config $Config
            $nodes = @(Get-UiNodes -Config $Config)
            $text = Get-UiText -Nodes $nodes
        }

        if ($text -match '(?i)(Sicherung ist deaktiviert|Sicherung deaktiviert|Backup is off|Kontospeicher.*voll|Account storage.*full|Warten auf WLAN|Waiting for Wi-Fi|konnte.*nicht gesichert|couldn.t back up|Backup failed)') {
            throw "Google Fotos meldet einen Sicherungsfehler. Auszug: $($Matches[0])"
        }

        if ($text -match '(?i)(Sicherung läuft|wird gesichert|Sicherung wird vorbereitet|Backing up|Preparing backup|items? left|Elemente? verbleibend)') {
            $sawActive = $true
            $completeStreak = 0
        }
        elseif ($text -match '(?i)(Sicherung abgeschlossen|Backup complete)') {
            $elapsedMinutes = ((Get-Date) - $start).TotalMinutes
            if ($sawActive -or ($elapsedMinutes -ge [double]$Config.ScanGraceMinutes)) {
                $completeStreak++
                if ($completeStreak -ge 2) {
                    Write-Log 'Google Fotos meldet die Sicherung zweimal hintereinander als abgeschlossen.' 'OK'
                    return
                }
            }
        }
        else {
            $completeStreak = 0
        }

        if (((Get-Date) - $lastProgressLog).TotalMinutes -ge 5) {
            Write-Log 'Sicherung läuft beziehungsweise Google Fotos verarbeitet den Batch weiterhin.'
            $lastProgressLog = Get-Date
        }

        [void](Invoke-Adb -Config $Config -Arguments @('shell', 'input', 'keyevent', 'KEYCODE_WAKEUP') -AllowFailure)
        Start-Sleep -Seconds ([int]$Config.BackupPollSeconds)
    }

    throw "Google Fotos wurde nach $($Config.BackupTimeoutHours) Stunden nicht fertig. Es wurde nichts gelöscht."
}

function Invoke-PhotosFreeUpSpace {
    param([Parameter(Mandatory = $true)]$Config)

    Write-Log 'Starte in Google Fotos „Speicherplatz auf diesem Gerät freigeben“ ...'
    Reset-PhotosToHome -Config $Config
    Open-PhotosProfile -Config $Config
    $nodes = @(Get-UiNodes -Config $Config)

    $menuNode = $nodes | Where-Object {
        (([string]$_.text + ' ' + [string]$_.'content-desc') -match '(?i)(Speicherplatz.*freigeben|[0-9]+([.,][0-9]+)?\s*(MB|GB).*freigeben|Free up.*space)')
    } | Select-Object -First 1

    if (-not $menuNode) {
        throw 'Der Menüpunkt „Speicherplatz auf diesem Gerät freigeben“ wurde nicht gefunden. Google-Fotos-Sprache/Oberfläche prüfen.'
    }
    [void](Tap-UiNode -Config $Config -Node $menuNode)
    Start-Sleep -Seconds 4

    $nodes = @(Get-UiNodes -Config $Config)
    $text = Get-UiText -Nodes $nodes
    if ($text -match '(?i)(Nichts freizugeben|Nothing to free up|Kein Speicherplatz freizugeben)') {
        Write-Log 'Google Fotos hat derzeit nichts freizugeben.' 'WARN'
        return
    }

    $confirmCandidates = @($nodes | Where-Object {
        $label = ([string]$_.text + ' ' + [string]$_.'content-desc')
        ($label -match '(?i)([0-9]+([.,][0-9]+)?\s*(KB|MB|GB).*freigeben|freigeben.*[0-9]+([.,][0-9]+)?\s*(KB|MB|GB)|[0-9]+\s+Elemente?.*entfernen|vom Gerät entfernen|Free up\s*[0-9]|Remove from device|Delete from device)') -and
        ($label -notmatch '(?i)(Abbrechen|Cancel)')
    })

    if ($confirmCandidates.Count -eq 0) {
        throw 'Die Bestätigung zum lokalen Freigeben wurde nicht gefunden. Es wurde nichts gelöscht.'
    }

    $confirmNode = $confirmCandidates | Select-Object -Last 1
    [void](Tap-UiNode -Config $Config -Node $confirmNode)
    Start-Sleep -Seconds 8
    Write-Log 'Google Fotos hat den lokalen Freigabevorgang bestätigt.' 'OK'
}

function Confirm-CleanupResults {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)]$CompletionSets,
        [Parameter(Mandatory = $true)]$BeforeCleanupSet
    )

    $staged = @(Load-Staged)
    if ($staged.Count -eq 0) { return 0 }

    $remaining = [System.Collections.Generic.List[object]]::new()
    $completedNow = 0
    $afterCleanupSet = Get-RemoteFileSet -Config $Config
    foreach ($entry in $staged) {
        $remotePath = [string]$entry.RemotePath
        if ($afterCleanupSet.Contains($remotePath)) {
            $remaining.Add($entry)
        }
        elseif ($BeforeCleanupSet.Contains($remotePath)) {
            Add-Completion -Entry $entry -CompletionSets $CompletionSets -Reason 'Von Google Fotos nach bestätigter Sicherung lokal freigegeben'
            $completedNow++
        }
        else {
            # Die Datei fehlte bereits vor unserem Google-Fotos-Freigabevorgang.
            # Sie darf deshalb nicht stillschweigend als hochgeladen gelten.
            $remaining.Add($entry)
            Write-Log "Datei fehlte bereits vor der kontrollierten Freigabe und bleibt ungeklärt: $($entry.RelativePath)" 'ERROR'
        }
    }

    Save-Staged -Entries $remaining
    if ($completedNow -gt 0) {
        Write-Log ("{0:N0} Dateien wurden von Google Fotos sicher lokal entfernt und als abgeschlossen protokolliert." -f $completedNow) 'OK'
    }
    if ($remaining.Count -gt 0) {
        Write-Log ("{0:N0} Dateien blieben lokal erhalten. Sie werden nicht als abgeschlossen markiert und später erneut geprüft." -f $remaining.Count) 'WARN'
    }

    $quotedRoot = Quote-AndroidShell ([string]$Config.RemoteRoot)
    [void](Invoke-Adb -Config $Config -Arguments @('shell', "find $quotedRoot -depth -type d -empty -delete 2>/dev/null") -AllowFailure)
    return $completedNow
}

function Process-StagedFiles {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)]$CompletionSets
    )

    $staged = @(Load-Staged)
    $ready = @($staged | Where-Object { $_.State -eq 'Staged' })
    if ($ready.Count -eq 0) { return 0 }

    $beforeCleanupSet = Get-RemoteFileSet -Config $Config
    foreach ($entry in $ready) {
        if (-not $beforeCleanupSet.Contains([string]$entry.RemotePath)) {
            throw "Eine vorgemerkte Pixel-Datei fehlt schon vor der kontrollierten Freigabe: $($entry.RelativePath). Es wurde nichts als abgeschlossen markiert."
        }
    }

    Wait-ForPhotosBackup -Config $Config
    # Direkt vor dem Klick noch einmal erfassen. Nur der Unterschied zwischen
    # diesem Satz und dem Satz danach darf als Google-bestätigte Bereinigung gelten.
    $beforeCleanupSet = Get-RemoteFileSet -Config $Config
    foreach ($entry in $ready) {
        if (-not $beforeCleanupSet.Contains([string]$entry.RemotePath)) {
            throw "Eine Pixel-Datei verschwand vor dem kontrollierten Freigabeklick: $($entry.RelativePath)."
        }
    }
    Invoke-PhotosFreeUpSpace -Config $Config
    return Confirm-CleanupResults -Config $Config -CompletionSets $CompletionSets -BeforeCleanupSet $beforeCleanupSet
}

function Process-AllPixelMedia {
    param(
        [Parameter(Mandatory = $true)]$Config,
        [Parameter(Mandatory = $true)]$CompletionSets
    )

    if (Test-AppTransport -Config $Config) {
        return Confirm-AppStagedBatches -Config $Config -CompletionSets $CompletionSets
    }

    $staged = @(Load-Staged)
    $readyStaged = @($staged | Where-Object { $_.State -eq 'Staged' })
    $readyResilio = @(Update-ResilioState -Config $Config)
    if (($readyStaged.Count -eq 0) -and ($readyResilio.Count -eq 0)) { return 0 }

    $beforeStagedSet = Get-RemoteFileSet -Config $Config
    foreach ($entry in $readyStaged) {
        if (-not $beforeStagedSet.Contains([string]$entry.RemotePath)) {
            throw "Eine vorgemerkte Pixel-Datei fehlt schon vor der kontrollierten Freigabe: $($entry.RelativePath)."
        }
    }

    Write-Log ("Bereite Google-Fotos-Prüfung vor: {0:N0} Windows-Dateien, {1:N0} Resilio-Dateien." -f $readyStaged.Count, $readyResilio.Count)
    Wait-ForPhotosBackup -Config $Config

    $beforeStagedSet = Get-RemoteFileSet -Config $Config
    $beforeResilioSnapshot = @()
    $beforeResilioSet = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
    if ([bool]$Config.ResilioEnabled) {
        $beforeResilioSnapshot = @(Get-RemoteMediaSnapshot -Config $Config -Root ([string]$Config.ResilioRemoteRoot))
        $beforeResilioSet = Convert-SnapshotToPathSet -Snapshot $beforeResilioSnapshot
    }

    Invoke-PhotosFreeUpSpace -Config $Config
    $completedNow = 0
    if ($readyStaged.Count -gt 0) {
        $completedNow = Confirm-CleanupResults -Config $Config -CompletionSets $CompletionSets -BeforeCleanupSet $beforeStagedSet
    }

    if ([bool]$Config.ResilioEnabled) {
        $afterResilioSnapshot = @(Get-RemoteMediaSnapshot -Config $Config -Root ([string]$Config.ResilioRemoteRoot))
        $afterResilioSet = Convert-SnapshotToPathSet -Snapshot $afterResilioSnapshot
        $removedCount = 0
        $removedBytes = [long]0
        foreach ($item in $beforeResilioSnapshot) {
            if (-not $afterResilioSet.Contains([string]$item.Path)) {
                $removedCount++
                $removedBytes += [long]$item.Size
            }
        }
        if ($removedCount -gt 0) {
            Write-Log ("Google Fotos hat {0:N0} Resilio-Dateien ({1:N2} GiB) lokal freigegeben." -f $removedCount, ($removedBytes / 1GB)) 'OK'
        }
        elseif ($beforeResilioSet.Count -gt 0) {
            Write-Log 'Die Resilio-Dateien blieben lokal erhalten und werden später erneut geprüft.' 'WARN'
        }
        [void](Update-ResilioState -Config $Config)
    }
    return $completedNow
}

function Reconcile-ManualCleanup {
    $config = Load-Config
    if (Test-AppTransport -Config $config) {
        Write-Host 'Im App-Modus gleicht das Programm fortlaufend automatisch mit den Rückbelegen ab.'
        Write-Host 'Diese manuelle Wiederherstellung ist nur für die ADB-Einrichtung vorgesehen.'
        return
    }
    Assert-DeviceReady -Config $config
    $staged = @(Load-Staged)
    if ($staged.Count -eq 0) {
        Write-Host 'Es sind keine vorgemerkten Pixel-Dateien vorhanden.'
        return
    }

    Write-Host ''
    Write-Host 'Diese Wiederherstellung ist nur korrekt, wenn du zuvor in Google Fotos'
    Write-Host '„Speicherplatz auf diesem Gerät freigeben“ verwendet hast.'
    Write-Host 'Ein normales Löschen oder der Papierkorb zählt ausdrücklich nicht.'
    Write-Host ''
    $confirmation = Read-Host 'Zur Bestätigung exakt FREIGEGEBEN eingeben'
    if ($confirmation -cne 'FREIGEGEBEN') {
        Write-Host 'Abgebrochen; der Zustand wurde nicht verändert.'
        return
    }

    $remoteSet = Get-RemoteFileSet -Config $config
    $completionSets = Load-CompletionSets
    $remaining = [System.Collections.Generic.List[object]]::new()
    $completedNow = 0
    foreach ($entry in $staged) {
        if ($remoteSet.Contains([string]$entry.RemotePath)) {
            $remaining.Add($entry)
        }
        else {
            Add-Completion -Entry $entry -CompletionSets $completionSets -Reason 'Vom Benutzer bestätigte Google-Fotos-Freigabe'
            $completedNow++
        }
    }
    Save-Staged -Entries $remaining
    Write-Log ("Manueller Abgleich: {0:N0} fehlende Pixel-Dateien bestätigt; {1:N0} verbleiben lokal." -f $completedNow, $remaining.Count) 'OK'
}

function Repair-InterruptedTransfers {
    param([Parameter(Mandatory = $true)]$Config)

    $staged = @(Load-Staged)
    $changed = $false
    foreach ($entry in $staged) {
        if ($entry.State -ne 'Copying') { continue }

        if (Test-RemoteFile -Config $Config -RemotePath ([string]$entry.RemotePath) -ExpectedSize ([long]$entry.Size)) {
            Send-MediaScan -Config $Config -RemotePath ([string]$entry.RemotePath)
            $entry.State = 'Staged'
            $entry.StagedUtc = [DateTime]::UtcNow.ToString('o')
            $changed = $true
            Write-Log "Unterbrochene, aber vollständige Übertragung wieder aufgenommen: $($entry.RelativePath)" 'OK'
        }
        else {
            $sourcePath = Join-Path ([string]$Config.SourceRoot) ([string]$entry.RelativePath)
            if (-not (Test-Path -LiteralPath $sourcePath -PathType Leaf)) {
                throw "Unterbrochene Übertragung kann nicht fortgesetzt werden; Quelle fehlt: $sourcePath"
            }
            $remoteDir = ([string]$entry.RemotePath).Substring(0, ([string]$entry.RemotePath).LastIndexOf('/'))
            $quotedDir = Quote-AndroidShell $remoteDir
            [void](Invoke-Adb -Config $Config -Arguments @('shell', "mkdir -p $quotedDir"))
            [void](Invoke-Adb -Config $Config -Arguments @('push', '-a', $sourcePath, [string]$entry.RemotePath))
            if (-not (Test-RemoteFile -Config $Config -RemotePath ([string]$entry.RemotePath) -ExpectedSize ([long]$entry.Size))) {
                throw "Fortsetzen der Übertragung fehlgeschlagen: $($entry.RelativePath)"
            }
            Send-MediaScan -Config $Config -RemotePath ([string]$entry.RemotePath)
            $entry.State = 'Staged'
            $entry.StagedUtc = [DateTime]::UtcNow.ToString('o')
            $changed = $true
        }
    }
    if ($changed) { Save-Staged -Entries $staged }
}

function Show-Status {
    $config = Load-Config
    $catalog = @(Load-Catalog)
    $staged = @(Load-Staged)
    $sets = Load-CompletionSets
    $completedCount = $sets.Fingerprints.Count
    $stablePending = @($catalog | Where-Object {
        ([string]$_.Stable -eq 'True') -and
        (-not $sets.Fingerprints.Contains([string]$_.Fingerprint))
    })
    $pendingBytes = [long]0
    foreach ($entry in $stablePending) { $pendingBytes += [long]$entry.Size }

    Write-Host ''
    Write-Host "Pixel Photo Uploader $script:AppVersion"
    if ([bool]$config.ImportEnabled) {
        Write-Host "Dropbox:         $($config.DropboxRoot)"
        Write-Host "OneDrive-Eingang:$($config.InboxRoot)"
    }
    Write-Host "Pixel-Archiv:    $($config.SourceRoot)"
    switch ([string]$config.TransportMode) {
        'App' {
            $receiptCount = @(Get-ChildItem -LiteralPath ([string]$config.ControlRoot) -Filter 'receipt-*.json' -File -ErrorAction SilentlyContinue).Count
            Write-Host "Übertragung:     Android-App + Resilio ($($config.StagingRoot))"
            Write-Host "Rückbelege:      $($config.ControlRoot) ($receiptCount)"
        }
        'WiFi' { Write-Host "Verbindung:      WLAN-ADB $($config.WiFiEndpoint)" }
        default { Write-Host "Verbindung:      USB $($config.Serial)" }
    }
    if ([bool]$config.ResilioEnabled) {
        $resilioState = @(Load-ResilioState)
        Write-Host "Resilio:         aktiv ($($config.ResilioRemoteRoot))"
        Write-Host ("Resilio lokal:   {0:N0} beobachtete Dateien" -f $resilioState.Count)
    }
    else {
        Write-Host 'Resilio:         aus'
    }
    Write-Host ("Katalog:         {0:N0} Dateien" -f $catalog.Count)
    Write-Host ('Batch:           {0:N2} GiB · Stabilität: {1:N0} s · Grundabgleich: alle {2:N0} min' -f (
        Get-ClampedValue -Value ([double]$config.BatchGiB) -Minimum $script:MinBatchGiB -Maximum $script:MaxBatchGiB), (
        Get-ClampedValue -Value ([double]$config.StableMinutes * 60) -Minimum 0 -Maximum $script:MaxStableSeconds), (
        Get-NumberProperty -Object $config -Name 'RescanMinutes' -Default 360))
    Write-Host ("Abgeschlossen:   {0:N0} Fingerabdrücke" -f $completedCount)
    Write-Host ("Auf Pixel:       {0:N0} Dateien" -f $staged.Count)
    Write-Host ("Offen (stabil):  {0:N0} Dateien / {1:N2} GiB" -f $stablePending.Count, ($pendingBytes / 1GB))
    Write-Host "Protokoll:       $script:LogPath"
    Write-Host ''
}

function Run-Preflight {
    $config = Load-Config
    if (Test-AppTransport -Config $config) {
        Invoke-AppPreflight -Config $config
        Write-Log 'Google Fotos steuert die Android-App; das Windows-Programm prüft nur Übergabe und Rückbelege.' 'OK'
        return
    }

    Ensure-Adb
    Assert-DeviceReady -Config $config
    $model = Invoke-Adb -Config $config -Arguments @('shell', 'getprop ro.product.model')
    $android = Invoke-Adb -Config $config -Arguments @('shell', 'getprop ro.build.version.release')
    $free = Get-DeviceFreeBytes -Config $config
    Write-Log "Gerät: $model, Android $android, frei: $([Math]::Round($free / 1GB, 2)) GiB" 'OK'

    Assert-DeviceUnlocked -Config $config
    if ([bool]$config.ResilioEnabled) {
        $quotedResilioRoot = Quote-AndroidShell ([string]$config.ResilioRemoteRoot)
        $resilioDirectory = Invoke-Adb -Config $config -Arguments @('shell', "if [ -d $quotedResilioRoot ]; then echo READY; else echo MISSING; fi") -AllowFailure
        if ($resilioDirectory -notmatch 'READY') {
            throw "Resilio-Zielordner fehlt auf dem Pixel: $($config.ResilioRemoteRoot)"
        }
    }

    Reset-PhotosToHome -Config $config
    Open-PhotosProfile -Config $config
    $text = Get-UiText -Nodes @(Get-UiNodes -Config $config)
    if ($text -notmatch '(?i)(Sicherung|Backup)') {
        throw 'Google-Fotos-Sicherungsstatus konnte nicht gelesen werden. Pixel entsperren und Google Fotos auf Deutsch oder Englisch verwenden.'
    }
    if ($text -notmatch '(?i)(Speicherplatz.*freigeben|[0-9]+([.,][0-9]+)?\s*(MB|GB).*freigeben|Free up.*space)') {
        throw 'Google-Fotos-Menüpunkt zum lokalen Freigeben wurde nicht erkannt.'
    }
    Write-Log 'Google-Fotos-Oberfläche und Freigabe-Menü wurden erkannt.' 'OK'
}

function Select-FolderPath {
    param(
        [Parameter(Mandatory = $true)][string]$Description,
        [bool]$AllowCreate = $false
    )

    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = $Description
    $dialog.ShowNewFolderButton = $AllowCreate
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        return ''
    }

    $path = (Get-Item -LiteralPath $dialog.SelectedPath).FullName
    if ($path.Length -gt 3) { $path = $path.TrimEnd('\') }
    return $path
}

function Assert-SeparatePipelineFolders {
    param(
        [Parameter(Mandatory = $true)][string]$DropboxRoot,
        [Parameter(Mandatory = $true)][string]$InboxRoot,
        [Parameter(Mandatory = $true)][string]$ArchiveRoot,
        [string]$StagingRoot = '',
        [string]$ControlRoot = ''
    )

    $folders = @(
        [pscustomobject]@{ Name = 'Dropbox'; Path = [System.IO.Path]::GetFullPath($DropboxRoot).TrimEnd('\') },
        [pscustomobject]@{ Name = 'OneDrive-Eingang'; Path = [System.IO.Path]::GetFullPath($InboxRoot).TrimEnd('\') },
        [pscustomobject]@{ Name = 'Pixel-Archiv'; Path = [System.IO.Path]::GetFullPath($ArchiveRoot).TrimEnd('\') }
    )
    if (-not [string]::IsNullOrWhiteSpace($StagingRoot)) {
        $folders += [pscustomobject]@{ Name = 'Resilio-Übergabe'; Path = [System.IO.Path]::GetFullPath($StagingRoot).TrimEnd('\') }
    }
    if (-not [string]::IsNullOrWhiteSpace($ControlRoot)) {
        $folders += [pscustomobject]@{ Name = 'Rückbeleg-Kontrollordner'; Path = [System.IO.Path]::GetFullPath($ControlRoot).TrimEnd('\') }
    }
    for ($left = 0; $left -lt $folders.Count; $left++) {
        for ($right = $left + 1; $right -lt $folders.Count; $right++) {
            $a = [string]$folders[$left].Path
            $b = [string]$folders[$right].Path
            $aPrefix = $a + '\'
            $bPrefix = $b + '\'
            if ($a.Equals($b, [StringComparison]::OrdinalIgnoreCase) -or
                $a.StartsWith($bPrefix, [StringComparison]::OrdinalIgnoreCase) -or
                $b.StartsWith($aPrefix, [StringComparison]::OrdinalIgnoreCase)) {
                throw "Die Ordner '$($folders[$left].Name)' und '$($folders[$right].Name)' dürfen nicht gleich oder ineinander verschachtelt sein."
            }
        }
    }
}

function Run-Setup {
    Write-Host ''
    Write-Host 'Pixel Photo Uploader – gemeinsame Einrichtung'
    Write-Host 'Dropbox und der OneDrive-Eingang werden geleert, indem Medien einsortiert werden.'
    Write-Host 'Inhaltsgleiche Duplikate werden erst nach SHA-256-Prüfung entfernt.'
    Write-Host ''
    Write-Host 'Wie erreichen die Medien das Pixel?'
    Write-Host '  [A] Android-App "Pixel Photo Companion" mit Resilio  (kein USB-Kabel, kein ADB)'
    Write-Host '  [W] WLAN-ADB  (für die einmalige Aktivierung ein USB-Datenkabel)'
    Write-Host '  [U] USB-ADB   (Pixel dauerhaft am Kabel)'
    $transportInput = Read-Host 'Übertragung [A]'
    $transportMode = 'App'
    if ($transportInput -match '(?i)^w') { $transportMode = 'WiFi' }
    elseif ($transportInput -match '(?i)^u') { $transportMode = 'USB' }
    $usesAdb = ($transportMode -ne 'App')
    $folderSteps = if ($usesAdb) { 3 } else { 5 }

    $dropboxRoot = Select-FolderPath -Description "1/${folderSteps}: Dropbox-Ordner `"Camera Uploads`" auswählen"
    if ([string]::IsNullOrWhiteSpace($dropboxRoot)) {
        Write-Host 'Einrichtung abgebrochen.'
        return
    }
    $inboxRoot = Select-FolderPath -Description "2/${folderSteps}: OneDrive-Ordner `"Eigene Aufnahmen`" auswählen"
    if ([string]::IsNullOrWhiteSpace($inboxRoot)) {
        Write-Host 'Einrichtung abgebrochen.'
        return
    }
    $sourceRoot = Select-FolderPath -Description "3/${folderSteps}: Archivordner `"data\pictures`" für den Pixel-Upload auswählen" -AllowCreate $true
    if ([string]::IsNullOrWhiteSpace($sourceRoot)) {
        Write-Host 'Einrichtung abgebrochen.'
        return
    }

    $stagingRoot = ''
    $controlRoot = ''
    if (-not $usesAdb) {
        $stagingRoot = Select-FolderPath -Description "4/${folderSteps}: Leeren Windows-Ordner für die Resilio-Übergabe an das Pixel auswählen oder erstellen" -AllowCreate $true
        if ([string]::IsNullOrWhiteSpace($stagingRoot)) {
            Write-Host 'Einrichtung abgebrochen.'
            return
        }
        $controlRoot = Select-FolderPath -Description "5/${folderSteps}: Windows-Ordner für die vom Pixel synchronisierten Rückbelege auswählen oder erstellen" -AllowCreate $true
        if ([string]::IsNullOrWhiteSpace($controlRoot)) {
            Write-Host 'Einrichtung abgebrochen.'
            return
        }
    }
    Assert-SeparatePipelineFolders -DropboxRoot $dropboxRoot -InboxRoot $inboxRoot -ArchiveRoot $sourceRoot -StagingRoot $stagingRoot -ControlRoot $controlRoot

    $batchGiB = Read-NumberInRange -Question 'Maximale Batchgröße in GiB' -Default 5 -Minimum $script:MinBatchGiB -Maximum $script:MaxBatchGiB
    $stableSeconds = Read-NumberInRange -Question 'Wartezeit auf unveränderte Dateien in Sekunden' -Default 120 -Minimum 0 -Maximum $script:MaxStableSeconds

    $usbSerial = ''
    $connectionMode = $transportMode
    $wifiEndpoint = ''
    if ($usesAdb) {
        Ensure-Adb
        Write-Host ''
        Write-Host 'Pixel per USB verbinden, entsperren und USB-Debugging zulassen.'
        Read-Host 'Danach Eingabetaste drücken' | Out-Null
        $usbSerial = [string](Wait-ForAuthorizedUsbPixel)

        if ($transportMode -eq 'WiFi') {
            $detectedIp = Get-WifiIPv4FromUsb -UsbSerial $usbSerial
            $ipInput = Read-Host "Pixel-IP im WLAN [$detectedIp]"
            $ip = if ([string]::IsNullOrWhiteSpace($ipInput)) { $detectedIp } else { $ipInput.Trim() }
            if ($ip -notmatch '^\d{1,3}(?:\.\d{1,3}){3}$') {
                throw 'Pixel-IP konnte nicht automatisch erkannt werden. Bitte eine gültige IPv4-Adresse eingeben.'
            }
            $wifiEndpoint = "$ip`:5555"
            Enable-WifiAdbFromUsb -UsbSerial $usbSerial -Endpoint $wifiEndpoint
        }
    }

    $resilioEnabled = $false
    $resilioRoot = '/sdcard/DCIM/ResilioInbox'
    if ($usesAdb) {
        $resilioInput = Read-Host 'Zusätzlich Resilio-Sync-Eingang auf dem Pixel überwachen? [j/N]'
        $resilioEnabled = [bool]($resilioInput -match '(?i)^(j|y)')
        if ($resilioEnabled) {
            $resilioRootInput = Read-Host "Resilio-Zielordner auf dem Pixel [$resilioRoot]"
            if (-not [string]::IsNullOrWhiteSpace($resilioRootInput)) {
                $resilioRoot = $resilioRootInput.Trim().TrimEnd('/')
            }
            if (-not $resilioRoot.StartsWith('/sdcard/')) {
                throw 'Der Resilio-Zielordner muss mit /sdcard/ beginnen.'
            }
        }
    }

    $config = [pscustomobject]@{
        Version            = 3
        ImportEnabled      = $true
        DropboxRoot        = $dropboxRoot
        InboxRoot          = $inboxRoot
        SourceRoot         = $sourceRoot
        TransportMode      = $transportMode
        StagingRoot        = $stagingRoot
        ControlRoot        = $controlRoot
        Serial             = $usbSerial
        UsbSerial          = $usbSerial
        ConnectionMode     = $connectionMode
        WiFiEndpoint       = $wifiEndpoint
        ResilioEnabled     = [bool]$resilioEnabled
        ResilioRemoteRoot  = $resilioRoot
        KeepAwake          = $true
        RequireUnlocked    = $true
        BatchGiB           = $batchGiB
        ReserveGiB         = 1.5
        StableMinutes      = Get-StableMinutesFromSeconds -Seconds $stableSeconds
        RescanMinutes      = 360
        ScanGraceMinutes   = 5
        BackupPollSeconds  = 45
        BackupTimeoutHours = 72
        RemoteRoot         = '/sdcard/DCIM/Camera/PixelUploader'
    }
    Save-JsonAtomic -Value $config -Path $script:ConfigPath

    if ($usesAdb) {
        Assert-DeviceReady -Config $config
        [void](Invoke-Adb -Config $config -Arguments @('shell', 'settings', 'put', 'global', 'stay_on_while_plugged_in', '3') -AllowFailure)
        [void](Invoke-Adb -Config $config -Arguments @('shell', 'input', 'keyevent', 'KEYCODE_WAKEUP') -AllowFailure)
        if ([bool]$config.ResilioEnabled) {
            $quotedResilioRoot = Quote-AndroidShell ([string]$config.ResilioRemoteRoot)
            [void](Invoke-Adb -Config $config -Arguments @('shell', "mkdir -p $quotedResilioRoot"))
        }
    }
    else {
        $batchParent = Join-Path $stagingRoot $script:AppBatchFolderName
        if (-not (Test-Path -LiteralPath $batchParent -PathType Container)) {
            New-Item -ItemType Directory -Path $batchParent -Force | Out-Null
        }
    }

    Write-Host ''
    if ($usesAdb) {
        Write-Host 'Jetzt am Pixel in Google Fotos prüfen:'
        Write-Host '  1. Richtiges Google-Konto'
        Write-Host '  2. Sicherung eingeschaltet'
        Write-Host '  3. Originalqualität'
        Write-Host '  4. Pixel einmal entsperren; beim Laden bleibt der Bildschirm eingeschaltet'
        if ([bool]$config.ResilioEnabled) {
            Write-Host "  5. Resilio Sync: Ziel $($config.ResilioRemoteRoot), selektive Synchronisierung AUS"
            Write-Host '  6. Resilio-Ordner nur lesend empfangen und geänderte Dateien nicht überschreiben lassen'
            Write-Host '  7. In Google Fotos die Sicherung dieses Geräteordners einschalten'
        }
        if ($transportMode -eq 'WiFi') {
            Write-Host "  WLAN-ADB ist unter $wifiEndpoint aktiv; USB kann nach der Prüfung entfernt werden."
        }
    }
    else {
        Write-Host 'Diese Einrichtung braucht kein USB-Kabel und kein ADB. Jetzt am Pixel prüfen:'
        Write-Host '  1. App "Pixel Photo Companion" installiert, Dateizugriff und Bedienungshilfe erlaubt'
        Write-Host '  2. Kontrollordner der App: /storage/emulated/0/Documents/PixelPhotoControl'
        Write-Host "  3. Resilio-Freigabe Windows -> Pixel: $stagingRoot"
        Write-Host '     Pixel-Ziel /storage/emulated/0/DCIM/ResilioInbox, nur lesend, Full Sync an, "Overwrite any changed files" aus'
        Write-Host "  4. Resilio-Freigabe Pixel -> Windows: Kontrollordner empfangen in $controlRoot"
        Write-Host '  5. Google Fotos: richtiges Konto, Sicherung an, Originalqualität, Ordner ResilioInbox gesichert'
        Write-Host '  6. In der App "Überwachung starten" drücken'
        Write-Host ''
        Write-Host "Windows-Übergabeordner: $stagingRoot"
        Write-Host "Rückbelege des Pixels:  $controlRoot"
        Write-Host 'Das Windows-Programm steuert Google Fotos nicht selbst; das übernimmt die App.'
    }
    Write-Host ''
    Read-Host 'Wenn erledigt, Eingabetaste drücken' | Out-Null

    Invoke-ImportPipeline -Config $config | Out-Null
    Update-Catalog -Config $config | Out-Null
    Run-Preflight
    Write-Log 'Einrichtung erfolgreich abgeschlossen.' 'OK'
}

function Start-PathWatcher {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Label,
        [bool]$IncludeSubdirectories = $true
    )

    $watcher = New-Object System.IO.FileSystemWatcher
    $watcher.Path = $Path
    $watcher.Filter = '*.*'
    $watcher.IncludeSubdirectories = $IncludeSubdirectories
    $watcher.NotifyFilter = [System.IO.NotifyFilters]'FileName, DirectoryName, Size, LastWrite'
    # Ohne den Hinweis meldet die Überwachung einen vollen Puffer kommentarlos: Ereignisse
    # fehlen dann einfach, und der Katalog führt geänderte Dateien als unverändert.
    $watcher.InternalBufferSize = $script:WatcherBufferBytes
    $watcher.EnableRaisingEvents = $true
    $prefix = "PixelPhotoUploader.$PID.$([Guid]::NewGuid().ToString('N'))"
    Register-ObjectEvent -InputObject $watcher -EventName Created -SourceIdentifier "$prefix.Created" | Out-Null
    Register-ObjectEvent -InputObject $watcher -EventName Changed -SourceIdentifier "$prefix.Changed" | Out-Null
    Register-ObjectEvent -InputObject $watcher -EventName Renamed -SourceIdentifier "$prefix.Renamed" | Out-Null
    Register-ObjectEvent -InputObject $watcher -EventName Deleted -SourceIdentifier "$prefix.Deleted" | Out-Null
    Register-ObjectEvent -InputObject $watcher -EventName Error -SourceIdentifier "$prefix.Error" | Out-Null
    return [pscustomobject]@{ Watcher = $watcher; Prefix = $prefix; Label = $Label }
}

function Start-PipelineWatchers {
    param([Parameter(Mandatory = $true)]$Config)

    $states = [System.Collections.Generic.List[object]]::new()
    $states.Add((Start-PathWatcher -Path ([string]$Config.SourceRoot) -Label 'Pixel-Archiv' -IncludeSubdirectories $true))
    if ([bool]$Config.ImportEnabled) {
        $states.Add((Start-PathWatcher -Path ([string]$Config.DropboxRoot) -Label 'Dropbox' -IncludeSubdirectories $true))
        $states.Add((Start-PathWatcher -Path ([string]$Config.InboxRoot) -Label 'OneDrive-Eingang' -IncludeSubdirectories $false))
    }
    return @($states)
}

function Stop-PipelineWatchers {
    param([object[]]$WatcherStates)

    foreach ($state in @($WatcherStates)) {
        if (-not $state) { continue }
        Get-EventSubscriber | Where-Object { $_.SourceIdentifier -like "$($state.Prefix).*" } | Unregister-Event -Force
        Get-Event | Where-Object { $_.SourceIdentifier -like "$($state.Prefix).*" } | Remove-Event
        $state.Watcher.Dispose()
    }
}

function Get-AndDrainWatcherSignals {
    param([object[]]$WatcherStates)

    $labels = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    $paths = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    $overflow = $false
    foreach ($state in @($WatcherStates)) {
        $events = @(Get-Event | Where-Object { $_.SourceIdentifier -like "$($state.Prefix).*" })
        foreach ($event in $events) {
            [void]$labels.Add([string]$state.Label)
            # Die Error-Meldung trägt keinen Pfad: sie sagt nur, dass darunter etwas fehlt.
            if ([string]$event.SourceIdentifier -like '*Error') {
                $overflow = $true
                Remove-Event -EventIdentifier $event.EventIdentifier
                continue
            }
            # PowerShell legt Sender und EventArgs als Feld ab und benennt die EventArgs
            # in 5.1 anders als in 7: gefunden wird deshalb über die Eigenschaften.
            foreach ($argument in @($event.SourceArgs)) {
                if (-not $argument) { continue }
                $argumentNames = @($argument.PSObject.Properties.Name)
                if ('FullPath' -in $argumentNames -and $argument.FullPath) {
                    [void]$paths.Add([string]$argument.FullPath)
                }
                # OldFullPath gibt es nur beim Umbenennen; ohne sie bliebe die Datei doppelt im Katalog.
                if ('OldFullPath' -in $argumentNames -and $argument.OldFullPath) {
                    [void]$paths.Add([string]$argument.OldFullPath)
                }
            }
            Remove-Event -EventIdentifier $event.EventIdentifier
        }
    }
    return [pscustomobject]@{ Labels = @($labels); Paths = @($paths); Overflow = $overflow }
}

function Run-WatchLoop {
    $config = Load-Config
    if (Test-AppTransport -Config $config) {
        Invoke-AppPreflight -Config $config
    }
    else {
        Ensure-Adb
    }
    Assert-DeviceReady -Config $config
    $completionSets = Load-CompletionSets
    $watcherStates = @()

    try {
        # Die Überwachung läuft schon, während unten noch der Katalog nachgezogen wird:
        # was in dieser Zeit passiert, geht nicht verloren.
        $watcherStates = @(Start-PipelineWatchers -Config $config)
        $imported = Invoke-ImportPipeline -Config $config
        $archiveScanMinutes = [double](Get-NumberProperty -Object $config -Name 'RescanMinutes' -Default 360)
        $decision = Get-ArchiveScanDecision -LastFullScanUtc (Get-LastFullScanUtc -SourceRoot ([string]$config.SourceRoot)) -RescanMinutes $archiveScanMinutes
        if ($decision.FullScan) {
            Update-Catalog -Config $config | Out-Null
        }
        else {
            # Der Grundabgleich liegt erst Stunden zurück; die Überwachung und was die
            # Eingänge gerade übergeben haben, reicht für den Anschluss.
            Write-Log ('Letzter Grundabgleich vor {0:N0} Minuten; das Archiv wird nicht noch einmal komplett durchsucht.' -f $decision.AgeMinutes) 'OK'
            if (@($imported.ArchivePaths).Count -gt 0) {
                Update-Catalog -Config $config -OnlyPaths @($imported.ArchivePaths) | Out-Null
            }
        }
        if (Test-AppTransport -Config $config) {
            Repair-AppBatches -Config $config
        }
        else {
            Repair-InterruptedTransfers -Config $config
        }
        $nextArchiveScan = (Get-Date).AddMinutes($decision.WaitMinutes)

        Write-Log 'Dauerbetrieb gestartet. Beenden mit Strg+C.' 'OK'
        while ($true) {
            Assert-DeviceReady -Config $config

            [void](Process-AllPixelMedia -Config $config -CompletionSets $completionSets)

            $signals = Get-AndDrainWatcherSignals -WatcherStates $watcherStates
            $labels = @($signals.Labels)
            $changedPaths = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
            foreach ($path in @($signals.Paths)) { [void]$changedPaths.Add([string]$path) }
            $eventSeen = $labels.Count -gt 0
            $archiveChanged = $labels -contains 'Pixel-Archiv'
            if ($eventSeen) {
                Write-Log "Windows hat Änderungen gemeldet ($($labels -join ', ')); warte auf stabile Dateien."
                Start-Sleep -Seconds ([Math]::Min(30, [int]([double]$config.StableMinutes * 60)))
                $imported = Invoke-ImportPipeline -Config $config
                # Nur was im Archiv angekommen ist, braucht den Katalog. Ein Screenshot, der
                # nur innerhalb des Eingangs aufräumt, hat das Archiv nicht verändert.
                if (@($imported.ArchivePaths).Count -gt 0) { $archiveChanged = $true }
                foreach ($path in @($imported.ArchivePaths)) { [void]$changedPaths.Add([string]$path) }
            }
            if ($archiveChanged -or $signals.Overflow) {
                if ($signals.Overflow) {
                    # Verlorene Ereignisse sind nicht nachfahrbar: nur der Vergleich der
                    # Platte mit dem Katalog findet, was niemand gemeldet hat. Ein Überlauf
                    # kann auch in der Dropbox- oder Eingangsüberwachung passieren.
                    Write-Log 'Die Windows-Überwachung meldet einen vollen Ereignispuffer; das Archiv wird vollständig nachgesehen.' 'WARN'
                }
                Update-Catalog -Config $config -OnlyPaths @($changedPaths) -Overflow:$signals.Overflow | Out-Null
                $nextArchiveScan = (Get-Date).AddMinutes($archiveScanMinutes)
            }
            elseif ((Get-Date) -ge $nextArchiveScan) {
                Write-Log 'Archiv-Grundabgleich fällig: neuer Durchlauf durch das Archiv.'
                Update-Catalog -Config $config | Out-Null
                Invoke-ImportPipeline -Config $config | Out-Null
                $nextArchiveScan = (Get-Date).AddMinutes($archiveScanMinutes)
            }

            $stagedCount = @(Load-Staged).Count
            $added = Select-AndStageBatch -Config $config -CompletionSets $completionSets
            if ($added -gt 0) {
                continue
            }

            if ((Get-Date) -ge $nextArchiveScan) { continue }
            $resilioPendingCount = 0
            if ([bool]$config.ResilioEnabled) {
                $resilioPendingCount = @((Load-ResilioState) | Where-Object { [bool]$_.MediaScanned }).Count
            }
            if (($stagedCount -gt 0) -or ($resilioPendingCount -gt 0)) {
                if (Test-AppTransport -Config $config) {
                    Write-Log 'Warte auf den Android-Rückbeleg; prüfe in 60 Sekunden erneut.'
                    Start-Sleep -Seconds 60
                }
                else {
                    Write-Log 'Lokale Restdateien werden in 15 Minuten erneut von Google Fotos geprüft.'
                    Start-Sleep -Seconds 900
                }
            }
            else {
                Write-Log 'Warteschlange leer. Warte auf neue Fotos oder den nächsten Archiv-Grundabgleich.' 'OK'
                Start-Sleep -Seconds 60
            }
        }
    }
    finally {
        Stop-PipelineWatchers -WatcherStates $watcherStates
    }
}

function Get-ScriptParameterCollisions {
    # PowerShell unterscheidet Variablennamen nicht nach Groß-/Kleinschreibung: ein
    # [string]$Caption-Parameter und ein lokales $caption sind dieselbe Variable, der
    # Label-Wert wird dabei stillschweigend in eine String umgewandelt.
    $scriptPath = [string]$PSCommandPath
    if ([string]::IsNullOrWhiteSpace($scriptPath) -or -not (Test-Path -LiteralPath $scriptPath)) { return @() }

    $tokens = $null
    $parseErrors = $null
    $ast = [System.Management.Automation.Language.Parser]::ParseFile($scriptPath, [ref]$tokens, [ref]$parseErrors)
    if (@($parseErrors).Count -gt 0) { return @("Skript lässt sich nicht lesen: $($parseErrors[0].Extent.StartLineNumber)") }

    $functions = @($ast.FindAll({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] }, $true))
    $results = [System.Collections.Generic.List[string]]::new()

    foreach ($function in $functions) {
        $typedParams = @{}
        foreach ($block in $function.FindAll({ param($node)
            $node -is [System.Management.Automation.Language.ParamBlockAst] -and
            $node.Parent -is [System.Management.Automation.Language.ScriptBlockAst] -and
            $node.Parent -isnot [System.Management.Automation.Language.FunctionDefinitionAst]
        }, $true)) {
            if ($block.Extent.StartLineNumber -lt $function.Extent.StartLineNumber -or
                $block.Extent.EndLineNumber -gt $function.Extent.EndLineNumber) { continue }
            foreach ($parameter in $block.Parameters) {
                $name = ''
                if ($parameter -is [System.Management.Automation.Language.VariableExpressionAst]) {
                    $name = [string]$parameter.VariablePath.UserPath
                }
                elseif ([string]$parameter.GetType().Name -eq 'NamedArgumentAst') {
                    continue
                }
                else {
                    $name = ([string]$parameter.Name).TrimStart('$')
                }
                if (-not $name) { continue }
                foreach ($attribute in $parameter.Attributes) {
                    if (-not $attribute.TypeName) { continue }
                    $typeName = [string]$attribute.TypeName.FullName
                    if ($typeName -and $typeName -notmatch '^(Parameter|Allow|Validate|Supports|Alias)') {
                        $typedParams[$name] = $typeName
                        break
                    }
                }
            }
        }
        if ($typedParams.Count -eq 0) { continue }

        foreach ($assignment in $function.FindAll({ param($node) $node -is [System.Management.Automation.Language.AssignmentStatementAst] }, $true)) {
            if ($assignment.Left -isnot [System.Management.Automation.Language.VariableExpressionAst]) { continue }
            if ($assignment.Extent.StartLineNumber -lt $function.Extent.StartLineNumber -or
                $assignment.Extent.EndLineNumber -gt $function.Extent.EndLineNumber) { continue }
            $inner = $false
            foreach ($other in $functions) {
                if ($other -eq $function) { continue }
                if ($assignment.Extent.StartLineNumber -ge $other.Extent.StartLineNumber -and
                    $assignment.Extent.EndLineNumber -le $other.Extent.EndLineNumber) { $inner = $true; break }
            }
            if ($inner) { continue }

            $target = [string]$assignment.Left.VariablePath.UserPath
            foreach ($candidate in @($typedParams.Keys)) {
                if ($target -eq $candidate) {
                    $results.Add(('{0}(): Parameter -{1} ({2}) wird in Zeile {3} selbst neu gesetzt' -f $function.Name, $candidate, $typedParams[$candidate], $assignment.Extent.StartLineNumber))
                }
            }
        }
    }
    return @($results | Select-Object -Unique)
}

function Get-StringCastConditions {
    # Eine Umwandlung, die ganze Bedingung ist, prüft immer einen Text: aus [string]$true
    # wie aus [string]$false wird 'True' bzw. 'False', und beides ist in PowerShell wahr.
    $scriptPath = [string]$PSCommandPath
    if ([string]::IsNullOrWhiteSpace($scriptPath) -or -not (Test-Path -LiteralPath $scriptPath)) { return @() }

    $tokens = $null
    $parseErrors = $null
    $ast = [System.Management.Automation.Language.Parser]::ParseFile($scriptPath, [ref]$tokens, [ref]$parseErrors)
    if (@($parseErrors).Count -gt 0) { return @("Skript lässt sich nicht lesen: $($parseErrors[0].Extent.StartLineNumber)") }

    $statements = @($ast.FindAll({ param($node)
        $node -is [System.Management.Automation.Language.IfStatementAst] -or
        $node -is [System.Management.Automation.Language.WhileStatementAst] -or
        $node -is [System.Management.Automation.Language.DoWhileStatementAst]
    }, $true))
    $results = [System.Collections.Generic.List[string]]::new()
    foreach ($statement in $statements) {
        $conditions = [System.Collections.Generic.List[object]]::new()
        if ($statement -is [System.Management.Automation.Language.IfStatementAst]) {
            foreach ($clause in $statement.Clauses) { $conditions.Add($clause.Item1) }
        }
        else {
            $conditions.Add($statement.Condition)
        }
        foreach ($condition in $conditions) {
            if ($condition -isnot [System.Management.Automation.Language.PipelineAst]) { continue }
            $elements = @($condition.PipelineElements)
            if ($elements.Count -ne 1) { continue }
            if ($elements[0] -isnot [System.Management.Automation.Language.CommandExpressionAst]) { continue }
            $expr = $elements[0].Expression
            if ($expr -isnot [System.Management.Automation.Language.ConvertExpressionAst]) { continue }
            # NewType bleibt je nach PowerShell-Version leer; der Quelltext zählt.
            if (([string]$expr.Extent.Text) -notmatch '(?is)^\s*\[\s*(string|System\.String)\s*\]') { continue }
            $text = (([string]$expr.Extent.Text) -replace '\s+', ' ').Trim()
            $results.Add(('Zeile {0}: Bedingung wandelt in einen Text um: {1}' -f $expr.Extent.StartLineNumber, $text))
        }
    }
    return @($results | Select-Object -Unique)
}

function Get-CastArguments {
    # In einem Befehlsargument ist `[double]$wert` keine Umwandlung und `[DateTime]::Now`
    # kein Aufruf: beides wird zu dem Text vor dem Wert. Bei einer Zahl knallt es, bei
    # einem Text-Parameter läuft es still falsch weiter. Also immer klammern.
    $scriptPath = [string]$PSCommandPath
    if ([string]::IsNullOrWhiteSpace($scriptPath) -or -not (Test-Path -LiteralPath $scriptPath)) { return @() }

    $tokens = $null
    $parseErrors = $null
    $ast = [System.Management.Automation.Language.Parser]::ParseFile($scriptPath, [ref]$tokens, [ref]$parseErrors)
    if (@($parseErrors).Count -gt 0) { return @("Skript lässt sich nicht lesen: $($parseErrors[0].Extent.StartLineNumber)") }

    $typeNamePattern = '(?is)^\s*\[\s*(string|single|int|int16|int32|int64|long|double|decimal|bool|boolean|byte|char|datetime|timespan|object|psobject|pscustomobject|hashtable|array|regex|xml|switch|uri|guid|type|system\.[\w.]+)\s*\](::|\$)'
    $results = [System.Collections.Generic.List[string]]::new()
    foreach ($command in @($ast.FindAll({ param($node)
        $node -is [System.Management.Automation.Language.CommandAst]
    }, $true))) {
        foreach ($element in @($command.CommandElements)) {
            $kind = [string]$element.GetType().Name
            if ($kind -ne 'StringConstantExpressionAst' -and $kind -ne 'ExpandableStringExpressionAst') { continue }
            $text = (([string]$element.Extent.Text) -replace '\s+', ' ').Trim()
            if ($text -notmatch $typeNamePattern) { continue }
            $results.Add(('Zeile {0}: Umwandlung steht ungeklammert als Befehlsargument da: {1}' -f $element.Extent.StartLineNumber, $text))
        }
    }
    return @($results | Select-Object -Unique)
}

function Run-SelfTest {
    $tempRoot = Join-Path $env:TEMP ("PixelPhotoUploader-Test-" + [Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null
    try {
        $structure = @(Get-ScriptParameterCollisions) + @(Get-StringCastConditions) + @(Get-CastArguments)
        if (@($structure).Count -gt 0) {
            throw ('Selbsttest der Skriptstruktur: ' + ((@($structure) -join ' · ')))
        }
        $hash1 = Get-TextSha256 'test'
        if ($hash1 -ne '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08') {
            throw 'SHA-256-Selbsttest fehlgeschlagen.'
        }
        $nested = Join-Path $tempRoot 'Unterordner'
        New-Item -ItemType Directory -Path $nested | Out-Null
        $photo = Join-Path $nested 'foto.jpg'
        [System.IO.File]::WriteAllBytes($photo, [byte[]](1, 2, 3, 4))
        $relative = Get-RelativePathSafe -Root $tempRoot -FullPath $photo
        if ($relative -ne 'Unterordner\foto.jpg') { throw "Relativpfad-Selbsttest fehlgeschlagen: $relative" }
        if (-not (Test-SupportedMedia -Path $photo)) { throw 'Dateityp-Selbsttest fehlgeschlagen.' }

        $dropboxRoot = Join-Path $tempRoot 'Dropbox'
        $inboxRoot = Join-Path $tempRoot 'OneDrive'
        $archiveRoot = Join-Path $tempRoot 'Archiv'
        New-Item -ItemType Directory -Path $dropboxRoot, $inboxRoot, $archiveRoot -Force | Out-Null
        $monthRoot = Join-Path $archiveRoot (Get-Date -Format 'yyyy.MM')
        New-Item -ItemType Directory -Path $monthRoot -Force | Out-Null
        [System.IO.File]::WriteAllBytes((Join-Path $monthRoot 'vorhanden.jpg'), [byte[]](9, 8, 7, 6))
        [System.IO.File]::WriteAllBytes((Join-Path $dropboxRoot 'anders-benannt.jpg'), [byte[]](9, 8, 7, 6))
        $testConfig = [pscustomobject]@{
            ImportEnabled = $true
            DropboxRoot = $dropboxRoot
            InboxRoot = $inboxRoot
            SourceRoot = $archiveRoot
            StableMinutes = 0
        }
        $pipelineResult = Invoke-ImportPipeline -Config $testConfig
        if (@(Get-ChildItem -LiteralPath $dropboxRoot -Recurse -File).Count -ne 0) { throw 'Dropbox-Import-Selbsttest fehlgeschlagen.' }
        if (@(Get-ChildItem -LiteralPath $inboxRoot -File).Count -ne 0) { throw 'OneDrive-Sortier-Selbsttest fehlgeschlagen.' }
        if (@(Get-ChildItem -LiteralPath $archiveRoot -Recurse -File).Count -ne 1) { throw 'SHA-256-Duplikat-Selbsttest fehlgeschlagen.' }
        if ($pipelineResult.Duplicates -ne 1) { throw 'Duplikatzähler-Selbsttest fehlgeschlagen.' }

        $monthName = Split-Path -Leaf $monthRoot
        $oldMonthRoot = Join-Path $archiveRoot '2019.01'
        New-Item -ItemType Directory -Path $oldMonthRoot -Force | Out-Null
        $newestFile = Join-Path $monthRoot 'neueste.jpg'
        $oldestFile = Join-Path $oldMonthRoot 'uralt.jpg'
        [System.IO.File]::WriteAllBytes($newestFile, [byte[]](22, 23, 24))
        [System.IO.File]::WriteAllBytes($oldestFile, [byte[]](20, 21))
        (Get-Item -LiteralPath $newestFile).LastWriteTimeUtc = [DateTime]'2026-06-06T12:00:00Z'
        (Get-Item -LiteralPath $oldestFile).LastWriteTimeUtc = [DateTime]'2019-01-01T12:00:00Z'
        (Get-Item -LiteralPath (Join-Path $monthRoot 'vorhanden.jpg')).LastWriteTimeUtc = [DateTime]'2020-01-01T12:00:00Z'

        $stagingRoot = Join-Path $tempRoot 'Uebergabe'
        $controlRoot = Join-Path $tempRoot 'Rueckbelege'
        New-Item -ItemType Directory -Path $stagingRoot, $controlRoot -Force | Out-Null
        $originalCatalogPath = $script:CatalogPath
        $originalStagedPath = $script:StagedPath
        $originalCompletedPath = $script:CompletedPath
        $originalConfigPath = $script:ConfigPath
        $originalTasksPath = $script:TasksPath
        $originalLastScanPath = $script:LastScanPath
        $script:CatalogPath = Join-Path $tempRoot 'test-catalog.csv'
        $script:StagedPath = Join-Path $tempRoot 'test-staged.json'
        $script:CompletedPath = Join-Path $tempRoot 'test-completed.csv'
        $script:ConfigPath = Join-Path $tempRoot 'test-config.json'
        $script:TasksPath = Join-Path $tempRoot 'test-tasks.json'
        $script:LastScanPath = Join-Path $tempRoot 'test-lastscan.json'
        try {
            $appConfig = [pscustomobject]@{
                TransportMode = 'App'
                SourceRoot    = $archiveRoot
                StagingRoot   = $stagingRoot
                ControlRoot   = $controlRoot
                BatchGiB      = 1
                StableMinutes = 0
            }
            [void](Update-Catalog -Config $appConfig)
            $sets = Load-CompletionSets
            if ((Select-AndStageBatch -Config $appConfig -CompletionSets $sets) -ne 3) {
                throw 'App-Übergabe-Selbsttest fehlgeschlagen.'
            }

            $stagedInOrder = @(Load-Staged)
            if ($stagedInOrder.Count -ne 3) { throw 'Es wurden drei vorgemerkte Dateien erwartet.' }
            if (([string]$stagedInOrder[0].RelativePath).Replace('\', '/') -ne "$monthName/neueste.jpg") {
                throw "Neueste Datei erwartet zuerst, stattdessen: $($stagedInOrder[0].RelativePath)"
            }
            if (([string]$stagedInOrder[2].RelativePath).Replace('\', '/') -ne '2019.01/uralt.jpg') {
                throw "Älteste Datei erwartet zuletzt, stattdessen: $($stagedInOrder[2].RelativePath)"
            }
            if ([string]$stagedInOrder[0].StagedName -notmatch '^000001-') { throw 'Batchnummerierung folgt nicht der Auswahlreihenfolge.' }

            $batchFolders = @(Get-ChildItem -LiteralPath (Join-Path $stagingRoot $script:AppBatchFolderName) -Directory)
            if ($batchFolders.Count -ne 1) { throw 'Es wurde genau ein Batchordner erwartet.' }
            if (-not (Test-Path -LiteralPath (Join-Path $batchFolders[0].FullName '_batch-manifest.json') -PathType Leaf)) {
                throw 'Batchmanifest fehlt; die Android-App würde den Batch ignorieren.'
            }
            if (-not (Test-Path -LiteralPath (Join-Path $batchFolders[0].FullName '_batch-ready.txt') -PathType Leaf)) {
                throw 'Fertigmarker fehlt; die Android-App würde den Batch ignorieren.'
            }
            $stagedRecords = @(Load-Staged)
            $pixelSuffix = [string]$stagedRecords[0].PixelSuffix
            if ([string]::IsNullOrWhiteSpace($pixelSuffix)) { throw 'Pixelsuffix des Batches fehlt.' }

            $receiptPaths = [System.Collections.Generic.List[string]]::new()
            foreach ($record in $stagedRecords) {
                $receiptPaths.Add('/storage/emulated/0/DCIM/ResilioInbox' + [string]$record.PixelSuffix)
            }
            Save-JsonAtomic -Value ([pscustomobject]@{
                version      = 1
                receiptId    = 'selftest'
                removedPaths = @($receiptPaths)
            }) -Path (Join-Path $controlRoot 'receipt-selftest.json') -Depth 5

            if ((Confirm-AppStagedBatches -Config $appConfig -CompletionSets $sets) -ne 3) {
                throw 'Rückbeleg-Abgleich fehlgeschlagen.'
            }
            if (@(Load-Staged).Count -ne 0) { throw 'Nach dem Rückbeleg darf nichts vorgemerkt bleiben.' }
            if (Test-Path -LiteralPath $batchFolders[0].FullName) { throw 'Abgeschlossener Batchordner wurde nicht entfernt.' }
            foreach ($archiveFile in @((Join-Path $monthRoot 'vorhanden.jpg'), $newestFile, $oldestFile)) {
                if (-not (Test-Path -LiteralPath $archiveFile -PathType Leaf)) {
                    throw "Die Archivdatei darf durch die Batch-Übergabe nicht verschwinden: $archiveFile"
                }
            }
            if ((Load-CompletionSets).Fingerprints.Count -ne 3) { throw 'Abschlussprotokoll unvollständig.' }
            if ((Select-AndStageBatch -Config $appConfig -CompletionSets (Load-CompletionSets)) -ne 0) {
                throw 'Bestätigte Dateien dürfen nicht erneut übergeben werden.'
            }

            $laterFile = Join-Path $monthRoot 'spaeter.jpg'
            [System.IO.File]::WriteAllBytes($laterFile, [byte[]](30, 31, 32))
            (Get-Item -LiteralPath $laterFile).LastWriteTimeUtc = [DateTime]::UtcNow.AddHours(-1)
            Save-JsonAtomic -Value ([pscustomobject]@{
                Version       = 3
                TransportMode = 'App'
                ImportEnabled = $true
                SourceRoot    = $archiveRoot
                DropboxRoot   = $dropboxRoot
                InboxRoot     = $inboxRoot
                StagingRoot   = $stagingRoot
                ControlRoot   = $controlRoot
                BatchGiB      = 1
                StableMinutes = 0
                RescanMinutes = 15
            }) -Path $script:ConfigPath -Depth 5

            $pass = Invoke-FullPass
            if ($pass.Staged -ne 1) { throw "Vollabgleich hätte genau eine neue Datei übergeben müssen, stattdessen: $($pass.Staged)" }
            if ($pass.Confirmed -ne 0) { throw 'Vollabgleich darf ohne neuen Rückbeleg nichts bestätigen.' }

            # Die Batchgröße gilt in Einrichtung, Fenster und Laufzeit dieselbe Spanne;
            # eine per Hand eingetragene Zahl darf nirgends stillschweigend anderes bewirken.
            if ((Get-BatchCapacityBytes -Config ([pscustomobject]@{ BatchGiB = $script:MaxBatchGiB })) -ne [long]($script:MaxBatchGiB * 1GB)) {
                throw 'Die versprochene Obergrenze der Batchgröße ist nicht erreichbar.'
            }
            if ((Get-BatchCapacityBytes -Config ([pscustomobject]@{ BatchGiB = 99 })) -ne [long]($script:MaxBatchGiB * 1GB)) {
                throw 'Eine Batchgröße über der Obergrenze wird nicht gedeckelt.'
            }
            if ((Get-BatchCapacityBytes -Config ([pscustomobject]@{ BatchGiB = 0 })) -ne [long]($script:MinBatchGiB * 1GB)) {
                throw 'Eine Batchgröße von Null baut unsichtbar gar keinen Batch mehr.'
            }
            if ((Get-BatchCapacityBytes -Config ([pscustomobject]@{ BatchGiB = 4 })) -ne 4GB) {
                throw 'Eine Batchgröße innerhalb der Spanne wird verstümmelt.'
            }

            # Die Wartezeit lässt sich in Sekunden stellen; gespeichert bleibt Minuten,
            # also muss die Umrechnung auf beide Richtungen und unter einer Minute passen.
            if ((Get-StableMinutesFromSeconds -Seconds 90) -ne 1.5) {
                throw '90 Sekunden Wartezeit sind nicht 1,5 Minuten.'
            }
            if ((Get-StableMinutesFromSeconds -Seconds 0) -ne 0) {
                throw 'Eine Wartezeit von Sekunden darf nicht auf eine Minute springen.'
            }
            if ((Get-StableMinutesFromSeconds -Seconds 900000) -ne ($script:MaxStableSeconds / 60)) {
                throw 'Eine Wartezeit über der Obergrenze wird nicht gedeckelt.'
            }

            $script:Dashboard = $null
            $script:DashboardStamp = ''
            $board = Get-Dashboard
            if (-not [bool]$board.Configured) { throw 'Dashboard meldet fehlende Einrichtung, obwohl konfiguriert ist.' }
            if ($board.CatalogFiles -ne 4) { throw "Dashboard zählt den Archivkatalog falsch: $($board.CatalogFiles)" }
            if ($board.CompletedFiles -ne 3) { throw "Dashboard zählt bestätigte Dateien falsch: $($board.CompletedFiles)" }
            if ($board.StagedFiles -ne 1) { throw "Dashboard zählt den laufenden Batch falsch: $($board.StagedFiles)" }
            if ($board.OpenFiles -ne 1) { throw "Dashboard zählt offene Dateien falsch: $($board.OpenFiles)" }
            if ($board.BatchFolders -ne 1) { throw "Dashboard zählt Batchordner im Übergabepfad falsch: $($board.BatchFolders)" }
            if ($board.ReceiptFiles -ne 1) { throw "Dashboard zählt Rückbelege falsch: $($board.ReceiptFiles)" }
            if ([double]$board.BatchGiB -ne 1) { throw "Dashboard zeigt eine andere Batchgröße als konfiguriert: $($board.BatchGiB)" }
            if (@(Get-LogTail -Lines 5).Count -ne 5) { throw 'Protokoll-Auszug für die Oberfläche ist unvollständig.' }
            foreach ($tailLine in @(Get-LogTail -Lines 8)) {
                $level = ''
                if ([string]$tailLine -match '^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} \[(?<level>INFO|WARN|ERROR|OK)\] ') {
                    $level = [string]$Matches['level']
                }
                if ([string]::IsNullOrWhiteSpace($level)) {
                    throw "Protokollzeile ohne Zeitstempel und Stufe: $tailLine"
                }
            }
            if (Get-TrackedTask -Task 'Watch') { throw 'Ohne tasks.json darf kein Hintergrundprozess gemeldet werden.' }

            $deadId = 4000
            while (Get-Process -Id $deadId -ErrorAction SilentlyContinue) { $deadId++ }
            Save-JsonAtomic -Value ([pscustomobject]@{
                Watch = [pscustomobject]@{ ProcessId = $deadId; StartedUtc = [DateTime]::UtcNow.ToString('o') }
            }) -Path $script:TasksPath -Depth 5
            $stale = Get-TrackedTask -Task 'Watch'
            if (-not $stale) { throw 'Eingetragener Hintergrundprozess wird nicht gelesen.' }
            if ([bool]$stale.Running) { throw 'Ein beendeter Hintergrundprozess wird als laufend gemeldet.' }
            [void](Stop-TrackedTask -Task 'Watch')
            if (Test-Path -LiteralPath $script:TasksPath) { throw 'Beendeter Task bleibt in tasks.json stehen.' }
            if ([bool](Stop-TrackedTask -Task 'Watch')) { throw 'Unbekannter Task darf nicht als beendet gemeldet werden.' }
            if ((Read-Tasks).Count -ne 0) { throw 'Taskliste ist nach dem Aufräumen nicht leer.' }

            $incRoot = Join-Path $tempRoot 'Inkrementarchiv'
            $incMonth = Join-Path $incRoot '2026.09'
            $incOld = Join-Path $incRoot '2020.05'
            New-Item -ItemType Directory -Path $incMonth, $incOld -Force | Out-Null
            $incFresh = Join-Path $incMonth 'frisch.jpg'
            $incGone = Join-Path $incMonth 'geloescht.jpg'
            $incNested = Join-Path $incOld 'unterordner.jpg'
            foreach ($incFile in @($incFresh, $incGone, $incNested)) {
                [System.IO.File]::WriteAllBytes($incFile, [byte[]](1, 2, 3))
            }
            $incQuick = [pscustomobject]@{ SourceRoot = $incRoot; StableMinutes = 0 }
            $incSlow = [pscustomobject]@{ SourceRoot = $incRoot; StableMinutes = 60 }

            # Die Wartezeit lässt sich in Sekunden stellen; gerechnet wird in Minuten weiter.
            $incSubMinute = [pscustomobject]@{ SourceRoot = $incRoot; StableMinutes = (Get-StableMinutesFromSeconds -Seconds 30) }
            $incLateFile = Join-Path $incMonth 'spaet.jpg'
            [System.IO.File]::WriteAllBytes($incLateFile, [byte[]](7, 7))
            (Get-Item -LiteralPath $incLateFile).LastWriteTimeUtc = [DateTime]::UtcNow.AddSeconds(-40)
            if (-not (Test-FileReady -Path $incLateFile -StableBefore ([DateTime]::UtcNow.AddMinutes(-[double]$incSubMinute.StableMinutes)))) {
                throw 'Eine Wartezeit von 30 Sekunden wird nicht als Sekunden geprüft.'
            }
            if ([bool](Test-FileReady -Path $incLateFile -StableBefore ([DateTime]::UtcNow.AddMinutes(-[double]$incSlow.StableMinutes)))) {
                throw 'Eine Datei vor Ablauf der Wartezeit gilt schon als unverändert.'
            }
            Remove-Item -LiteralPath $incLateFile -Force

            $incEntries = @(Update-Catalog -Config $incQuick)
            if ($incEntries.Count -ne 3) { throw 'Ausgangskatalog für den Fortschreib-Selbsttest unvollständig.' }
            $incEntries[0].Sha256 = 'vorgemerkt'
            Save-Catalog -Entries $incEntries
            $incKept = @(Update-Catalog -Config $incSlow)
            if (@($incKept | Where-Object { [string]$_.Sha256 -eq 'vorgemerkt' }).Count -ne 1) {
                throw 'Bekannte Prüfsumme geht beim Durchlauf verloren.'
            }
            if (@($incKept | Where-Object { [string]$_.Stable -ne 'True' }).Count -ne 0) {
                throw 'Unveränderte Datei wurde beim Durchlauf erneut nachgeprüft.'
            }

            # Der Rekursivlauf merkt sich seine Zeit: sonst würde jeder Start des
            # Dauerbetriebs das Archiv ein zweites Mal komplett durchsuchen.
            $incScanAge = ([DateTime]::UtcNow - (Get-LastFullScanUtc -SourceRoot $incRoot)).TotalMinutes
            if ($incScanAge -lt 0 -or $incScanAge -gt 5) {
                throw ('Der Rekursivlauf hinterlässt keinen frischen Zeitpunkt: {0:N1} Minuten.' -f $incScanAge)
            }
            if ((Get-LastFullScanUtc -SourceRoot (Join-Path $tempRoot 'Anderes Archiv')) -ne [DateTime]::MinValue) {
                throw 'Der Grundabgleich eines anderen Archivs würde den ersten Durchlauf überspringen.'
            }
            $incOldMark = [DateTime]::UtcNow.AddMinutes(-90)
            Set-LastFullScanUtc -Value $incOldMark -SourceRoot $incRoot
            if ((Get-LastFullScanUtc -SourceRoot $incRoot).Ticks -ne $incOldMark.Ticks) {
                throw 'Der gemerkte Grundabgleich kommt nicht unverändert zurück.'
            }
            [void](Update-Catalog -Config $incQuick -OnlyPaths @($incFresh))
            if ((Get-LastFullScanUtc -SourceRoot $incRoot).Ticks -ne $incOldMark.Ticks) {
                throw 'Ein Meldungslauf ohne Rekursivlauf schiebt den Grundabgleich nach vorn.'
            }
            [void](Update-Catalog -Config $incQuick)
            if ((Get-LastFullScanUtc -SourceRoot $incRoot).Ticks -eq $incOldMark.Ticks) {
                throw 'Ein Rekursivlauf hinterlässt seinen Zeitpunkt nicht.'
            }
            # Anlaufentscheidung: frisch gemerkt wird überlesen, alt oder unbekannt nicht.
            $incFreshPlan = Get-ArchiveScanDecision -LastFullScanUtc ([DateTime]::UtcNow) -RescanMinutes 360
            if ($incFreshPlan.FullScan -or $incFreshPlan.WaitMinutes -lt 355 -or $incFreshPlan.WaitMinutes -gt 360) {
                throw 'Ein gerade gelaufener Grundabgleich wird beim Start wiederholt.'
            }
            $incLatePlan = Get-ArchiveScanDecision -LastFullScanUtc ([DateTime]::UtcNow.AddMinutes(-400)) -RescanMinutes 360
            if (-not $incLatePlan.FullScan -or $incLatePlan.WaitMinutes -ne 360) {
                throw 'Ein überfälliger Grundabgleich wird beim Start übersprungen.'
            }
            $incUnknownPlan = Get-ArchiveScanDecision -LastFullScanUtc ([DateTime]::MinValue) -RescanMinutes 360
            if (-not $incUnknownPlan.FullScan) {
                throw 'Ohne gemerkten Grundabgleich startet der Dauerbetrieb mit leerem Katalog.'
            }

            [System.IO.File]::WriteAllBytes($incFresh, [byte[]](1, 2, 3, 4, 5))
            (Get-Item -LiteralPath $incFresh).LastWriteTimeUtc = [DateTime]::UtcNow
            $incUpdatedRows = @(Update-Catalog -Config $incQuick -OnlyPaths @($incFresh))
            $incFreshRow = @($incUpdatedRows | Where-Object { [string]$_.RelativePath -like '*frisch.jpg' })
            if ($incUpdatedRows.Count -ne 3 -or $incFreshRow.Count -ne 1) { throw 'Fortschreib-Selbsttest: frische Datei fehlt.' }
            if ([string]$incFreshRow[0].Size -ne '5') { throw 'Größe der gemeldeten Datei nicht fortgeschrieben.' }

            Remove-Item -LiteralPath $incGone -Force
            if (@(Update-Catalog -Config $incQuick -OnlyPaths @($incGone)).Count -ne 2) {
                throw 'Gelöschte Datei bleibt im Katalog stehen.'
            }
            Remove-Item -LiteralPath $incOld -Recurse -Force
            if (@(Update-Catalog -Config $incQuick -OnlyPaths @($incOld)).Count -ne 1) {
                throw 'Einträge eines gelöschten Ordners bleiben im Katalog stehen.'
            }
            if (@(Update-Catalog -Config $incQuick -OnlyPaths @($incMonth)).Count -ne 1) {
                throw 'Ein unbedenklicher Ordner hat Katalogeinträge entfernt.'
            }
            if (@(Update-Catalog -Config $incQuick -OnlyPaths @((Join-Path $tempRoot 'fremd.jpg'))).Count -ne 1) {
                throw 'Ein Pfad außerhalb des Archivs hat den Katalog verändert.'
            }

            $incNew = Join-Path $incMonth 'neu.jpg'
            [System.IO.File]::WriteAllBytes($incNew, [byte[]](7, 8))
            if (@(Update-Catalog -Config $incQuick -OnlyPaths @($incNew)).Count -ne 2) {
                throw 'Neue Datei wurde ohne Durchlauf nicht ergänzt.'
            }
            $incCheckedRows = @(Update-Catalog -Config $incSlow -OnlyPaths @($incNew))
            if ([string](@($incCheckedRows | Where-Object { [string]$_.RelativePath -like '*neu.jpg' })[0]).Stable -ne 'False') {
                throw 'Gemeldete Datei ohne neue Prüfung als vollständig geführt.'
            }

            $incUnreported = Join-Path $incMonth 'ungemeldet.jpg'
            [System.IO.File]::WriteAllBytes($incUnreported, [byte[]](9, 9))
            if (@(Update-Catalog -Config $incQuick -OnlyPaths @($incNew)).Count -ne 2) {
                throw 'Der Fortschreiblauf findet Dateien, die niemand gemeldet hat.'
            }
            if (@(Update-Catalog -Config $incQuick -OnlyPaths @($incNew) -Overflow).Count -ne 3) {
                throw 'Ein Überlauf des Ereignispuffers wird nicht als voller Durchlauf behandelt.'
            }
            # Danach muss der nächste ganz normale Meldungslauf wieder keiner sein.
            $incAfterOverflow = Join-Path $incMonth 'nachueberlauf.jpg'
            [System.IO.File]::WriteAllBytes($incAfterOverflow, [byte[]](3, 3))
            if (@(Update-Catalog -Config $incQuick -OnlyPaths @($incNew)).Count -ne 3) {
                throw 'Nach dem Überlauf läuft jeder Meldungslauf erneut vollständig.'
            }
            Remove-Item -LiteralPath $incAfterOverflow -Force
            $incBulkPaths = @(1 .. 4 | ForEach-Object { (Join-Path $incMonth ('massenweise{0:d4}.jpg' -f $_)) })
            if (@(Update-Catalog -Config $incQuick -OnlyPaths $incBulkPaths -BulkPathLimit 3).Count -ne 3) {
                throw 'Sammelaktion wird nicht als Durchlauf erkannt.'
            }

            $incDropbox = Join-Path $tempRoot 'Importdropbox'
            $incInbox = Join-Path $tempRoot 'Importeingang'
            New-Item -ItemType Directory -Path $incDropbox, $incInbox -Force | Out-Null
            [System.IO.File]::WriteAllBytes((Join-Path $incDropbox 'eingang.jpg'), [byte[]](4, 5, 6))
            $incImportConfig = [pscustomobject]@{
                ImportEnabled = $true
                DropboxRoot   = $incDropbox
                InboxRoot     = $incInbox
                SourceRoot    = $incRoot
                StableMinutes = 0
            }
            $incImported = Invoke-ImportPipeline -Config $incImportConfig
            if (@($incImported.ArchivePaths).Count -ne 1) {
                throw 'Der Import meldet sein Archivziel nicht an den Katalog.'
            }
            if (@(Get-ChildItem -LiteralPath ([string]$incImported.ArchivePaths[0]) -File).Count -ne 1) {
                throw 'Gemeldetes Archivziel existiert nicht.'
            }
            if (@(Update-Catalog -Config $incQuick -OnlyPaths @($incImported.ArchivePaths)).Count -ne 4) {
                throw 'Importierte Datei fehlt im Katalog, obwohl ihr Ziel gemeldet war.'
            }
            [System.IO.File]::WriteAllBytes((Join-Path $incInbox 'Screenshot_2026-09-01.png'), [byte[]](1, 1))
            if (@((Invoke-ImportPipeline -Config $incImportConfig).ArchivePaths).Count -ne 0) {
                throw 'Ein Ziel außerhalb des Archivs meldet sich als Archivdatei.'
            }

            # Der erste Ereignislauf nach der Einrichtung trifft einen leeren Katalog an.
            Save-Catalog -Entries @()
            if (@(Update-Catalog -Config $incQuick -OnlyPaths @($incFresh)).Count -ne 1) {
                throw 'Die erste Meldung in einen leeren Katalog geht verloren.'
            }

            $watchState = Start-PathWatcher -Path $incMonth -Label 'Selbsttest-Überwachung'
            try {
                if ([int]$watchState.Watcher.InternalBufferSize -lt 65536) {
                    throw 'Die Überwachung läuft mit zu kleinem Ereignispuffer und verschluckt Meldungen.'
                }
                $watchSubscribers = @(Get-EventSubscriber | Where-Object { $_.SourceIdentifier -like "$($watchState.Prefix).*" })
                if ($watchSubscribers.Count -ne 5) {
                    throw 'Die Überwachung hört nicht auf alle fünf Ereignisarten.'
                }
                if (@($watchSubscribers | Where-Object { $_.SourceIdentifier -like '*Error' }).Count -ne 1) {
                    throw 'Ein voller Ereignispuffer bliebe ungehört.'
                }
            }
            finally {
                Stop-PipelineWatchers -WatcherStates @($watchState)
            }
            if (@(Get-EventSubscriber | Where-Object { $_.SourceIdentifier -like "$($watchState.Prefix).*" }).Count -ne 0) {
                throw 'Die Selbsttest-Überwachung bleibt angemeldet.'
            }

            $script:SelfTestDrainedEvents = [System.Collections.Generic.List[string]]::new()
            function Get-Event {
                [pscustomobject]@{
                    SourceIdentifier = 'PixelPhotoUploader.Selbsttest.Error'
                    EventIdentifier  = 42
                    SourceArgs       = @($null, [pscustomobject]@{ Name = 'Error'; Message = 'Zu viele Änderungen.' })
                }
            }
            function Remove-Event {
                param($EventIdentifier)
                $script:SelfTestDrainedEvents.Add([string]$EventIdentifier)
            }
            try {
                $overflowSignals = Get-AndDrainWatcherSignals -WatcherStates @(
                    [pscustomobject]@{ Prefix = 'PixelPhotoUploader.Selbsttest'; Label = 'Selbsttest-Überwachung' }
                )
                if (-not [bool]$overflowSignals.Overflow) { throw 'Ein voller Ereignispuffer wird nicht erkannt.' }
                if (@($overflowSignals.Paths).Count -ne 0) { throw 'Die Fehlmeldung erfindet geänderte Pfade.' }
                if ($script:SelfTestDrainedEvents.Count -ne 1) { throw 'Die Fehlmeldung bleibt in der Ereignisschlange stehen.' }
            }
            finally {
                Remove-Item -LiteralPath 'Function:Get-Event' -Force
                Remove-Item -LiteralPath 'Function:Remove-Event' -Force
                $script:SelfTestDrainedEvents = $null
            }

            # Eine teilweise Freigabe darf den Rest nicht blockieren: das Pixel hält einen
            # Batch nur für vollständig, wenn sein Inhalt zum Manifest passt. Windows muss
            # also seine eigene Übergabekopie verkleinen, sonst bietet die App die
            # Restdateien nie wieder an und die Automatik steht still.
            $shrinkRoot = Join-Path $tempRoot 'Schrumpfarchiv'
            $shrinkMonth = Join-Path $shrinkRoot '2026.09'
            New-Item -ItemType Directory -Path $shrinkMonth -Force | Out-Null
            for ($shrinkIndex = 1; $shrinkIndex -le 3; $shrinkIndex++) {
                $shrinkFile = Join-Path $shrinkMonth ('datei{0}.jpg' -f $shrinkIndex)
                $shrinkBytes = New-Object byte[] ($shrinkIndex * 512)
                for ($byteIndex = 0; $byteIndex -lt $shrinkBytes.Length; $byteIndex++) {
                    $shrinkBytes[$byteIndex] = [byte](($byteIndex + $shrinkIndex) % 251)
                }
                [System.IO.File]::WriteAllBytes($shrinkFile, $shrinkBytes)
                (Get-Item -LiteralPath $shrinkFile).LastWriteTimeUtc = [DateTime]::UtcNow.AddHours(-$shrinkIndex)
            }
            # Eigener Übergabe- und Kontrollordner: Batchknoten tragen einen Zeitstempel bis
            # auf die Sekunde, und dieser Testlauf hat weiter oben schon in derselben Sekunde
            # einen Batch übergeben. Geteilte Ordner würden die Szenarien vermischen.
            $shrinkStagingRoot = Join-Path $tempRoot 'Schrumpfuebergabe'
            $shrinkControlRoot = Join-Path $tempRoot 'Schrumpfkontrolle'
            New-Item -ItemType Directory -Path $shrinkStagingRoot, $shrinkControlRoot -Force | Out-Null
            $shrinkConfig = [pscustomobject]@{
                TransportMode = 'App'
                SourceRoot    = $shrinkRoot
                StagingRoot   = $shrinkStagingRoot
                ControlRoot   = $shrinkControlRoot
                BatchGiB      = 1
                StableMinutes = 0
            }
            $script:CatalogPath = Join-Path $tempRoot 'schrumpf-catalog.csv'
            $script:StagedPath = Join-Path $tempRoot 'schrumpf-staged.json'
            $script:CompletedPath = Join-Path $tempRoot 'schrumpf-completed.csv'
            [void](Update-Catalog -Config $shrinkConfig)
            if ((Select-AndStageBatch -Config $shrinkConfig -CompletionSets (Load-CompletionSets)) -ne 3) {
                throw 'Schrumpf-Selbsttest: drei Dateien wurden nicht übergeben.'
            }
            $shrinkStaged = @(Load-Staged)
            $shrinkBatchId = [string]$shrinkStaged[0].BatchId
            $shrinkDirectory = Get-AppBatchDirectory -Config $shrinkConfig -BatchId $shrinkBatchId

            $freedPaths = [System.Collections.Generic.List[string]]::new()
            foreach ($record in @($shrinkStaged[0], $shrinkStaged[1])) {
                $freedPaths.Add('/storage/emulated/0/DCIM/ResilioInbox' + [string]$record.PixelSuffix)
            }
            Save-JsonAtomic -Value ([pscustomobject]@{
                version      = 1
                receiptId    = 'teilfreigabe'
                removedPaths = @($freedPaths)
            }) -Path (Join-Path $shrinkControlRoot 'receipt-teilfreigabe.json') -Depth 5

            if ((Confirm-AppStagedBatches -Config $shrinkConfig -CompletionSets (Load-CompletionSets)) -ne 2) {
                throw 'Eine teilweise bestätigte Freigabe wurde nicht gebucht.'
            }
            if (@(Load-Staged).Count -ne 1) { throw 'Nach der Teilfreigabe muss die Restdatei vorgemerkt bleiben.' }
            if (-not (Test-Path -LiteralPath $shrinkDirectory)) { throw 'Ein teilbestätigter Batchordner wurde gelöscht.' }
            if (Test-Path -LiteralPath (Join-Path $shrinkDirectory ([string]$shrinkStaged[0].StagedName))) {
                throw 'Eine freigegebene Datei blieb in der eigenen Übergabekopie stehen.'
            }
            if (-not (Test-Path -LiteralPath (Join-Path $shrinkDirectory ([string]$shrinkStaged[2].StagedName)))) {
                throw 'Die verbliebene Datei wurde aus der Übergabekopie geworfen.'
            }
            $shrunkManifest = Get-Content -LiteralPath (Join-Path $shrinkDirectory '_batch-manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
            if ([int]$shrunkManifest.fileCount -ne 1) { throw 'Das geschrumpfte Manifest zählt eine Datei zu viel.' }
            if ([long]$shrunkManifest.bytes -ne [long]$shrinkStaged[2].Size) { throw 'Das geschrumpfte Manifest rechnet die falsche Größe.' }
            if (@(Get-ChildItem -LiteralPath $shrinkDirectory -File | Where-Object { $_.Name -notlike '_*' }).Count -ne [int]$shrunkManifest.fileCount) {
                throw ('Übergabekopie und Manifest stimmen nicht überein; das Pixel würde den Batch ignorieren. ' +
                    ((@(Get-ChildItem -LiteralPath $shrinkDirectory -File) | ForEach-Object { $_.Name }) -join '|') + ' / ' + $shrunkManifest.fileCount)
            }
            if (@(Get-ChildItem -LiteralPath $shrinkMonth -File).Count -ne 3) {
                throw 'Das Archiv hat durch die Teilfreigabe Dateien verloren.'
            }

            $restPath = '/storage/emulated/0/DCIM/ResilioInbox' + [string]$shrinkStaged[2].PixelSuffix
            Save-JsonAtomic -Value ([pscustomobject]@{
                version      = 1
                receiptId    = 'teilfreigabe-rest'
                removedPaths = @(@($freedPaths) + $restPath)
            }) -Path (Join-Path $shrinkControlRoot 'receipt-teilfreigabe-rest.json') -Depth 5
            if ((Confirm-AppStagedBatches -Config $shrinkConfig -CompletionSets (Load-CompletionSets)) -ne 1) {
                throw 'Die Restdatei der Teilfreigabe wurde nicht nachträglich bestätigt.'
            }
            if (@(Load-Staged).Count -ne 0) { throw 'Nach der vollständigen Freigabe darf nichts vorgemerkt bleiben.' }
            if (Test-Path -LiteralPath $shrinkDirectory) { throw 'Der vollständig bestätigte Batchordner blieb nach dem Schrumpfen stehen.' }
        }
        finally {
            $script:CatalogPath = $originalCatalogPath
            $script:StagedPath = $originalStagedPath
            $script:CompletedPath = $originalCompletedPath
            $script:ConfigPath = $originalConfigPath
            $script:TasksPath = $originalTasksPath
            $script:LastScanPath = $originalLastScanPath
            $script:Dashboard = $null
            $script:DashboardStamp = ''
        }

        Write-Host 'Selbsttest erfolgreich.' -ForegroundColor Green
    }
    finally {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Get-FileStamp {
    param([Parameter(Mandatory = $true)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return 'fehlt' }
    try {
        $item = Get-Item -LiteralPath $Path
        return '{0}|{1}' -f $item.Length, $item.LastWriteTimeUtc.Ticks
    }
    catch {
        return 'unklar'
    }
}

function Get-LogTail {
    param([int]$Lines = 200)

    if (-not (Test-Path -LiteralPath $script:LogPath -PathType Leaf)) { return @() }
    try {
        return @(Get-Content -LiteralPath $script:LogPath -Tail $Lines -Encoding UTF8 -ErrorAction Stop)
    }
    catch {
        return @()
    }
}

function Get-TrackedProcessCommandLine {
    param([Parameter(Mandatory = $true)][int]$ProcessId)

    try {
        $info = @(Get-CimInstance -ClassName Win32_Process -Filter "ProcessId = $ProcessId" -ErrorAction Stop)
        if ($info.Count -eq 0) { return '' }
        return [string]$info[0].CommandLine
    }
    catch {
        return ''
    }
}

function Read-Tasks {
    $map = @{}
    if (-not (Test-Path -LiteralPath $script:TasksPath -PathType Leaf)) { return $map }

    $raw = ''
    try { $raw = [string](Get-Content -LiteralPath $script:TasksPath -Raw -Encoding UTF8 -ErrorAction Stop) } catch { return $map }
    if ([string]::IsNullOrWhiteSpace($raw)) { return $map }

    $stored = $null
    try { $stored = $raw | ConvertFrom-Json } catch { return $map }

    foreach ($name in $script:TrackedTasks) {
        if ($stored.PSObject.Properties.Name -contains $name) {
            $idText = Get-PropertyText -Object $stored.$name -Name 'ProcessId'
            $processId = 0
            if ([int]::TryParse($idText, [ref]$processId) -and ($processId -gt 0)) {
                $map[$name] = [pscustomobject]@{
                    ProcessId  = $processId
                    StartedUtc = Get-PropertyText -Object $stored.$name -Name 'StartedUtc'
                }
            }
        }
    }
    return $map
}

function Write-Tasks {
    param([Parameter(Mandatory = $true)]$Map)

    $ordered = [ordered]@{}
    foreach ($name in $script:TrackedTasks) {
        if ($Map.ContainsKey($name)) {
            $entry = $Map[$name]
            $idText = Get-PropertyText -Object $entry -Name 'ProcessId'
            $processId = 0
            if (-not [int]::TryParse($idText, [ref]$processId)) { continue }
            $ordered[$name] = [pscustomobject]@{
                ProcessId  = $processId
                StartedUtc = Get-PropertyText -Object $entry -Name 'StartedUtc'
            }
        }
    }

    if ($ordered.Count -eq 0) {
        if (Test-Path -LiteralPath $script:TasksPath) { Remove-Item -LiteralPath $script:TasksPath -Force }
        return
    }
    Save-JsonAtomic -Value ([pscustomobject]$ordered) -Path $script:TasksPath -Depth 5
}

function Get-TrackedTask {
    param([Parameter(Mandatory = $true)][string]$Task)

    $map = Read-Tasks
    if (-not $map.ContainsKey($Task)) { return $null }
    $entry = $map[$Task]
    $processId = [int]$entry.ProcessId
    $process = $null
    try { $process = Get-Process -Id $processId -ErrorAction SilentlyContinue } catch { $process = $null }

    $running = $false
    $attributed = $false
    if ($null -ne $process) {
        $commandLine = Get-TrackedProcessCommandLine -ProcessId $processId
        if (-not [string]::IsNullOrWhiteSpace($commandLine)) {
            $scriptName = [System.IO.Path]::GetFileNameWithoutExtension([string]$script:ScriptPath)
            $attributed = ($commandLine -like "*$scriptName*") -and ($commandLine -like "*-Action $Task*")
            $running = $attributed
        }
        else {
            # Ohne Windows-Prozessinformationen bleibt nur der Prozessname – reicht für "läuft", nicht zum Beenden.
            $running = ([string]$process.ProcessName -match '^(powershell|pwsh)$')
        }
    }

    return [pscustomobject]@{
        Task       = $Task
        ProcessId  = $processId
        StartedUtc = [string]$entry.StartedUtc
        Running    = [bool]$running
        Attributed = [bool]$attributed
    }
}

function Start-TrackedTask {
    param([Parameter(Mandatory = $true)][ValidateSet('Watch', 'Sync', 'Preflight', 'SelfTest', 'Setup')][string]$Task)

    $existing = Get-TrackedTask -Task $Task
    if ($existing -and [bool]$existing.Running) { return $existing }

    $executable = 'powershell.exe'
    try {
        $hostPath = [string](Get-Process -Id $PID).Path
        if (-not [string]::IsNullOrWhiteSpace($hostPath)) { $executable = $hostPath }
    }
    catch { }

    $visible = [bool]($Task -in @('Setup', 'Preflight', 'SelfTest'))
    $start = @{
        FilePath         = $executable
        ArgumentList     = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', [string]$script:ScriptPath, '-Action', $Task)
        WorkingDirectory = [string]$script:AppRoot
        WindowStyle      = 'Normal'
        PassThru         = $true
    }
    if (-not $visible) { $start['WindowStyle'] = 'Hidden' }
    $process = Start-Process @start

    $startedUtc = [DateTime]::UtcNow.ToString('o')
    $map = Read-Tasks
    $map[$Task] = [pscustomobject]@{ ProcessId = [int]$process.Id; StartedUtc = $startedUtc }
    Write-Tasks -Map $map
    return [pscustomobject]@{ Task = $Task; ProcessId = [int]$process.Id; StartedUtc = $startedUtc; Running = $true; Attributed = $true }
}

function Stop-TrackedTask {
    param([Parameter(Mandatory = $true)][ValidateSet('Watch', 'Sync', 'Preflight', 'SelfTest', 'Setup')][string]$Task)

    $entry = Get-TrackedTask -Task $Task
    if (-not $entry) { return $false }

    if ([bool]$entry.Running) {
        if (-not [bool]$entry.Attributed) {
            Write-Log "Hintergrundprozess $Task (PID $($entry.ProcessId)) ist nicht eindeutig zugeordnet; er läuft weiter." 'WARN'
        }
        else {
            $process = $null
            try { $process = Get-Process -Id ([int]$entry.ProcessId) -ErrorAction SilentlyContinue } catch { $process = $null }
            if ($null -ne $process) {
                try {
                    $process.Kill()
                    [void]$process.WaitForExit(5000)
                }
                catch {
                    Write-Log "Hintergrundprozess $Task konnte nicht beendet werden: $($_.Exception.Message)" 'WARN'
                }
            }
        }
    }

    $map = Read-Tasks
    [void]$map.Remove($Task)
    Write-Tasks -Map $map
    return $true
}

function Clear-FinishedTasks {
    $map = Read-Tasks
    if ($map.Count -eq 0) { return }

    $changed = $false
    foreach ($name in @($map.Keys)) {
        $entry = Get-TrackedTask -Task $name
        if ((-not $entry) -or (-not [bool]$entry.Running)) {
            [void]$map.Remove($name)
            $changed = $true
        }
    }
    if ($changed) { Write-Tasks -Map $map }
}

function Get-NumberProperty {
    param(
        [Parameter(Mandatory = $true)]$Object,
        [Parameter(Mandatory = $true)][string]$Name,
        [double]$Default = 0
    )

    $text = Get-PropertyText -Object $Object -Name $Name
    $value = [double]0
    if ([double]::TryParse($text, [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$value)) {
        return $value
    }
    return $Default
}

function Get-ClampedValue {
    param(
        [Parameter(Mandatory = $true)][double]$Value,
        [Parameter(Mandatory = $true)][double]$Minimum,
        [Parameter(Mandatory = $true)][double]$Maximum
    )

    if ($Value -lt $Minimum) { return $Minimum }
    if ($Value -gt $Maximum) { return $Maximum }
    return $Value
}

function Get-TransportStamp {
    param([Parameter(Mandatory = $true)]$Config)

    $parts = @()
    foreach ($root in @((Get-PropertyText -Object $Config -Name 'ControlRoot'), (Get-PropertyText -Object $Config -Name 'StagingRoot'))) {
        $count = -1
        if (-not [string]::IsNullOrWhiteSpace($root)) {
            try { $count = @(Get-ChildItem -LiteralPath $root -Force -ErrorAction SilentlyContinue).Count } catch { $count = -1 }
        }
        $parts += "$root=$count"
    }
    return ($parts -join ';')
}

function Get-Dashboard {
    $empty = [pscustomobject]@{
        Configured     = $false
        Transport      = ''
        ArchiveRoot    = ''
        StagingRoot    = ''
        ControlRoot    = ''
        BatchGiB       = 0.0
        StableMinutes  = 0.0
        RescanMinutes  = 0.0
        CatalogFiles   = 0
        OpenFiles      = 0
        OpenGiB        = 0.0
        StagedFiles    = 0
        CompletedFiles = 0
        ReceiptFiles   = 0
        BatchFolders   = 0
        Detail         = 'Das Programm ist noch nicht eingerichtet.'
    }

    $config = $null
    try { $config = Load-Config }
    catch {
        $script:DashboardStamp = ''
        $script:Dashboard = $null
        $empty.Detail = $_.Exception.Message
        return $empty
    }

    $stamp = @(
        (Get-FileStamp -Path $script:ConfigPath),
        (Get-FileStamp -Path $script:CatalogPath),
        (Get-FileStamp -Path $script:CompletedPath),
        (Get-FileStamp -Path $script:StagedPath),
        (Get-FileStamp -Path $script:TasksPath),
        (Get-TransportStamp -Config $config)
    ) -join ';'
    if (($stamp -eq [string]$script:DashboardStamp) -and $script:Dashboard) { return $script:Dashboard }

    try {
        $catalog = @(Load-Catalog)
        $completionSets = Load-CompletionSets
        $staged = @(Load-Staged)
        $open = @($catalog | Where-Object {
            ([string]$_.Stable -eq 'True') -and (-not $completionSets.Fingerprints.Contains([string]$_.Fingerprint))
        })
        $openBytes = [long]0
        foreach ($entry in $open) { $openBytes += [long]$entry.Size }

        $receipts = 0
        $batchFolders = 0
        $controlRoot = [string](Get-PropertyText -Object $config -Name 'ControlRoot')
        $stagingRoot = [string](Get-PropertyText -Object $config -Name 'StagingRoot')
        if ((Test-AppTransport -Config $config) -and (-not [string]::IsNullOrWhiteSpace($controlRoot))) {
            try { $receipts = @(Get-ChildItem -LiteralPath $controlRoot -Filter 'receipt-*.json' -File -ErrorAction SilentlyContinue).Count } catch { $receipts = 0 }
        }
        if ((Test-AppTransport -Config $config) -and (-not [string]::IsNullOrWhiteSpace($stagingRoot))) {
            $batchParent = Join-Path $stagingRoot $script:AppBatchFolderName
            try { $batchFolders = @(Get-ChildItem -LiteralPath $batchParent -Directory -ErrorAction SilentlyContinue).Count } catch { $batchFolders = 0 }
        }

        $data = [pscustomobject]@{
            Configured     = $true
            Transport      = [string]$config.TransportMode
            ArchiveRoot    = [string](Get-PropertyText -Object $config -Name 'SourceRoot')
            StagingRoot    = $stagingRoot
            ControlRoot    = $controlRoot
            BatchGiB       = Get-ClampedValue -Value (Get-NumberProperty -Object $config -Name 'BatchGiB' -Default 5) -Minimum $script:MinBatchGiB -Maximum $script:MaxBatchGiB
            StableMinutes  = Get-NumberProperty -Object $config -Name 'StableMinutes' -Default 2
            RescanMinutes  = Get-NumberProperty -Object $config -Name 'RescanMinutes' -Default 360
            CatalogFiles   = $catalog.Count
            OpenFiles      = $open.Count
            OpenGiB        = ($openBytes / 1GB)
            StagedFiles    = $staged.Count
            CompletedFiles = $completionSets.Fingerprints.Count
            ReceiptFiles   = $receipts
            BatchFolders   = $batchFolders
            Detail         = ''
        }
        $script:DashboardStamp = $stamp
        $script:Dashboard = $data
        return $data
    }
    catch {
        if ($script:Dashboard) { return $script:Dashboard }
        $empty.Detail = $_.Exception.Message
        return $empty
    }
}

function Invoke-FullPass {
    $config = Load-Config
    if (Test-AppTransport -Config $config) {
        Invoke-AppPreflight -Config $config
    }
    else {
        Ensure-Adb
        Assert-DeviceReady -Config $config
    }

    Invoke-ImportPipeline -Config $config | Out-Null
    Update-Catalog -Config $config | Out-Null

    $completionSets = Load-CompletionSets
    if (Test-AppTransport -Config $config) {
        Repair-AppBatches -Config $config
    }
    else {
        Repair-InterruptedTransfers -Config $config
    }

    $confirmed = [int](Process-AllPixelMedia -Config $config -CompletionSets $completionSets)
    $stagedNow = [int](Select-AndStageBatch -Config $config -CompletionSets $completionSets)
    Write-Log ('Vollabgleich beendet: {0:N0} Dateien bestätigt, {1:N0} neu übergeben.' -f $confirmed, $stagedNow) 'OK'
    return [pscustomobject]@{ Confirmed = $confirmed; Staged = $stagedNow }
}

function Get-GuiPalette {
    if (-not $script:GuiPalette) {
        $script:GuiPalette = [pscustomobject]@{
            Text       = [System.Drawing.Color]::FromArgb(255, 33, 37, 45)
            Muted      = [System.Drawing.Color]::FromArgb(255, 104, 112, 126)
            Surface    = [System.Drawing.Color]::White
            Card       = [System.Drawing.Color]::FromArgb(255, 246, 248, 251)
            Border     = [System.Drawing.Color]::FromArgb(255, 213, 219, 228)
            Accent     = [System.Drawing.Color]::FromArgb(255, 45, 105, 200)
            AccentDark = [System.Drawing.Color]::FromArgb(255, 32, 79, 152)
            AccentSoft = [System.Drawing.Color]::FromArgb(255, 235, 242, 252)
            HoverSoft  = [System.Drawing.Color]::FromArgb(255, 240, 244, 250)
        }
    }
    return $script:GuiPalette
}

function New-GuiLabel {
    param(
        [string]$Text = '',
        [int]$Width = 170,
        [int]$Height = 22,
        [single]$FontSize = 0,
        [switch]$Bold,
        [string]$ColorName = '',
        [switch]$Muted,
        [int]$X = -1,
        [int]$Y = -1
    )

    $label = New-Object System.Windows.Forms.Label
    $label.Text = $Text
    $label.AutoSize = $false
    $label.Size = New-Object System.Drawing.Size($Width, $Height)
    $size = $label.Font.Size
    if ($FontSize -gt 0) { $size = $FontSize }
    $style = [System.Drawing.FontStyle]::Regular
    if ($Bold) { $style = [System.Drawing.FontStyle]::Bold }
    $label.Font = New-Object System.Drawing.Font('Segoe UI', $size, $style)
    if ($Muted) { $label.ForeColor = (Get-GuiPalette).Muted }
    if ($ColorName) { $label.ForeColor = [System.Drawing.Color]::FromName($ColorName) }
    Set-GuiPosition -Control $label -X $X -Y $Y
    return $label
}

function Set-GuiPosition {
    param(
        [Parameter(Mandatory = $true)]$Control,
        [int]$X = -1,
        [int]$Y = -1
    )

    if ($X -ge 0) { $Control.Left = $X }
    if ($Y -ge 0) { $Control.Top = $Y }
}

function New-GuiButton {
    param(
        [Parameter(Mandatory = $true)][string]$Text,
        [Parameter(Mandatory = $true)]$OnClick,
        [string]$Hint = '',
        [int]$Width = 178,
        [switch]$Primary
    )

    $palette = Get-GuiPalette
    $button = New-Object System.Windows.Forms.Button
    $button.Text = $Text
    $button.Size = New-Object System.Drawing.Size($Width, 38)
    $button.Margin = New-Object System.Windows.Forms.Padding(4, 0, 4, 0)
    $button.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $button.FlatAppearance.BorderSize = 1
    $button.FlatAppearance.BorderColor = $palette.Border
    $button.UseVisualStyleBackColor = $false
    $button.BackColor = $palette.Surface
    $button.ForeColor = $palette.Text
    $button.FlatAppearance.MouseOverBackColor = $palette.HoverSoft
    $button.FlatAppearance.MouseDownBackColor = $palette.AccentSoft
    if ($Primary) {
        # Der Einschalter ist die Hauptaktion im Fenster und deshalb farblich hervorgehoben.
        $button.BackColor = $palette.Accent
        $button.ForeColor = [System.Drawing.Color]::White
        $button.FlatAppearance.BorderColor = $palette.AccentDark
        $button.FlatAppearance.MouseOverBackColor = $palette.AccentDark
        $button.FlatAppearance.MouseDownBackColor = $palette.Accent
    }
    $button.Tag = $OnClick
    $button.Add_Click({ param($sender, $event) & $sender.Tag })
    if ($Hint -and $script:GuiToolTip) { [void]$script:GuiToolTip.SetToolTip($button, $Hint) }
    return $button
}

function New-GuiButtonRow {
    param([Parameter(Mandatory = $true)][AllowEmptyCollection()][object[]]$Buttons)

    # Ein Raster statt einer Flussgruppe: damit bleibt die Zeile garantiert einzeilig,
    # weil die Knöpfe nirgends mehr hin umbrechen können. Die Breite folgt dem Text.
    $row = New-Object System.Windows.Forms.TableLayoutPanel
    $row.Dock = 'Fill'
    $row.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 4)
    $row.ColumnCount = @($Buttons).Count
    $row.RowCount = 1
    [void]$row.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, [single]100)))

    $weights = [System.Collections.Generic.List[int]]::new()
    $totalWeight = 0
    foreach ($control in @($Buttons)) {
        $weight = [Math]::Max(12, ([string]$control.Text).Length)
        $weights.Add($weight)
        $totalWeight += $weight
    }
    for ($column = 0; $column -lt $weights.Count; $column++) {
        $share = [single](100 * $weights[$column] / $totalWeight)
        [void]$row.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, $share)))
        $control = @($Buttons)[$column]
        $control.Dock = 'Fill'
        [void]$row.Controls.Add($control, $column, 0)
    }
    return $row
}

function New-GuiCard {
    param([Parameter(Mandatory = $true)][string]$CaptionText)

    $palette = Get-GuiPalette
    $panel = New-Object System.Windows.Forms.Panel
    $panel.Size = New-Object System.Drawing.Size(168, 92)
    $panel.Margin = New-Object System.Windows.Forms.Padding(0, 0, 10, 0)
    $panel.BackColor = $palette.Card
    $accentBar = New-Object System.Windows.Forms.Panel
    $accentBar.Dock = 'Top'
    $accentBar.Height = 3
    $accentBar.BackColor = $palette.Accent
    $valueLabel = New-GuiLabel -Text '-' -Width 152 -Height 30 -FontSize 16 -Bold -X 8 -Y 14
    $captionLabel = New-GuiLabel -Text $CaptionText -Width 152 -Height 34 -FontSize 9 -Muted -X 8 -Y 46
    [void]$panel.Controls.Add($valueLabel)
    [void]$panel.Controls.Add($captionLabel)
    [void]$panel.Controls.Add($accentBar)
    return [pscustomobject]@{ Panel = $panel; Value = $valueLabel; Caption = $captionLabel }
}

function Get-GuiLevelColor {
    param([string]$Level = 'INFO')

    switch ($Level) {
        'WARN'  { return [System.Drawing.Color]::DarkOrange }
        'ERROR' { return [System.Drawing.Color]::Firebrick }
        'OK'    { return [System.Drawing.Color]::ForestGreen }
        default { return [System.Drawing.Color]::Black }
    }
}

function Set-GuiLog {
    param([Parameter(Mandatory = $true)]$Box)

    $lines = @(Get-LogTail -Lines 200)
    $box.SuspendLayout()
    $box.Clear()
    foreach ($line in $lines) {
        $level = 'INFO'
        if ([string]$line -match '\[(?<level>INFO|WARN|ERROR|OK)\]') { $level = [string]$Matches['level'] }
        $box.SelectionStart = $box.TextLength
        $box.SelectionLength = 0
        $box.SelectionColor = Get-GuiLevelColor -Level $level
        $box.SelectedText = [string]$line + "`r`n"
    }
    $box.SelectionColor = Get-GuiLevelColor
    $box.Select($box.TextLength, 0)
    $box.ScrollToCaret()
    $box.ResumeLayout()
}

function Format-GuiTime {
    param([Parameter(Mandatory = $true)][string]$UtcRoundTrip)

    $moment = [DateTime]::MinValue
    if ([DateTime]::TryParse($UtcRoundTrip, [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::RoundtripKind, [ref]$moment)) {
        return $moment.ToLocalTime().ToString('HH:mm:ss')
    }
    return '-'
}

function Format-GuiErrorText {
    param([Parameter(Mandatory = $true)][object]$Problem)

    if ($Problem -isnot [System.Management.Automation.ErrorRecord]) { return [string]$Problem }

    $message = [string]$Problem.Exception.Message
    if ([string]::IsNullOrWhiteSpace($message)) { $message = [string]$Problem }

    $position = ''
    if ($Problem.InvocationInfo) { $position = [string]$Problem.InvocationInfo.PositionMessage }
    if ([string]::IsNullOrWhiteSpace($position)) { return $message }
    return "$message`r`n`r`n$position"
}

function Show-GuiError {
    param([Parameter(Mandatory = $true)][object]$Problem)

    $text = Format-GuiErrorText -Problem $Problem
    Write-Log ($text -replace '\r?\n', ' | ') 'ERROR'
    $form = $null
    if ($script:Gui) { $form = $script:Gui['form'] }
    [void][System.Windows.Forms.MessageBox]::Show(
        $form, $text, 'Pixel Photo Uploader',
        [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)
}

function Get-PhoneChecklist {
    param([Parameter(Mandatory = $true)]$Dashboard)

    $lines = [System.Collections.Generic.List[string]]::new()
    if ([string]$Dashboard.Transport -eq 'App') {
        $lines.Add('Pixel einrichten – App und Resilio, ohne USB-Kabel')
        $lines.Add('')
        $lines.Add('1. App "Pixel Photo Companion" installiert, Dateizugriff und Bedienungshilfe erlaubt.')
        $lines.Add('2. Kontrollordner der App auf dem Pixel: /storage/emulated/0/Documents/PixelPhotoControl')
        $lines.Add("3. Resilio-Freigabe Windows -> Pixel: $($Dashboard.StagingRoot)")
        $lines.Add('   Pixel-Ziel /storage/emulated/0/DCIM/ResilioInbox, nur lesend, Full Sync an,')
        $lines.Add('   "Overwrite any changed files" aus.')
        $lines.Add("4. Resilio-Freigabe Pixel -> Windows: Kontrollordner empfangen in $($Dashboard.ControlRoot)")
        $lines.Add('5. Google Fotos: richtiges Konto, Sicherung an, Originalqualität,')
        $lines.Add('   Geräteordner "ResilioInbox" in "Back up device folders" einschalten.')
        $lines.Add('6. In der App "Überwachung starten"; beim Start eines Batches muss der Pixel entsperrt sein.')
        $lines.Add('')
        $lines.Add('Abgeglichen wird nur der Pfadteil /WindowsBatches/<Batch>/<Datei>.')
        $lines.Add('Der Speicherort auf dem Pixel darf abweichen, ohne dass Windows etwas umstellen müsste.')
    }
    else {
        $lines.Add('Pixel einrichten – ADB (' + [string]$Dashboard.Transport + ')')
        $lines.Add('')
        $lines.Add('1. USB-Debugging am Pixel eingeschaltet, Rechner autorisiert.')
        $lines.Add('2. Google Fotos: richtiges Konto, Sicherung an, Originalqualität.')
        $lines.Add('3. Pixel entsperrt lassen, während Google Fotos den Batch prüft.')
        $lines.Add('')
        $lines.Add('Für diesen Weg gehört einmalig ein USB-Kabel zur Einrichtung.')
    }
    $lines.Add('')
    $lines.Add('Sicherheit')
    $lines.Add('- Das Archiv wird für die Übergabe nur kopiert; gelöscht wird ausschließlich der eigene Batchordner.')
    $lines.Add('- Ohne Rückbeleg der App bleibt der Batchordner stehen; es startet kein zweiter Batch.')
    return ($lines -join "`r`n")
}

function Reset-GuiSettings {
    if (-not $script:Gui) { return }
    $g = $script:Gui
    $dash = Get-Dashboard
    try {
        $g['batchBox'].Value = [decimal](Get-ClampedValue -Value $dash.BatchGiB -Minimum $script:MinBatchGiB -Maximum $script:MaxBatchGiB)
        $g['stableBox'].Value = [decimal](Get-ClampedValue -Value ($dash.StableMinutes * 60) -Minimum 0 -Maximum $script:MaxStableSeconds)
        $g['rescanBox'].Value = [decimal](Get-ClampedValue -Value $dash.RescanMinutes -Minimum 5 -Maximum 10080)
        $paths = "Archiv (wird nur kopiert):`r`n$($dash.ArchiveRoot)`r`n`r`nResilio-Übergabe an das Pixel:`r`n$($dash.StagingRoot)`r`n`r`nRückbelege des Pixels:`r`n$($dash.ControlRoot)"
        if (-not [bool]$dash.Configured) { $paths = [string]$dash.Detail }
        $g['pathsBox'].Text = $paths
        $g['checkBox'].Text = Get-PhoneChecklist -Dashboard $dash
    }
    catch { }
}

function Update-GuiState {
    if (-not $script:Gui) { return }
    $g = $script:Gui
    try {
        Clear-FinishedTasks
        $dash = Get-Dashboard
        $watch = Get-TrackedTask -Task 'Watch'
        $sync = Get-TrackedTask -Task 'Sync'

        $mode = 'nicht eingerichtet'
        switch ([string]$dash.Transport) {
            'App'  { $mode = 'Android-App + Resilio' }
            'WiFi' { $mode = 'WLAN-ADB' }
            'USB'  { $mode = 'USB-ADB' }
        }
        $g['subtitle'].Text = ('Übertragung: {0} · Batch {1:N1} GiB · Dateien müssen {2:N0} s unverändert sein' -f $mode, $dash.BatchGiB, ($dash.StableMinutes * 60))

        $g['cardcatalog'].Value.Text = ('{0:N0}' -f $dash.CatalogFiles)
        $g['cardopen'].Value.Text = ('{0:N0}' -f $dash.OpenFiles)
        $g['cardopen'].Caption.Text = ('offen (stabil) · {0:N2} GiB' -f $dash.OpenGiB)
        $g['cardstaged'].Value.Text = ('{0:N0}' -f $dash.StagedFiles)
        $g['cardcompleted'].Value.Text = ('{0:N0}' -f $dash.CompletedFiles)
        $g['cardreceipts'].Value.Text = ('{0:N0}' -f $dash.ReceiptFiles)
        $g['cardreceipts'].Caption.Text = ('Rückbelege · Batchordner: {0:N0}' -f $dash.BatchFolders)

        $ready = [bool]$dash.Configured
        $g['runButton'].Enabled = $ready
        $g['syncButton'].Enabled = $ready
        $g['preflightButton'].Enabled = $ready

        $runText = 'Überwachung starten'
        $runHint = 'Dauerbetrieb als eigener Prozess; läuft auch nach dem Schließen dieses Fensters weiter.'
        if ($ready -and $watch -and [bool]$watch.Running) {
            $runText = 'Überwachung beenden'
            $runHint = ('PID {0} · läuft seit {1}' -f $watch.ProcessId, (Format-GuiTime ([string]$watch.StartedUtc)))
        }
        $g['runButton'].Text = $runText
        if ($script:GuiToolTip) { [void]$script:GuiToolTip.SetToolTip($g['runButton'], $runHint) }

        $syncText = 'Jetzt abgleichen'
        if ($ready -and $sync -and [bool]$sync.Running) { $syncText = 'Abgleich läuft …' }
        $g['syncButton'].Text = $syncText

        $status = [string]$dash.Detail
        if ($ready) {
            $parts = [System.Collections.Generic.List[string]]::new()
            if ($watch -and [bool]$watch.Running) { $parts.Add("Überwachung läuft (PID $($watch.ProcessId))") }
            else { $parts.Add('Überwachung aus') }
            if ($sync -and [bool]$sync.Running) { $parts.Add("Vollabgleich läuft (PID $($sync.ProcessId))") }
            foreach ($name in @('Preflight', 'SelfTest', 'Setup')) {
                $task = Get-TrackedTask -Task $name
                if ($task -and [bool]$task.Running) { $parts.Add("$name läuft (PID $($task.ProcessId))") }
            }
            $parts.Add("Protokoll: $script:LogPath")
            $status = ($parts -join '   ·   ')
        }
        $g['statusLabel'].ForeColor = (Get-GuiPalette).Muted
        $g['statusLabel'].Text = $status

        $logStamp = Get-FileStamp -Path $script:LogPath
        if ($logStamp -ne [string]$g['logStamp']) {
            $g['logStamp'] = $logStamp
            Set-GuiLog -Box $g['logBox']
        }

        $configStamp = Get-FileStamp -Path $script:ConfigPath
        if ($configStamp -ne [string]$g['configStamp']) {
            $g['configStamp'] = $configStamp
            Reset-GuiSettings
        }
    }
    catch {
        if ($g['statusLabel']) {
            # Eine Fehlerzeile in der Statusleiste ist sonst leicht zu übersehen.
            $g['statusLabel'].ForeColor = [System.Drawing.Color]::Firebrick
            $g['statusLabel'].Text = ('Anzeige konnte nicht aktualisiert werden: {0}' -f ((Format-GuiErrorText -Problem $_) -replace '\s*\r?\n\s*', ' · '))
        }
    }
}

function Show-MainWindow {
    if ([System.Threading.Thread]::CurrentThread.GetApartmentState() -ne [System.Threading.ApartmentState]::STA) {
        throw 'Die Oberfläche braucht Windows PowerShell im STA-Modus. Bitte per Doppelklick auf die Startdatei öffnen.'
    }
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [System.Windows.Forms.Application]::EnableVisualStyles()

    $script:GuiToolTip = New-Object System.Windows.Forms.ToolTip
    $palette = Get-GuiPalette
    $form = New-Object System.Windows.Forms.Form
    $form.Text = "Pixel Photo Uploader $script:AppVersion  ·  $PSScriptRoot"
    $form.Font = New-Object System.Drawing.Font('Segoe UI', [single]9.75)
    $form.ClientSize = New-Object System.Drawing.Size(940, 664)
    $form.MinimumSize = New-Object System.Drawing.Size(900, 620)
    $form.BackColor = $palette.Surface
    $form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen

    $script:Gui = @{
        form            = $form
        subtitle        = $null
        statusLabel     = $null
        runButton       = $null
        syncButton      = $null
        preflightButton = $null
        logBox          = $null
        pathsBox        = $null
        checkBox        = $null
        batchBox        = $null
        stableBox       = $null
        rescanBox       = $null
        settingsInfo    = $null
        logStamp        = ''
        configStamp     = ''
    }

    $root = New-Object System.Windows.Forms.TableLayoutPanel
    $root.Dock = 'Fill'
    $root.ColumnCount = 1
    $root.RowCount = 3
    [void]$root.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, [single]62)))
    [void]$root.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, [single]100)))
    [void]$root.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, [single]24)))

    $header = New-Object System.Windows.Forms.Panel
    $header.Dock = 'Fill'
    $headerRule = New-Object System.Windows.Forms.Panel
    $headerRule.Dock = 'Bottom'
    $headerRule.Height = 1
    $headerRule.BackColor = $palette.Border
    $title = New-GuiLabel -Text "Pixel Photo Uploader $script:AppVersion" -Width 620 -Height 26 -FontSize 14 -Bold -X 14 -Y 8
    $subtitle = New-GuiLabel -Text 'Wird geladen …' -Width 910 -Height 20 -Muted -X 16 -Y 36
    [void]$header.Controls.Add($title)
    [void]$header.Controls.Add($subtitle)
    [void]$header.Controls.Add($headerRule)
    $script:Gui['subtitle'] = $subtitle

    $tabs = New-Object System.Windows.Forms.TabControl
    $tabs.Dock = 'Fill'
    $tabs.Padding = New-Object System.Windows.Forms.Padding(16, 5, 16, 5)
    $status = New-Object System.Windows.Forms.StatusStrip
    $status.BackColor = $palette.Surface
    $status.SizingGrip = $false
    $statusLabel = New-Object System.Windows.Forms.ToolStripStatusLabel
    $statusLabel.Text = 'Wird geladen …'
    $statusLabel.Spring = $true
    $statusLabel.ForeColor = $palette.Muted
    $statusLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    [void]$status.Items.Add($statusLabel)
    $script:Gui['statusLabel'] = $statusLabel

    $tabRun = New-Object System.Windows.Forms.TabPage
    $tabRun.Text = 'Betrieb'
    $runLayout = New-Object System.Windows.Forms.TableLayoutPanel
    $runLayout.Dock = 'Fill'
    $runLayout.ColumnCount = 1
    $runLayout.RowCount = 3
    $runLayout.Padding = New-Object System.Windows.Forms.Padding(10, 10, 10, 6)
    [void]$runLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, [single]100)))
    [void]$runLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, [single]52)))
    [void]$runLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, [single]100)))

    $cardPanel = New-Object System.Windows.Forms.FlowLayoutPanel
    $cardPanel.Dock = 'Fill'
    $cardPanel.WrapContents = $false
    foreach ($card in @(
            [pscustomobject]@{ Key = 'cardcatalog'; Caption = 'Dateien im Archiv' },
            [pscustomobject]@{ Key = 'cardopen'; Caption = 'offen (stabil)' },
            [pscustomobject]@{ Key = 'cardstaged'; Caption = 'im Batch ans Pixel' },
            [pscustomobject]@{ Key = 'cardcompleted'; Caption = 'von Google Fotos bestätigt' },
            [pscustomobject]@{ Key = 'cardreceipts'; Caption = 'Rückbelege der App' })) {
        $guiCard = New-GuiCard -CaptionText $card.Caption
        [void]$cardPanel.Controls.Add($guiCard.Panel)
        $script:Gui[$card.Key] = $guiCard
    }

    $onToggleWatch = {
        try {
            $watch = Get-TrackedTask -Task 'Watch'
            if ($watch -and [bool]$watch.Running) {
                [void](Stop-TrackedTask -Task 'Watch')
            }
            else {
                [void](Stop-TrackedTask -Task 'Sync')
                [void](Start-TrackedTask -Task 'Watch')
            }
        }
        catch { Show-GuiError $_ }
        Update-GuiState
    }
    $onSync = {
        try {
            $current = Get-TrackedTask -Task 'Sync'
            if ((-not $current) -or (-not [bool]$current.Running)) {
                [void](Stop-TrackedTask -Task 'Watch')
                [void](Start-TrackedTask -Task 'Sync')
            }
        }
        catch { Show-GuiError $_ }
        Update-GuiState
    }
    $onPreflight = {
        try { [void](Start-TrackedTask -Task 'Preflight') } catch { Show-GuiError $_ }
        Update-GuiState
    }
    $onSetup = {
        try { [void](Start-TrackedTask -Task 'Setup') } catch { Show-GuiError $_ }
        Update-GuiState
    }
    $onSelfTest = {
        try { [void](Start-TrackedTask -Task 'SelfTest') } catch { Show-GuiError $_ }
        Update-GuiState
    }
    $onOpenLog = {
        try { [void](Start-Process -FilePath 'explorer.exe' -ArgumentList ('/select,"' + [string]$script:LogPath + '"')) }
        catch { Show-GuiError $_ }
    }

    $runButton = New-GuiButton -Text 'Überwachung starten' -OnClick $onToggleWatch -Primary `
        -Hint 'Dauerbetrieb als eigener Prozess; läuft auch nach dem Schließen dieses Fensters weiter.'
    $syncButton = New-GuiButton -Text 'Jetzt abgleichen' -OnClick $onSync `
        -Hint 'Ein Durchlauf: einsortieren, katalogisieren, Rückbelege holen, nächsten Batch übergeben.'
    $preflightButton = New-GuiButton -Text 'Übergabe prüfen' -OnClick $onPreflight `
        -Hint 'Prüft Übergabe- und Rückbelegordner in einem separaten Fenster.'
    $setupButton = New-GuiButton -Text 'Einrichtung' -OnClick $onSetup `
        -Hint 'Die geführte Einrichtung mit den Ordnerabfragen läuft in einem Konsolenfenster.'
    $selfTestButton = New-GuiButton -Text 'Selbsttest' -OnClick $onSelfTest `
        -Hint 'Arbeitet mit Kopien in einem temporären Ordner; das Archiv bleibt unverändert.'
    $logButton = New-GuiButton -Text 'Protokoll öffnen' -OnClick $onOpenLog
    $buttonPanel = New-GuiButtonRow -Buttons @($runButton, $syncButton, $preflightButton, $setupButton, $selfTestButton, $logButton)
    $script:Gui['runButton'] = $runButton
    $script:Gui['syncButton'] = $syncButton
    $script:Gui['preflightButton'] = $preflightButton

    $logGroup = New-Object System.Windows.Forms.GroupBox
    $logGroup.Text = 'Protokoll'
    $logGroup.Dock = 'Fill'
    $logGroup.ForeColor = $palette.Text
    $logGroup.Padding = New-Object System.Windows.Forms.Padding(8, 2, 8, 8)
    $logGroup.Margin = New-Object System.Windows.Forms.Padding(4, 4, 4, 0)
    $logBox = New-Object System.Windows.Forms.RichTextBox
    $logBox.Dock = 'Fill'
    $logBox.ReadOnly = $true
    $logBox.BorderStyle = [System.Windows.Forms.BorderStyle]::None
    $logBox.Font = New-Object System.Drawing.Font('Consolas', [single]9)
    $logBox.BackColor = [System.Drawing.Color]::White
    [void]$logGroup.Controls.Add($logBox)
    $script:Gui['logBox'] = $logBox

    [void]$runLayout.Controls.Add($cardPanel, 0, 0)
    [void]$runLayout.Controls.Add($buttonPanel, 0, 1)
    [void]$runLayout.Controls.Add($logGroup, 0, 2)
    [void]$tabRun.Controls.Add($runLayout)

    $tabSettings = New-Object System.Windows.Forms.TabPage
    $tabSettings.Text = 'Einstellungen'
    $settingsLayout = New-Object System.Windows.Forms.TableLayoutPanel
    $settingsLayout.Dock = 'Fill'
    $settingsLayout.ColumnCount = 2
    $settingsLayout.RowCount = 6
    $settingsLayout.Padding = New-Object System.Windows.Forms.Padding(14, 14, 14, 10)
    [void]$settingsLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, [single]320)))
    [void]$settingsLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, [single]100)))
    foreach ($height in @(34, 34, 34, 46, 26)) {
        [void]$settingsLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, [single]$height)))
    }
    [void]$settingsLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, [single]100)))

    $batchBox = New-Object System.Windows.Forms.NumericUpDown
    $batchBox.Minimum = [decimal]$script:MinBatchGiB
    $batchBox.Maximum = [decimal]$script:MaxBatchGiB
    $batchBox.DecimalPlaces = 2
    $batchBox.Increment = [decimal]0.5
    $batchBox.Width = 130
    $stableBox = New-Object System.Windows.Forms.NumericUpDown
    $stableBox.Minimum = [decimal]0
    $stableBox.Maximum = [decimal]$script:MaxStableSeconds
    $stableBox.Increment = [decimal]15
    $stableBox.ThousandsSeparator = $true
    $stableBox.Width = 130
    $rescanBox = New-Object System.Windows.Forms.NumericUpDown
    $rescanBox.Minimum = [decimal]5
    $rescanBox.Maximum = [decimal]10080
    $rescanBox.Increment = [decimal]60
    $rescanBox.ThousandsSeparator = $true
    $rescanBox.Width = 130
    foreach ($field in @($batchBox, $stableBox, $rescanBox)) {
        $field.Height = 26
    }
    $script:Gui['batchBox'] = $batchBox
    $script:Gui['stableBox'] = $stableBox
    $script:Gui['rescanBox'] = $rescanBox

    $settingRows = @(
        [pscustomobject]@{
            Text  = ('Maximale Batchgröße (GiB, {0}–{1})' -f $script:MinBatchGiB, $script:MaxBatchGiB)
            Field = $batchBox
            Row   = 0
            Hint  = 'So viel muss das Pixel frei haben – die App prüft das vor der Übergabe nicht.' + [Environment]::NewLine +
                    'Der Übergabeordner auf dem Windows-Rechner braucht dieselbe Menge Platz.'
        },
        [pscustomobject]@{
            Text  = ('Dateien müssen unverändert sein (Sekunden, 0–{0})' -f $script:MaxStableSeconds)
            Field = $stableBox
            Row   = 1
            Hint  = 'Kurze Zeit holt neue Fotos schneller ins Archiv.' + [Environment]::NewLine +
                    'Bei Dropbox und OneDrive soll sie lang genug sein, dass eine Datei fertig geschrieben ist.'
        },
        [pscustomobject]@{
            Text  = 'Archiv-Grundabgleich spätestens alle (Minuten)'
            Field = $rescanBox
            Row   = 2
            Hint  = 'Neue, geänderte und gelöschte Dateien erkennt die Überwachung weiterhin sofort – auch im Archiv.' + [Environment]::NewLine +
                     'Der Grundabgleich durchsucht zusätzlich das gesamte Archiv und gilt als Sicherheitsnetz für verpasste Meldungen.'
        }
    )
    foreach ($row in $settingRows) {
        $label = New-GuiLabel -Text $row.Text -Width 320 -Height 26
        if ([string]$row.Hint -and $script:GuiToolTip) { [void]$script:GuiToolTip.SetToolTip($label, [string]$row.Hint) }
        $row.Field.Anchor = [System.Windows.Forms.AnchorStyles]::Left
        $row.Field.Margin = New-Object System.Windows.Forms.Padding(0, 4, 0, 0)
        [void]$settingsLayout.Controls.Add($label, 0, $row.Row)
        [void]$settingsLayout.Controls.Add($row.Field, 1, $row.Row)
    }

    $onSaveSettings = {
        $g = $script:Gui
        try {
            $config = Load-Config
            $batchGiB = [double]$g['batchBox'].Value
            $stableSeconds = [double]$g['stableBox'].Value
            $rescanMinutes = [double]$g['rescanBox'].Value
            $config | Add-Member -NotePropertyName BatchGiB -NotePropertyValue $batchGiB -Force
            $config | Add-Member -NotePropertyName StableMinutes -NotePropertyValue (Get-StableMinutesFromSeconds -Seconds $stableSeconds) -Force
            $config | Add-Member -NotePropertyName RescanMinutes -NotePropertyValue $rescanMinutes -Force
            Save-JsonAtomic -Value $config -Path $script:ConfigPath
            Write-Log ('Oberfläche: Einstellungen gespeichert – Batch {0:N2} GiB, Stabilität {1:N0} s, Archiv-Grundabgleich alle {2:N0} min.' -f $batchGiB, $stableSeconds, $rescanMinutes) 'OK'
            $g['settingsInfo'].ForeColor = (Get-GuiPalette).Muted
            $g['settingsInfo'].Text = 'Gespeichert. Wirksam, sobald die Überwachung neu gestartet wird.'
            $g['configStamp'] = ''
        }
        catch {
            $g['settingsInfo'].ForeColor = [System.Drawing.Color]::Firebrick
            $g['settingsInfo'].Text = "Speichern fehlgeschlagen: $($_.Exception.Message)"
            Show-GuiError $_
        }
        Update-GuiState
    }
    $saveButton = New-GuiButton -Text 'Speichern' -OnClick $onSaveSettings -Width 150
    $saveButton.Anchor = [System.Windows.Forms.AnchorStyles]::Left
    $saveButton.Margin = New-Object System.Windows.Forms.Padding(4, 6, 0, 0)
    [void]$settingsLayout.Controls.Add($saveButton, 0, 3)
    $settingsInfo = New-GuiLabel -Text 'Die Werte gelten, sobald die Überwachung neu gestartet wurde.' -Width 880 -Height 24 -Muted
    $settingsInfo.Anchor = [System.Windows.Forms.AnchorStyles]::Left
    [void]$settingsLayout.Controls.Add($settingsInfo, 0, 4)
    $settingsLayout.SetColumnSpan($settingsInfo, 2)
    $script:Gui['settingsInfo'] = $settingsInfo

    $pathsGroup = New-Object System.Windows.Forms.GroupBox
    $pathsGroup.Text = 'Ordner – geändert über die Einrichtung'
    $pathsGroup.Dock = 'Fill'
    $pathsGroup.ForeColor = $palette.Text
    $pathsGroup.Margin = New-Object System.Windows.Forms.Padding(0, 6, 0, 0)
    $pathsBox = New-Object System.Windows.Forms.TextBox
    $pathsBox.Dock = 'Fill'
    $pathsBox.Multiline = $true
    $pathsBox.ReadOnly = $true
    $pathsBox.ScrollBars = [System.Windows.Forms.ScrollBars]::Vertical
    $pathsBox.Font = New-Object System.Drawing.Font('Consolas', [single]9)
    [void]$pathsGroup.Controls.Add($pathsBox)
    [void]$settingsLayout.Controls.Add($pathsGroup, 0, 5)
    $settingsLayout.SetColumnSpan($pathsGroup, 2)
    $script:Gui['pathsBox'] = $pathsBox
    [void]$tabSettings.Controls.Add($settingsLayout)

    $tabPhone = New-Object System.Windows.Forms.TabPage
    $tabPhone.Text = 'Pixel-Checkliste'
    $checkGroup = New-Object System.Windows.Forms.GroupBox
    $checkGroup.Text = 'einmalig am Pixel prüfen'
    $checkGroup.Dock = 'Fill'
    $checkGroup.ForeColor = $palette.Text
    $checkGroup.Margin = New-Object System.Windows.Forms.Padding(10)
    $checkBox = New-Object System.Windows.Forms.TextBox
    $checkBox.Dock = 'Fill'
    $checkBox.Multiline = $true
    $checkBox.ReadOnly = $true
    $checkBox.ScrollBars = [System.Windows.Forms.ScrollBars]::Vertical
    $checkBox.WordWrap = $true
    $checkBox.Font = New-Object System.Drawing.Font('Consolas', [single]9.5)
    [void]$checkGroup.Controls.Add($checkBox)
    [void]$tabPhone.Controls.Add($checkGroup)
    $script:Gui['checkBox'] = $checkBox

    [void]$tabs.TabPages.Add($tabRun)
    [void]$tabs.TabPages.Add($tabSettings)
    [void]$tabs.TabPages.Add($tabPhone)

    [void]$root.Controls.Add($header, 0, 0)
    [void]$root.Controls.Add($tabs, 0, 1)
    [void]$root.Controls.Add($status, 0, 2)
    [void]$form.Controls.Add($root)

    $timer = New-Object System.Windows.Forms.Timer
    $timer.Interval = 2000
    $timer.Add_Tick({ Update-GuiState })
    $script:Gui['timer'] = $timer

    $form.Add_Shown({
        Write-Log "Fenster-Oberfläche $script:AppVersion bereit." 'INFO'
        Reset-GuiSettings
        Update-GuiState
        $script:Gui['timer'].Start()
    })
    $form.Add_FormClosing({
        param($sender, $event)
        $watch = $null
        try { $watch = Get-TrackedTask -Task 'Watch' } catch { $watch = $null }
        if ($watch -and [bool]$watch.Running) {
            $question = "Die Überwachung läuft im Hintergrund weiter (PID $($watch.ProcessId)).`r`nSie lässt sich erst beim nächsten Öffnen dieses Fensters wieder beenden.`r`n`r`nFenster schließen?"
            $answer = [System.Windows.Forms.MessageBox]::Show(
                $sender, $question, 'Pixel Photo Uploader',
                [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question)
            if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
                $event.Cancel = $true
                return
            }
        }
        if ($script:Gui -and $script:Gui['timer']) { $script:Gui['timer'].Stop() }
    })

    try {
        [void]$form.ShowDialog()
    }
    finally {
        if ($script:Gui -and $script:Gui['timer']) {
            $script:Gui['timer'].Stop()
            $script:Gui['timer'].Dispose()
        }
        $form.Dispose()
        $script:Gui = $null
        if ($script:GuiToolTip) {
            $script:GuiToolTip.Dispose()
            $script:GuiToolTip = $null
        }
    }
}

function Show-Menu {
    while ($true) {
        Clear-Host
        Write-Host "Pixel Photo Uploader $script:AppVersion"
        Write-Host "Skriptordner:    $PSScriptRoot"
        Write-Host '================================'
        Write-Host '1  Einrichtung / Quelle ändern'
        Write-Host '2  Dauerbetrieb starten'
        Write-Host '3  Jetzt vollständig abgleichen (sortieren, katalogisieren, übergeben)'
        Write-Host '4  Status anzeigen'
        Write-Host '5  Verbindung bzw. Übergabe prüfen'
        Write-Host '6  Nach bestätigter manueller Freigabe abgleichen'
        Write-Host '7  WLAN-ADB nach Pixel-Neustart reaktivieren (nur ADB-Einrichtung)'
        Write-Host '8  Fenster-Oberfläche öffnen'
        Write-Host '0  Beenden'
        Write-Host ''
        $choice = Read-Host 'Auswahl'
        try {
            switch ($choice) {
                '1' { Run-Setup; Read-Host 'Weiter mit Eingabetaste' | Out-Null }
                '2' { Run-WatchLoop }
                '3' { Invoke-FullPass | Out-Null; Read-Host 'Weiter mit Eingabetaste' | Out-Null }
                '4' { Show-Status; Read-Host 'Weiter mit Eingabetaste' | Out-Null }
                '5' { Run-Preflight; Read-Host 'Weiter mit Eingabetaste' | Out-Null }
                '6' { Reconcile-ManualCleanup; Read-Host 'Weiter mit Eingabetaste' | Out-Null }
                '7' { Reenable-WifiAdb; Read-Host 'Weiter mit Eingabetaste' | Out-Null }
                '8' { Show-MainWindow }
                '0' { return }
                default { }
            }
        }
        catch {
            Write-Log $_.Exception.Message 'ERROR'
            Read-Host 'Weiter mit Eingabetaste' | Out-Null
        }
    }
}

try {
    switch ($Action) {
        'Menu'      { Show-Menu }
        'Gui'       {
            # Die Oberfläche läuft in einem versteckten Prozess; ein Fehler wäre sonst unsichtbar.
            try {
                Show-MainWindow
            }
            catch {
                $text = Format-GuiErrorText -Problem $_
                Write-Log ("Oberfläche konnte nicht starten: " + ($text -replace '\r?\n', ' | ')) 'ERROR'
                try {
                    Add-Type -AssemblyName System.Windows.Forms
                    [void][System.Windows.Forms.MessageBox]::Show(
                        "Die Oberfläche konnte nicht gestartet werden:`r`n`r`n$text`r`n`r`nProtokoll: $script:LogPath",
                        'Pixel Photo Uploader')
                }
                catch { }
                exit 1
            }
        }
        'Setup'     { Run-Setup }
        'Watch'     { Run-WatchLoop }
        'Scan'      { $config = Load-Config; Invoke-ImportPipeline -Config $config | Out-Null; Update-Catalog -Config $config | Out-Null }
        'Sync'      { Invoke-FullPass | Out-Null }
        'Status'    { Show-Status }
        'Preflight' { Run-Preflight }
        'SelfTest'  { Run-SelfTest }
    }
}
catch {
    Write-Log $_.Exception.Message 'ERROR'
    exit 1
}
